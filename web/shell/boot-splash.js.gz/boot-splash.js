/* SPDX-License-Identifier: AGPL-3.0-or-later */
// The start-up animation behind the boot screen (honours prefers-reduced-motion).
(function(){
  var cv=document.getElementById('boot-atom'); if(!cv||!cv.getContext) return;
  var ctx=cv.getContext('2d'), raf=0, stopped=false, t0=0;
  // Accessibility + first-boot CPU. This canvas is the heaviest thing on screen (radial gradients,
  // 280 stars, shadowBlur, ~60 fps) and it runs during boot, competing with the very work it is
  // waiting for. Honour prefers-reduced-motion: paint ONE settled frame and stop — no rAF loop,
  // no vestibular trigger, and a weak client gets its cycles back for booting the OS.
  var REDUCE=false; try{ REDUCE=matchMedia('(prefers-reduced-motion: reduce)').matches; }catch(e){}
  function nowMs(){ return (window.performance&&performance.now)?performance.now():Date.now(); }
  var DPR=Math.min(window.devicePixelRatio||1,2), W=0, H=0;
  var TILTS=[0,Math.PI/3,2*Math.PI/3], SPD=[2.0,-2.45,2.95], PH=[0,2.1,4.2];
  var stars=[], dust=[], nebula=[], NUC=[];
  function rnd(s){var x=Math.sin(s*127.1+311.7)*43758.5453;return x-Math.floor(x);}
  function build(){
    stars=[]; var n=Math.min(280,Math.round(W*H/6000));
    for(var i=0;i<n;i++){var L=rnd(i+3)<0.5?0:(rnd(i+5)<0.7?1:2);
      stars.push({x:rnd(i+1)*W,y:rnd(i+7)*H,L:L,b:0.15+rnd(i+13)*0.8,tw:rnd(i+19)*6.2832,r:(0.5+rnd(i+29))*(1+L*0.5),fl:rnd(i+37)<0.05});}
    dust=[]; var dn=Math.min(48,Math.round(W*H/22000));
    for(var j=0;j<dn;j++)dust.push({x:rnd(j+101)*W,y:rnd(j+131)*H,ph:rnd(j+151)*6.2832,sp:0.3+rnd(j+167)*0.7,r:0.6+rnd(j+181)*1.4,a:0.08+rnd(j+199)*0.22});
    nebula=[{x:0.30,y:0.32,c:'40,90,200',s:0.55,ph:0.0},{x:0.72,y:0.30,c:'120,55,185',s:0.50,ph:1.7},
            {x:0.64,y:0.70,c:'20,150,170',s:0.60,ph:3.1},{x:0.26,y:0.74,c:'180,60,120',s:0.45,ph:4.6}];
    NUC=[]; for(var k=0;k<22;k++)NUC.push({a:k*2.399963,rr:Math.sqrt(k/22),p:(k%3!==0),ph:rnd(k+41)*6.2832});
  }
  function ensureSize(){var w=window.innerWidth||document.documentElement.clientWidth||0,
    h=window.innerHeight||document.documentElement.clientHeight||0; if(w===W&&h===H)return;
    W=w;H=h;cv.width=Math.max(1,Math.round(W*DPR));cv.height=Math.max(1,Math.round(H*DPR));
    ctx.setTransform(DPR,0,0,DPR,0,0); build();}
  function ept(ring,pm,R,B,cx,cy){var ex=R*Math.cos(pm),ey=B*Math.sin(pm),T=TILTS[ring];
    return {x:cx+ex*Math.cos(T)-ey*Math.sin(T),y:cy+ex*Math.sin(T)+ey*Math.cos(T),d:Math.sin(pm)};}
  function pill(x,y,w,h){var r=h/2;ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);
    ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);}
  function glow(x,y,r,col,a){var g=ctx.createRadialGradient(x,y,0,x,y,r);
    g.addColorStop(0,'rgba('+col+','+a+')');g.addColorStop(1,'rgba('+col+',0)');
    ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r,0,6.2832);ctx.fill();}
  function frame(ts){
    if(stopped)return;
    // Reduced motion: bias t so the first (and only) frame shows the SETTLED composition —
    // nucleus lit, rings drawn, wordmark in — instead of the blank start of the ignition ramp.
    if(!t0)t0=REDUCE?ts-2200:ts;
    ensureSize(); if(!W||!H){ if(REDUCE)return; raf=requestAnimationFrame(frame);return;} var t=(ts-t0)/1000;
    var cx=W/2, cy=H*0.42, R=Math.max(74,Math.min(168,Math.min(W,H)*0.18)), B=R*0.32;
    var nucR=R*0.22, eR=Math.max(2.4,R*0.05), fs=Math.max(22,Math.min(48,Math.min(W,H)*0.064));
    var ign=Math.min(1,t/0.6), ringR=Math.min(1,Math.max(0,(t-0.3)/0.8)),
        elec=Math.min(1,Math.max(0,(t-0.6)/0.7)), word=Math.min(1,Math.max(0,(t-1.05)/0.8));

    // ---- animated background (additive bloom over an opaque base) ----
    ctx.clearRect(0,0,W,H);
    var bgg=ctx.createRadialGradient(cx,cy,0,cx,cy,Math.max(W,H)*0.75);
    bgg.addColorStop(0,'#0a1430');bgg.addColorStop(0.5,'#05070f');bgg.addColorStop(1,'#010206');
    ctx.fillStyle=bgg;ctx.fillRect(0,0,W,H);
    ctx.globalCompositeOperation='lighter';
    for(var nb=0;nb<nebula.length;nb++){var b=nebula[nb];
      var bx=(b.x+0.03*Math.sin(t*0.15+b.ph))*W, by=(b.y+0.03*Math.cos(t*0.12+b.ph))*H;
      glow(bx,by,Math.max(W,H)*b.s*(0.85+0.15*Math.sin(t*0.4+b.ph)),b.c,0.15);}
    for(var i=0;i<stars.length;i++){var s=stars[i];
      var sx=(s.x+t*(4+s.L*9))%W, sy=(s.y+t*(1.5+s.L*3))%H; if(sx<0)sx+=W; if(sy<0)sy+=H;
      var tw=0.55+0.45*Math.sin(t*(1.5+s.L)+s.tw);
      ctx.globalAlpha=s.b*tw; ctx.fillStyle=s.L?'#dce8ff':'#9fb4e0';
      ctx.beginPath();ctx.arc(sx,sy,s.r,0,6.2832);ctx.fill();
      if(s.fl){var gl=s.r*3.4;ctx.globalAlpha=s.b*tw*0.7;ctx.fillStyle='#bcd8ff';
        ctx.fillRect(sx-gl,sy-0.4,gl*2,0.8);ctx.fillRect(sx-0.4,sy-gl,0.8,gl*2);}}
    for(var dd=0;dd<dust.length;dd++){var dm=dust[dd];
      var dx=(dm.x+Math.sin(t*dm.sp+dm.ph)*18)%W, dy=(dm.y-t*dm.sp*10)%H; if(dx<0)dx+=W; if(dy<0)dy+=H;
      ctx.globalAlpha=dm.a*(0.5+0.5*Math.sin(t*2+dm.ph));ctx.fillStyle='#9fc6ff';
      ctx.beginPath();ctx.arc(dx,dy,dm.r,0,6.2832);ctx.fill();}
    ctx.globalAlpha=1;
    (function(){var per=4.5,idx=Math.floor(t/per),lt=t-idx*per,dur=0.9;   // periodic meteor
      if(lt<dur){var pr=lt/dur,sx0=rnd(idx*7+1)*W*0.8,sy0=rnd(idx*7+3)*H*0.25,ang=0.5+rnd(idx*7+5)*0.5,len=180;
        var hx=sx0+Math.cos(ang)*W*0.55*pr,hy=sy0+Math.sin(ang)*H*0.6*pr,a=Math.sin(pr*Math.PI)*0.8;
        var mg=ctx.createLinearGradient(hx-Math.cos(ang)*len,hy-Math.sin(ang)*len,hx,hy);
        mg.addColorStop(0,'rgba(140,200,255,0)');mg.addColorStop(1,'rgba(205,232,255,'+a+')');
        ctx.strokeStyle=mg;ctx.lineWidth=2;ctx.lineCap='round';ctx.beginPath();
        ctx.moveTo(hx-Math.cos(ang)*len,hy-Math.sin(ang)*len);ctx.lineTo(hx,hy);ctx.stroke();
        glow(hx,hy,9,'205,232,255',a);}})();
    ctx.globalCompositeOperation='source-over';

    // ---- atom ----
    if(ringR>0){ctx.save();ctx.globalAlpha=ringR*0.45;ctx.translate(cx,cy);ctx.rotate(t*0.25);  // energy HUD ring
      ctx.strokeStyle='rgba(70,205,255,0.6)';ctx.lineWidth=1;
      for(var tk=0;tk<48;tk++){var aa=tk/48*6.2832,r1=R*1.12,r2=R*(tk%4===0?1.21:1.16);
        ctx.beginPath();ctx.moveTo(Math.cos(aa)*r1,Math.sin(aa)*r1);ctx.lineTo(Math.cos(aa)*r2,Math.sin(aa)*r2);ctx.stroke();}
      ctx.restore();}
    function ringHalf(front,col,glowcol,w){ctx.lineCap='round';
      ctx.globalCompositeOperation='lighter';ctx.shadowColor=glowcol;ctx.shadowBlur=14;ctx.strokeStyle=col;ctx.lineWidth=w;
      for(var r=0;r<3;r++){ctx.beginPath();var on=false;for(var j=0;j<=72;j++){var m=j/72*6.2832,d=Math.sin(m);
        if((d>=0)!==front){on=false;continue;}var p=ept(r,m,R,B,cx,cy);if(!on){ctx.moveTo(p.x,p.y);on=true;}else ctx.lineTo(p.x,p.y);}ctx.stroke();}
      ctx.shadowBlur=0;ctx.globalCompositeOperation='source-over';}
    function electrons(front){for(var r=0;r<3;r++){var m=SPD[r]*t+PH[r],p=ept(r,m,R,B,cx,cy);
      if((p.d>=0)!==front)continue;var dep=(p.d+1)/2,sz=eR*(0.65+dep)*elec;
      ctx.globalCompositeOperation='lighter';
      for(var q=12;q>=1;q--){var tp=m-(SPD[r]>0?1:-1)*q*0.085,tq=ept(r,tp,R,B,cx,cy);if((tq.d>=0)!==front)continue;
        ctx.globalAlpha=(1-q/13)*0.4*elec;ctx.fillStyle='#36e0ff';ctx.beginPath();ctx.arc(tq.x,tq.y,sz*(1-q/15),0,6.2832);ctx.fill();}
      ctx.globalAlpha=1;glow(p.x,p.y,sz*5,'80,220,255',0.5*elec*(0.6+dep*0.4));
      ctx.shadowColor='#9af0ff';ctx.shadowBlur=16*elec;ctx.fillStyle='#eaffff';ctx.beginPath();ctx.arc(p.x,p.y,sz,0,6.2832);ctx.fill();ctx.shadowBlur=0;
      if(front&&dep>0.55){var g2=sz*4.5*(0.6+0.4*Math.sin(t*8+r));ctx.globalAlpha=elec*0.6;ctx.fillStyle='#cdfaff';
        ctx.fillRect(p.x-g2,p.y-0.6,g2*2,1.2);ctx.fillRect(p.x-0.6,p.y-g2,1.2,g2*2);ctx.globalAlpha=1;}
      ctx.globalCompositeOperation='source-over';}}
    if(ringR>0)ringHalf(false,'rgba(40,140,170,'+(0.8*ringR)+')','rgba(40,160,200,0.6)',Math.max(1,R*0.013));
    electrons(false);
    var pulse=1+0.06*Math.sin(t*5);                                   // nucleus
    ctx.globalCompositeOperation='lighter';
    glow(cx,cy,nucR*3.2*pulse,'255,150,60',0.5*ign);glow(cx,cy,nucR*1.7*pulse,'255,210,130',0.6*ign);
    ctx.globalCompositeOperation='source-over';
    for(var mm=0;mm<NUC.length;mm++){var nu=NUC[mm],rr=nucR*0.82*nu.rr*ign,
      jx=Math.cos(nu.ph+t*3)*nucR*0.07,jy=Math.sin(nu.ph+t*3.3)*nucR*0.07;
      ctx.fillStyle=nu.p?'rgba(255,120,70,'+ign+')':'rgba(140,170,240,'+ign+')';
      ctx.beginPath();ctx.arc(cx+Math.cos(nu.a)*rr+jx,cy+Math.sin(nu.a)*rr*0.92+jy,nucR*0.15,0,6.2832);ctx.fill();}
    ctx.globalCompositeOperation='lighter';glow(cx,cy,nucR*0.95,'255,250,225',0.95*ign);ctx.globalCompositeOperation='source-over';
    for(var ep=0;ep<2;ep++){var pp=((t+ep*0.7)%1.6)/1.15; if(pp<1){ctx.strokeStyle='rgba(120,210,255,'+((1-pp)*0.3*ign)+')';
      ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(cx,cy,nucR+pp*R*1.0,0,6.2832);ctx.stroke();}}
    if(ringR>0)ringHalf(true,'rgba(90,235,255,'+(0.95*ringR)+')','rgba(60,224,255,0.8)',Math.max(1.4,R*0.016));
    electrons(true);

    // ---- foreground ----
    if(word>0){ctx.globalAlpha=word;ctx.textAlign='center';ctx.textBaseline='middle';var wy=cy+R*1.45;
      ctx.shadowColor='rgba(60,224,255,0.8)';ctx.shadowBlur=28*word;ctx.fillStyle='#eaf6ff';
      ctx.font='700 '+fs+'px ui-sans-serif,system-ui,"Segoe UI",Roboto,sans-serif';ctx.fillText('NucleoOS',cx,wy);ctx.shadowBlur=0;
      var uw=ctx.measureText('NucleoOS').width*0.5*Math.min(1,Math.max(0,(t-1.1)/0.6));
      if(uw>0){var ug=ctx.createLinearGradient(cx-uw,0,cx+uw,0);ug.addColorStop(0,'rgba(60,224,255,0)');
        ug.addColorStop(0.5,'rgba(90,240,255,0.9)');ug.addColorStop(1,'rgba(60,224,255,0)');ctx.fillStyle=ug;ctx.fillRect(cx-uw,wy+fs*0.62,uw*2,1.5);}
      ctx.fillStyle='rgba(150,180,210,'+word+')';ctx.font='400 '+Math.max(11,fs*0.29)+'px ui-sans-serif,system-ui,sans-serif';
      ctx.fillText('w e b - n a t i v e   o s',cx,wy+fs*0.92);ctx.globalAlpha=1;}
    var bw=Math.min(280,W*0.5), bx=cx-bw/2, by=cy+R*1.45+fs*1.7+16, sweep=(t*0.55)%1;
    ctx.fillStyle='rgba(255,255,255,0.07)';pill(bx,by,bw,3);ctx.fill();
    ctx.save();pill(bx,by,bw,3);ctx.clip();ctx.globalCompositeOperation='lighter';
    var hw=bw*0.36, hx=bx-hw+(bw+hw)*sweep, lg=ctx.createLinearGradient(hx,0,hx+hw,0);
    lg.addColorStop(0,'rgba(60,224,255,0)');lg.addColorStop(0.5,'rgba(120,240,255,1)');lg.addColorStop(1,'rgba(60,224,255,0)');
    ctx.fillStyle=lg;ctx.fillRect(bx-hw,by-2,bw+hw*2,7);ctx.restore();
    var vg=ctx.createRadialGradient(cx,cy,Math.min(W,H)*0.3,cx,cy,Math.max(W,H)*0.72);  // vignette
    vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,6,0.55)');ctx.fillStyle=vg;ctx.fillRect(0,0,W,H);
    if(REDUCE)return;                 // one static frame — never schedule the animation loop
    raf=requestAnimationFrame(frame);
  }
  // Repaint the static frame when the viewport changes, so reduced-motion isn't left with a
  // stale canvas after a resize/rotate (the animated path redraws every frame anyway).
  function onResize(){ var w0=W,h0=H; ensureSize(); if(REDUCE&&!stopped&&(W!==w0||H!==h0)){ t0=0; frame(nowMs()); } }
  function stop(){if(stopped)return;stopped=true;if(raf)cancelAnimationFrame(raf);window.removeEventListener('resize',onResize);}
  var bs=document.getElementById('boot-screen');
  if(bs){if(bs.classList.contains('hidden'))stop();
    else if(window.MutationObserver){var mo=new MutationObserver(function(){if(bs.classList.contains('hidden')){setTimeout(stop,500);mo.disconnect();}});mo.observe(bs,{attributes:true,attributeFilter:['class']});}}
  setTimeout(stop,60000);   // hard backstop: never spin forever if the hide signal is missed
  window.addEventListener('resize',onResize);
  try{ensureSize();if(REDUCE)frame(nowMs());else raf=requestAnimationFrame(frame);}catch(e){}
})();
