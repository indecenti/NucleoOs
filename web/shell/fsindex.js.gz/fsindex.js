/* SPDX-License-Identifier: AGPL-3.0-or-later */
// NucleoOS file index — the brains behind taskbar/Start search.
//
// The device exposes only /api/fs/list (no native search). Hitting it per keystroke is slow
// and floods the device, so instead we crawl the SD ONCE (breadth-first, capped), keep a flat
// in-memory index, and answer every search from RAM — instant, zero network. The index is:
//   • persisted to localStorage so a returning browser searches immediately (any age), and
//     re-crawled only when someone searches and it is missing, stale or older than 10 min — never at
//     boot (it used to walk /data on every boot, in the middle of the session restore);
//   • MARKED stale by fs.changed (no request); re-crawled at once only while a search is open, so
//     results stay fresh without polling or re-reading the SD after every save;
//   • bounded (depth + total directory reads) to stay kind to the ESP32 and its SD card.
//
// Everything here is framework-free and self-contained; the shell calls init() at boot, warm() + search()
// from the search UI, invalidate() on fs.changed. Host-tested in tests/suite/shell-fsindex.test.mjs.

import fs from './nucleo-fs.js';

const ROOTS = ['/data'];
const MAX_DEPTH = 6;            // how deep into /data we descend
const MAX_DIRS = 600;          // hard cap on directory reads per full crawl (bounded work per boot)
const PERSIST_KEY = 'nucleo.fsindex.v1';
const PERSIST_TTL = 10 * 60 * 1000;   // a stored index is shown instantly if younger than this
const REFRESH_DEBOUNCE = 1500;        // coalesce bursts of fs.changed into one re-crawl
const PERSIST_MAX = 4000;             // entries actually written to localStorage (see persist)

// The ROM tree is NOT crawled, and that is the single biggest thing this file does
// for the device. /data/ROMs is a symlink to /roms and /api/fs/list resolves
// symlinks, so the crawl walked the entire library — ~45 systems, each with
// images/, manuals/, ports/ — as one SEQUENTIAL HTTP request per directory, one
// stat per entry, on exFAT-over-FUSE, from the same card the emulator streams the
// running game off. It also poisoned the feature it exists for: the 600-directory
// budget burned itself inside artwork folders, so Notes and Documents fell out of
// search behind thousands of boxart .png.
// Games are not lost from search — they come from /api/library, which the DEVICE
// owns and keeps in sync (and which counts them off the disk, not off gamelist.xml).
const SKIP = new Set(['/data/ROMs', '/data/roms', '/data/play']);
const skipped = (p) => SKIP.has(p) || [...SKIP].some((s) => p.startsWith(s + '/'));

// Map an extension to a coarse category used for grouping + glyphs in the UI.
const CAT = {
  image: new Set(['jpg', 'jpeg', 'png', 'bmp', 'gif', 'webp', 'svg']),
  audio: new Set(['mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac']),
  video: new Set(['nfv', 'mp4', 'webm', 'mov', 'mkv', 'avi']),
  doc: new Set(['txt', 'md', 'pdf', 'doc', 'docx', 'rtf', 'log']),
  code: new Set(['js', 'mjs', 'ts', 'json', 'c', 'h', 'cpp', 'py', 'sh', 'html', 'css', 'xml', 'yaml', 'yml', 'toml', 'ini', 'cfg', 'csv']),
  game: new Set(['jsdos', 'com', 'exe']),
};
export function categoryOf(name, isDir) {
  if (isDir) return 'folder';
  const ext = (name.split('.').pop() || '').toLowerCase();
  for (const c in CAT) if (CAT[c].has(ext)) return c;
  return 'other';
}

let index = [];          // [{ path, name, lower, dir, ext, isDir, cat }]
let builtAt = 0;         // timestamp of the last successful crawl (0 = never)
let building = null;     // in-flight crawl promise (dedupes concurrent callers)
let refreshTimer = null;
const updateCbs = new Set();   // notified after every (re)build so the UI can repaint

const host = (() => { try { return location.host; } catch { return ''; } })();
const now = () => Date.now();

// ---- persistence (instant cold-start, revalidated in the background) ----
function loadPersisted() {
  try {
    const raw = localStorage.getItem(PERSIST_KEY);
    if (!raw) return false;
    const o = JSON.parse(raw);
    if (!o || o.host !== host || !Array.isArray(o.items)) return false;
    index = o.items;
    builtAt = o.builtAt || 0;
    return (now() - builtAt) < PERSIST_TTL;     // fresh enough to trust until revalidation
  } catch { return false; }
}
function persist() {
  // Bounded on purpose: a scraped library used to serialise tens of thousands of
  // entries, blow the localStorage quota, and fail inside a silent catch — which
  // left the PREVIOUS (stale) index in place and meant the next load was never
  // warm, so it re-crawled from scratch every single time. Cap what we store, and
  // if it still doesn't fit, drop the key instead of keeping a lie.
  try {
    const items = index.length > PERSIST_MAX ? index.slice(0, PERSIST_MAX) : index;
    localStorage.setItem(PERSIST_KEY, JSON.stringify({ host, builtAt, items }));
  } catch {
    try { localStorage.removeItem(PERSIST_KEY); } catch {}
  }
}

// ---- crawl ----
// Through the core file layer: its request queue keeps the crawl from crowding the device's sockets, and it
// never lists the temporary files of a write in progress. null = this folder could not be read.
async function listDir(path) {
  try { return await fs.list(path); } catch { return null; }
}

async function crawl() {
  const out = [];
  const queue = ROOTS.map((p) => ({ path: p, depth: 0 }));
  let reads = 0;
  while (queue.length && reads < MAX_DIRS) {
    const { path, depth } = queue.shift();
    reads++;
    const entries = await listDir(path);
    if (!entries) continue;
    for (const e of entries) {
      if (!e || typeof e.name !== 'string' || !e.name) continue;   // one malformed entry must not sink the crawl
      const isDir = e.type === 'dir';
      const full = path.endsWith('/') ? path + e.name : path + '/' + e.name;
      out.push({
        path: full, name: e.name, lower: e.name.toLowerCase(),
        dir: path, isDir, size: e.size || 0,
        ext: isDir ? '' : (e.name.split('.').pop() || '').toLowerCase(),
        cat: categoryOf(e.name, isDir),
      });
      // The folder itself stays in the index (it is a useful navigation target);
      // what we refuse is to DESCEND into it.
      if (isDir && depth + 1 < MAX_DEPTH && !skipped(full)) queue.push({ path: full, depth: depth + 1 });
    }
  }
  return out;
}

// Build (or rebuild) the index. Concurrent callers share one crawl. `force` ignores freshness.
export function ensure(force = false) {
  if (building) return building;
  if (!force && builtAt && (now() - builtAt) < PERSIST_TTL) return Promise.resolve(index);
  building = (async () => {
    // finally: a throw anywhere in the crawl must clear `building`, or every later ensure()/
    // invalidate() returns this same rejected promise and search is dead for the session.
    try {
      const items = await crawl();
      // A crawl that returns nothing (device unreachable mid-session) shouldn't wipe a good index.
      if (items.length || !index.length) { index = items; builtAt = now(); persist(); }
      for (const cb of updateCbs) try { cb(); } catch {}
      return index;
    } finally {
      building = null;
    }
  })();
  building.catch(() => {});   // invalidate()'s fire-and-forget path must not surface as an unhandled rejection
  return building;
}

// The device changed something on disk. The index is only MARKED stale: re-crawling the whole SD after
// every save (a note, a config file, ANIMA's learning) was the costliest thing the shell did to the
// Cardputer. It is re-crawled when someone searches (warm), or right away only while a search is open.
let stale = false;
let isLive = () => false;      // set by init(): "is a search on screen right now?"
// A change inside a subtree we never crawl (SKIP) cannot change the index, so it does not even mark it
// stale: writing a save or a play-stat file must not cost a re-walk of /data.
export function invalidate(path) {
  if (path && skipped(path)) return;
  stale = true;
  clearTimeout(refreshTimer);
  if (isLive()) refreshTimer = setTimeout(() => ensure(true), REFRESH_DEBOUNCE);
}
// Called by the search UI: answer from what we have, and refresh in the background if it is missing,
// stale, or old. Concurrent calls share one crawl.
export function warm() {
  if (!builtAt || stale || (now() - builtAt) >= PERSIST_TTL) { stale = false; ensure(true); }   // a change DURING the crawl marks it stale again
}

export function onUpdate(cb) { updateCbs.add(cb); return () => updateCbs.delete(cb); }
export const isReady = () => builtAt > 0;

// ---- ranking ----
// Higher is better. Rewards prefix and word-boundary matches over buried substrings, penalises
// depth and length a touch so the shortest, shallowest, closest name wins — like a real OS.
function scoreEntry(it, terms) {
  let score = 0;
  for (const t of terms) {
    const name = it.lower, path = it.path.toLowerCase();
    let s;
    if (name === t) s = 1000;
    else if (name.startsWith(t)) s = 760;
    else if (wordStarts(name, t)) s = 620;
    else if (name.includes(t)) s = 440;
    else if (path.includes(t)) s = 220;
    else return -1;                    // every term must match somewhere (AND semantics)
    score += s;
  }
  score += it.isDir ? 30 : 0;          // folders are useful navigation targets
  score -= (it.path.split('/').length - 2) * 8;   // shallower wins
  score -= Math.min(it.name.length, 40) * 0.4;    // shorter wins
  return score;
}
// True if `t` starts a word in `s` (after a separator), e.g. "los" matches "My Bones — Losing".
function wordStarts(s, t) {
  let i = s.indexOf(t);
  while (i > 0) {
    if (/[\s_\-.\/()]/.test(s[i - 1])) return true;
    i = s.indexOf(t, i + 1);
  }
  return i === 0;
}

// Search the in-memory index. Returns ranked [{ ...entry, cat }]. Pure + synchronous — call
// ensure() once up front (or rely on the persisted index) so this stays instant per keystroke.
export function search(query, limit = 40) {
  const q = (query || '').trim().toLowerCase();
  if (!q) return [];
  const terms = q.split(/\s+/).filter(Boolean);
  const scored = [];
  for (const it of index) {
    const sc = scoreEntry(it, terms);
    if (sc >= 0) scored.push({ it, sc });
  }
  scored.sort((a, b) => b.sc - a.sc);
  return scored.slice(0, limit).map((x) => x.it);
}

// Initialise from the persisted index (instant), then revalidate against the device.
// Boot: the index this browser kept (any age) answers searches instantly; NO crawl here. Every boot used
// to walk /data (up to MAX_DIRS /api/fs/list) even when nobody searched — on a 4-socket, no-PSRAM device,
// in the middle of the session restore. The crawl now happens on the first search (warm()).
export function init({ live } = {}) {
  if (typeof live === 'function') isLive = live;
  loadPersisted();
  if (index.length) for (const cb of updateCbs) try { cb(); } catch {}
}
