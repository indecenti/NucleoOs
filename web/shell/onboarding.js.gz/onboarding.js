/* SPDX-License-Identifier: AGPL-3.0-or-later */
// NucleoOS — first-boot onboarding wizard.
//
// Shows ONCE (per browser) on the first paired boot when no AI provider is configured: a curated
// welcome, a NucleoOS install tutorial (PWA / how the OS is served), and a guided Claude/Groq API-key
// setup with a live key test — all browser-direct (the Cardputer is never loaded). Resolves when the
// user finishes or skips. Idempotent: a `nucleo.onboarded` flag + the device /api/anima/caps probe
// keep it from ever nagging again once a key exists.

import * as AI from './ai.js';
import User from './nucleo-user.js';
import Caps from './nucleo-caps.js';

// The accounts step (users.multi, docs/multiuser.md): its own five-language table, keyed by meaning.
const ACC = {
  it: { title: 'Chi userà questo dispositivo?', sub: 'Puoi cambiare idea in Impostazioni ▸ Account', me: 'Solo io', meD: 'Come oggi: nessun account da creare.',
    many: 'Più persone', manyD: 'Ognuno con i suoi file, le sue impostazioni e il suo assistente.', admin: "Crea l'amministratore",
    adminSub: "Ciò che c'è ora sul dispositivo diventa suo. Altri account si aggiungono in Impostazioni ▸ Account.",
    name: 'Nome', pw: 'Password', again: 'Ripeti la password', pin: 'PIN mostrato dal dispositivo', go: 'Crea', mismatch: 'Le due password non coincidono',
    weak: 'Password troppo debole: almeno 8 caratteri e non una delle più comuni', proof: 'Inserisci il PIN mostrato dal dispositivo', fail: 'Non è riuscito: riprova', taken: 'Questo nome non si può usare' },
  en: { title: 'Who will use this device?', sub: 'You can change your mind in Settings ▸ Accounts', me: 'Only me', meD: 'As today: no account to create.',
    many: 'Several people', manyD: 'Each with their own files, settings and assistant.', admin: 'Create the administrator',
    adminSub: 'What is on the device now becomes theirs. More accounts are added in Settings ▸ Accounts.',
    name: 'Name', pw: 'Password', again: 'Password again', pin: 'PIN shown on the device', go: 'Create', mismatch: 'The two passwords do not match',
    weak: 'Password too weak: at least 8 characters and not a common one', proof: 'Enter the PIN shown on the device', fail: 'It did not work: try again', taken: 'That name cannot be used' },
  es: { title: '¿Quién usará este dispositivo?', sub: 'Puedes cambiarlo en Ajustes ▸ Cuentas', me: 'Solo yo', meD: 'Como hoy: ninguna cuenta que crear.',
    many: 'Varias personas', manyD: 'Cada una con sus archivos, sus ajustes y su asistente.', admin: 'Crear el administrador',
    adminSub: 'Lo que hay ahora en el dispositivo pasa a ser suyo. Más cuentas se añaden en Ajustes ▸ Cuentas.',
    name: 'Nombre', pw: 'Contraseña', again: 'Repite la contraseña', pin: 'PIN que muestra el dispositivo', go: 'Crear', mismatch: 'Las dos contraseñas no coinciden',
    weak: 'Contraseña demasiado débil: al menos 8 caracteres y no una de las más comunes', proof: 'Introduce el PIN que muestra el dispositivo', fail: 'No ha funcionado: inténtalo de nuevo', taken: 'Ese nombre no se puede usar' },
  fr: { title: 'Qui utilisera cet appareil ?', sub: 'Vous pourrez changer dans Réglages ▸ Comptes', me: 'Moi seul', meD: "Comme aujourd'hui : aucun compte à créer.",
    many: 'Plusieurs personnes', manyD: 'Chacune avec ses fichiers, ses réglages et son assistant.', admin: "Créer l'administrateur",
    adminSub: "Ce qui est sur l'appareil maintenant devient le sien. D'autres comptes s'ajoutent dans Réglages ▸ Comptes.",
    name: 'Nom', pw: 'Mot de passe', again: 'Répétez le mot de passe', pin: "PIN affiché par l'appareil", go: 'Créer', mismatch: 'Les deux mots de passe ne correspondent pas',
    weak: 'Mot de passe trop faible : au moins 8 caractères et pas un des plus courants', proof: "Saisissez le PIN affiché par l'appareil", fail: "Cela n'a pas fonctionné : réessayez", taken: 'Ce nom ne peut pas être utilisé' },
  de: { title: 'Wer wird dieses Gerät benutzen?', sub: 'Du kannst es in Einstellungen ▸ Konten ändern', me: 'Nur ich', meD: 'Wie bisher: kein Konto anzulegen.',
    many: 'Mehrere Personen', manyD: 'Jede mit eigenen Dateien, Einstellungen und eigenem Assistenten.', admin: 'Administrator anlegen',
    adminSub: 'Was jetzt auf dem Gerät ist, gehört dann ihm. Weitere Konten kommen in Einstellungen ▸ Konten dazu.',
    name: 'Name', pw: 'Passwort', again: 'Passwort wiederholen', pin: 'PIN, die das Gerät zeigt', go: 'Anlegen', mismatch: 'Die beiden Passwörter stimmen nicht überein',
    weak: 'Passwort zu schwach: mindestens 8 Zeichen und keines der häufigsten', proof: 'Gib die PIN ein, die das Gerät zeigt', fail: 'Das hat nicht geklappt: versuche es erneut', taken: 'Dieser Name ist nicht möglich' },
  zh: { title: '谁会使用这台设备？', sub: '之后可以在「设置 ▸ 账户」中更改', me: '只有我', meD: '和现在一样：无需创建账户。',
    many: '多个人', manyD: '每个人都有自己的文件、设置和助手。', admin: '创建管理员',
    adminSub: '设备上现有的内容都将归管理员所有。更多账户可在「设置 ▸ 账户」中添加。',
    name: '名称', pw: '密码', again: '再次输入密码', pin: '设备上显示的 PIN', go: '创建', mismatch: '两次输入的密码不一致',
    weak: '密码太弱：至少 8 个字符，且不能是常见密码', proof: '请输入设备上显示的 PIN', fail: '操作未成功，请重试', taken: '无法使用此名称' },
};
// The apps step: where the apps are, how one lands on the desktop, where more come from. Five languages, by meaning.
const APPS = {
  it: { title: 'Le tue app', sub: 'Sul desktop trovi solo l\'essenziale: tutto il resto è a un clic',
    start: 'Start', startD: 'Il pulsante in basso apre tutte le app installate. Cerca per nome scrivendo subito.',
    desk: 'Sul desktop', deskD: 'Tasto destro (o tieni premuto) su un\'app in Start, poi «Aggiungi al desktop».',
    store: 'Store', storeD: 'Altre app, firmate e verificate prima di ogni installazione. Si installano e si tolgono con un clic.',
    open: 'Apri lo Store alla fine', opened: 'Lo Store si aprirà quando avrai finito' },
  en: { title: 'Your apps', sub: 'The desktop keeps only the essentials: everything else is one click away',
    start: 'Start', startD: 'The button at the bottom opens every installed app. Type to search by name.',
    desk: 'On the desktop', deskD: 'Right-click (or press and hold) an app in Start, then "Add to desktop".',
    store: 'Store', storeD: 'More apps, signed and checked before every install. Installed and removed with one click.',
    open: 'Open the Store at the end', opened: 'The Store will open when you are done' },
  es: { title: 'Tus apps', sub: 'El escritorio solo tiene lo esencial: todo lo demás está a un clic',
    start: 'Inicio', startD: 'El botón de abajo abre todas las apps instaladas. Escribe para buscar por nombre.',
    desk: 'En el escritorio', deskD: 'Clic derecho (o mantén pulsado) sobre una app en Inicio y luego «Añadir al escritorio».',
    store: 'Tienda', storeD: 'Más apps, firmadas y verificadas antes de cada instalación. Se instalan y se quitan con un clic.',
    open: 'Abrir la Tienda al final', opened: 'La Tienda se abrirá cuando termines' },
  fr: { title: 'Vos applications', sub: "Le bureau ne garde que l'essentiel : tout le reste est à un clic",
    start: 'Démarrer', startD: "Le bouton en bas ouvre toutes les applications installées. Tapez pour chercher par nom.",
    desk: 'Sur le bureau', deskD: "Clic droit (ou appui long) sur une application dans Démarrer, puis « Ajouter au bureau ».",
    store: 'Store', storeD: "D'autres applications, signées et vérifiées avant chaque installation. Installées et retirées en un clic.",
    open: 'Ouvrir le Store à la fin', opened: 'Le Store s\'ouvrira quand vous aurez terminé' },
  de: { title: 'Deine Apps', sub: 'Auf dem Desktop liegt nur das Wichtigste: alles andere ist einen Klick entfernt',
    start: 'Start', startD: 'Die Schaltfläche unten öffnet alle installierten Apps. Tippe, um nach Namen zu suchen.',
    desk: 'Auf den Desktop', deskD: 'Rechtsklick (oder lange drücken) auf eine App in Start, dann „Zum Desktop hinzufügen“.',
    store: 'Store', storeD: 'Weitere Apps, signiert und vor jeder Installation geprüft. Mit einem Klick installiert und entfernt.',
    open: 'Am Ende den Store öffnen', opened: 'Der Store öffnet sich, wenn du fertig bist' },
  zh: { title: '你的应用', sub: '桌面上只放最常用的：其他一切点一下就能找到',
    start: '开始', startD: '底部的按钮会打开所有已安装的应用。直接输入即可按名称搜索。',
    desk: '放到桌面', deskD: '在「开始」中右键点击（或长按）一个应用，然后选择「添加到桌面」。',
    store: '应用商店', storeD: '更多应用，每次安装前都经过签名和校验。点一下即可安装或移除。',
    open: '完成后打开应用商店', opened: '完成后将打开应用商店' },
};

// The device can have accounts and nobody has turned them on: the wizard asks, once per browser ("Only me" is
// remembered here; Settings > Accounts turns them on later).
const ACC_SKIP = 'nucleo.accounts.skip';
let host = {};
async function accountsToSet() {
  try {
    if (localStorage.getItem(ACC_SKIP) === '1') return null;
    if (!(await Caps.has('users.multi'))) return null;
    const st = await User.status();
    return st && st.setup ? st : null;
  } catch { return null; }
}

const ONB_KEY = 'nucleo.onboarded';
const CODES = ['it', 'en', 'es', 'fr', 'de', 'zh'];
// The language is the i18n engine's (window.NucleoI18N), which also knows the device's and the
// browser's. Reading only localStorage was wrong twice: on a fresh browser the key is empty (the intro
// came out in the wrong language), and picking the already-active language doesn't write it (setLang
// is a no-op), so the choice changed nothing. Fallback: English, like Core and the web OS.
const lang = () => {
  let l = window.NucleoI18N && window.NucleoI18N.lang;
  if (!l) { try { l = localStorage.getItem('anima.lang'); } catch {} }
  l = String(l || 'en').slice(0, 2);
  return CODES.includes(l) ? l : 'en';
};
// es/fr/de/zh overlays, keyed by the ENGLISH UI string. it/en render inline via the TR ternaries below;
// TR(it, en): it→it, en→en, otherwise L10N[lang][en] (falling back to the English text if a key is missing).
const L10N = {
  es: {
    'Choose your language': 'Elige tu idioma',
    'You can change it anytime in Settings ▸ Appearance': 'Puedes cambiarlo cuando quieras en Ajustes ▸ Apariencia',
    'Welcome to NucleoOS': 'Bienvenido a NucleoOS',
    'A web-native OS that lives on your device': 'Un SO web-nativo que vive en tu dispositivo',
    'NucleoOS turns your device into a tiny computer you drive from this browser. At its heart is <b>ANIMA</b> — an assistant whose brain runs <b>offline, on the device itself</b>.': 'NucleoOS convierte tu dispositivo en un pequeño ordenador que controlas desde este navegador. En su núcleo está <b>ANIMA</b> — un asistente cuyo cerebro funciona <b>sin conexión, en el propio dispositivo</b>.',
    'Offline brain': 'Cerebro sin conexión',
    'Answers, reasoning and memory — no cloud needed.': 'Respuestas, razonamiento y memoria — sin necesidad de nube.',
    'Optional cloud': 'Nube opcional',
    'Add a Claude key for deeper understanding & verification.': 'Añade una clave Claude para mayor comprensión y verificación.',
    'Your keys, your device': 'Tus claves, tu dispositivo',
    'Keys stay on the device; cloud calls go straight from your browser.': 'Las claves quedan en el dispositivo; las llamadas a la nube salen directas desde tu navegador.',
    'Light on the device': 'Ligero para el dispositivo',
    'The heavy AI work runs in your browser, not the chip.': 'El trabajo pesado de la IA se ejecuta en tu navegador, no en el chip.',
    '✨ Two minutes now and ANIMA is ready everywhere in the OS.': '✨ Dos minutos ahora y ANIMA estará lista en todo el OS.',
    'NucleoOS is served by the device over your network — no app store. <b>Install it</b> to get a full-screen app icon and instant launch.': 'NucleoOS lo sirve el dispositivo a través de tu red — sin tienda de apps. <b>Instálalo</b> para tener un icono de app a pantalla completa e inicio instantáneo.',
    'Keep the device on the same Wi-Fi as this computer or phone.': 'Mantén el dispositivo en la misma Wi-Fi que este ordenador o teléfono.',
    'Desktop (Chrome/Edge): click the ⊕ / install icon in the address bar.': 'Escritorio (Chrome/Edge): haz clic en el icono ⊕ / instalar en la barra de direcciones.',
    'iPhone/iPad (Safari): Share → “Add to Home Screen”.': 'iPhone/iPad (Safari): Compartir → “Añadir a pantalla de inicio”.',
    'Android (Chrome): menu ⋮ → “Install app”.': 'Android (Chrome): menú ⋮ → “Instalar app”.',
    '💡 Tip: bookmark the device IP so you can always get back to NucleoOS.': '💡 Consejo: guarda la IP del dispositivo en marcadores para volver siempre a NucleoOS.',
    'Install NucleoOS': 'Instalar NucleoOS',
    'Add it like a native app': 'Añádelo como una app nativa',
    '⤓ Install app': '⤓ Instalar app',
    'RECOMMENDED': 'RECOMENDADO',
    'Choose your AI': 'Elige tu IA',
    'You can change this anytime in Settings ▸ AI': 'Puedes cambiarlo cuando quieras en Ajustes ▸ IA',
    'Best understanding. Runs in your browser — zero load on the device.': 'La mejor comprensión. Se ejecuta en tu navegador — cero carga en el dispositivo.',
    'Fast & free tier. OpenAI-compatible (Llama models).': 'Rápido y con nivel gratuito. Compatible con OpenAI (modelos Llama).',
    'Strong, generous free tier. Routed via the device proxy (no browser CORS).': 'Potente, con nivel gratuito generoso. Enrutado por el proxy del dispositivo (sin CORS de navegador).',
    'Offline only': 'Solo sin conexión',
    'No key. ANIMA still answers from its on-device brain, weather & Wikipedia.': 'Sin clave. ANIMA sigue respondiendo desde su cerebro en el dispositivo, el tiempo y Wikipedia.',
    'Paste a key first.': 'Pega primero una clave.',
    'testing…': 'probando…',
    '✓ Key works!': '✓ ¡La clave funciona!',
    '✗ Key rejected.': '✗ Clave rechazada.',
    '⚡ Test': '⚡ Probar',
    'Paste your key.': 'Pega tu clave.',
    'That doesn’t look like a ': 'No parece una clave ',
    ' key. Save anyway?': '. ¿Guardar de todos modos?',
    'saving…': 'guardando…',
    'detecting plan…': 'detectando plan…',
    '✓ Saved — ANIMA is ready.': '✓ Guardada — ANIMA está lista.',
    'Pair this browser first.': 'Empareja primero este navegador.',
    'Save failed.': 'Error al guardar.',
    '💾 Save & finish': '💾 Guardar y finalizar',
    'Go to ': 'Ve a ',
    'Open API Keys → Create Key.': 'Abre API Keys → Create Key.',
    'Copy the key (starts with sk-ant-) and paste it below.': 'Copia la clave (empieza por sk-ant-) y pégala abajo.',
    'Create an API key (starts with AIza) and paste it below.': 'Crea una clave API (empieza por AIza) y pégala abajo.',
    'The device relays the call (Google has no browser access).': 'El dispositivo retransmite la llamada (Google no tiene acceso desde el navegador).',
    'Create an API key (starts with gsk_) and paste it below.': 'Crea una clave API (empieza por gsk_) y pégala abajo.',
    'Connect ': 'Conecta ',
    'Your key stays on the device': 'Tu clave permanece en el dispositivo',
    'Model': 'Modelo',
    '{F}: too long for the device (at most {N} characters).': '{F}: demasiado largo para el dispositivo (como máximo {N} caracteres).',
    'Key rejected by {H}: check you copied all of it.': 'Clave rechazada por {H}: comprueba que la copiaste entera.',
    '{H} doesn’t know the model “{M}”: pick one from the list (Test fills it) or check the name.': '{H} no conoce el modelo «{M}»: elige uno de la lista (Probar la llena) o revisa el nombre.',
    'OpenAI-compatible': 'Compatible con OpenAI',
    'OpenRouter, Together, DeepSeek, Mistral, OpenAI or your own server: address, model and key.': 'OpenRouter, Together, DeepSeek, Mistral, OpenAI o tu propio servidor: dirección, modelo y clave.',
    'Connect an OpenAI-compatible service': 'Conecta un servicio compatible con OpenAI',
    'Address, model and key stay on the device': 'Dirección, modelo y clave se quedan en el dispositivo',
    'Copy the API base URL from your service’s docs (it usually ends in /v1).': 'Copia la URL base de la API de la documentación de tu servicio (suele terminar en /v1).',
    'Create an API key there and paste it below.': 'Crea allí una clave de API y pégala abajo.',
    'Press Test: the models the service offers appear in the list.': 'Pulsa Probar: los modelos del servicio aparecen en la lista.',
    'Address': 'Dirección',
    'model name': 'nombre del modelo',
    'Not a valid address: type the service’s base URL, e.g. https://openrouter.ai/api/v1.': 'Dirección no válida: escribe la URL base del servicio, p. ej. https://openrouter.ai/api/v1.',
    'Use an https:// address: over http the key would travel in clear text.': 'Usa una dirección https://: con http la clave viajaría sin cifrar.',
    'Type only the base address, without /chat/completions.': 'Escribe solo la dirección base, sin /chat/completions.',
    'Can’t reach this address from the browser or through the device. Check it (it usually ends in /v1) and the network.': 'No llego a esta dirección ni desde el navegador ni a través del dispositivo. Revísala (suele terminar en /v1) y revisa la red.',
    'The server doesn’t list its models: type the model name.': 'El servidor no lista sus modelos: escribe el nombre del modelo.',
    '✓ Works — called straight from the browser.': '✓ Funciona — llamado directamente desde el navegador.',
    '✓ Works — through the device (the service refuses browser calls).': '✓ Funciona — a través del dispositivo (el servicio no acepta llamadas del navegador).',
    'The test failed. Save anyway?': 'La prueba falló. ¿Guardo igualmente?',
    'Type the model name.': 'Escribe el nombre del modelo.',
    'Stored only on your device, never logged. With Claude the key stays in <b>your browser</b> and talks directly to Anthropic — the device isn’t loaded.': 'Se guarda solo en tu dispositivo, nunca en registros. Con Claude la clave permanece en <b>tu navegador</b> y habla directamente con Anthropic — el dispositivo no se carga.',
    'Skip AI setup? You can do it later in Settings ▸ AI.': '¿Omitir la configuración de la IA? Puedes hacerlo luego en Ajustes ▸ IA.',
    'Set up later': 'Más tarde',
    '← Back': '← Atrás',
    'Next →': 'Siguiente →',
    'Start using NucleoOS': 'Empezar a usar NucleoOS',
  },
  fr: {
    'Choose your language': 'Choisissez votre langue',
    'You can change it anytime in Settings ▸ Appearance': 'Vous pouvez la changer à tout moment dans Réglages ▸ Apparence',
    'Welcome to NucleoOS': 'Bienvenue dans NucleoOS',
    'A web-native OS that lives on your device': 'Un OS web-natif qui vit sur votre appareil',
    'NucleoOS turns your device into a tiny computer you drive from this browser. At its heart is <b>ANIMA</b> — an assistant whose brain runs <b>offline, on the device itself</b>.': 'NucleoOS transforme votre appareil en un petit ordinateur que vous pilotez depuis ce navigateur. En son cœur se trouve <b>ANIMA</b> — un assistant dont le cerveau fonctionne <b>hors ligne, sur l’appareil lui-même</b>.',
    'Offline brain': 'Cerveau hors ligne',
    'Answers, reasoning and memory — no cloud needed.': 'Réponses, raisonnement et mémoire — sans cloud.',
    'Optional cloud': 'Cloud optionnel',
    'Add a Claude key for deeper understanding & verification.': 'Ajoutez une clé Claude pour une compréhension et une vérification accrues.',
    'Your keys, your device': 'Vos clés, votre appareil',
    'Keys stay on the device; cloud calls go straight from your browser.': 'Les clés restent sur l’appareil ; les appels cloud partent directement de votre navigateur.',
    'Light on the device': 'Léger pour l’appareil',
    'The heavy AI work runs in your browser, not the chip.': 'Le gros du travail de l’IA s’exécute dans votre navigateur, pas sur la puce.',
    '✨ Two minutes now and ANIMA is ready everywhere in the OS.': '✨ Deux minutes maintenant et ANIMA est prête partout dans l’OS.',
    'NucleoOS is served by the device over your network — no app store. <b>Install it</b> to get a full-screen app icon and instant launch.': 'NucleoOS est servi par l’appareil sur votre réseau — sans magasin d’applications. <b>Installez-le</b> pour obtenir une icône plein écran et un lancement instantané.',
    'Keep the device on the same Wi-Fi as this computer or phone.': 'Gardez l’appareil sur le même Wi-Fi que cet ordinateur ou ce téléphone.',
    'Desktop (Chrome/Edge): click the ⊕ / install icon in the address bar.': 'Ordinateur (Chrome/Edge) : cliquez sur l’icône ⊕ / installer dans la barre d’adresse.',
    'iPhone/iPad (Safari): Share → “Add to Home Screen”.': 'iPhone/iPad (Safari) : Partager → “Sur l’écran d’accueil”.',
    'Android (Chrome): menu ⋮ → “Install app”.': 'Android (Chrome) : menu ⋮ → “Installer l’application”.',
    '💡 Tip: bookmark the device IP so you can always get back to NucleoOS.': '💡 Astuce : ajoutez l’IP de l’appareil aux favoris pour toujours revenir à NucleoOS.',
    'Install NucleoOS': 'Installer NucleoOS',
    'Add it like a native app': 'Ajoutez-le comme une app native',
    '⤓ Install app': '⤓ Installer l’app',
    'RECOMMENDED': 'RECOMMANDÉ',
    'Choose your AI': 'Choisissez votre IA',
    'You can change this anytime in Settings ▸ AI': 'Vous pouvez le changer à tout moment dans Réglages ▸ IA',
    'Best understanding. Runs in your browser — zero load on the device.': 'La meilleure compréhension. S’exécute dans votre navigateur — aucune charge sur l’appareil.',
    'Fast & free tier. OpenAI-compatible (Llama models).': 'Rapide et avec offre gratuite. Compatible OpenAI (modèles Llama).',
    'Strong, generous free tier. Routed via the device proxy (no browser CORS).': 'Puissant, offre gratuite généreuse. Acheminé via le proxy de l’appareil (sans CORS navigateur).',
    'Offline only': 'Hors ligne uniquement',
    'No key. ANIMA still answers from its on-device brain, weather & Wikipedia.': 'Sans clé. ANIMA répond quand même depuis son cerveau embarqué, la météo et Wikipédia.',
    'Paste a key first.': 'Collez d’abord une clé.',
    'testing…': 'test…',
    '✓ Key works!': '✓ La clé fonctionne !',
    '✗ Key rejected.': '✗ Clé refusée.',
    '⚡ Test': '⚡ Tester',
    'Paste your key.': 'Collez votre clé.',
    'That doesn’t look like a ': 'Cela ne ressemble pas à une clé ',
    ' key. Save anyway?': '. Enregistrer quand même ?',
    'saving…': 'enregistrement…',
    'detecting plan…': 'détection du forfait…',
    '✓ Saved — ANIMA is ready.': '✓ Enregistrée — ANIMA est prête.',
    'Pair this browser first.': 'Appairez d’abord ce navigateur.',
    'Save failed.': 'Échec de l’enregistrement.',
    '💾 Save & finish': '💾 Enregistrer et terminer',
    'Go to ': 'Allez sur ',
    'Open API Keys → Create Key.': 'Ouvrez API Keys → Create Key.',
    'Copy the key (starts with sk-ant-) and paste it below.': 'Copiez la clé (commence par sk-ant-) et collez-la ci-dessous.',
    'Create an API key (starts with AIza) and paste it below.': 'Créez une clé API (commence par AIza) et collez-la ci-dessous.',
    'The device relays the call (Google has no browser access).': 'L’appareil relaie l’appel (Google n’a pas d’accès navigateur).',
    'Create an API key (starts with gsk_) and paste it below.': 'Créez une clé API (commence par gsk_) et collez-la ci-dessous.',
    'Connect ': 'Connecter ',
    'Your key stays on the device': 'Votre clé reste sur l’appareil',
    'Model': 'Modèle',
    '{F}: too long for the device (at most {N} characters).': '{F} : trop long pour l’appareil ({N} caractères au maximum).',
    'Key rejected by {H}: check you copied all of it.': 'Clé refusée par {H} : vérifiez qu’elle est copiée en entier.',
    '{H} doesn’t know the model “{M}”: pick one from the list (Test fills it) or check the name.': '{H} ne connaît pas le modèle « {M} » : choisissez-en un dans la liste (Tester la remplit) ou vérifiez le nom.',
    'OpenAI-compatible': 'Compatible OpenAI',
    'OpenRouter, Together, DeepSeek, Mistral, OpenAI or your own server: address, model and key.': 'OpenRouter, Together, DeepSeek, Mistral, OpenAI ou votre propre serveur : adresse, modèle et clé.',
    'Connect an OpenAI-compatible service': 'Connecter un service compatible OpenAI',
    'Address, model and key stay on the device': 'Adresse, modèle et clé restent sur l’appareil',
    'Copy the API base URL from your service’s docs (it usually ends in /v1).': 'Copiez l’URL de base de l’API depuis la documentation de votre service (elle finit souvent par /v1).',
    'Create an API key there and paste it below.': 'Créez-y une clé API et collez-la ci-dessous.',
    'Press Test: the models the service offers appear in the list.': 'Appuyez sur Tester : les modèles du service apparaissent dans la liste.',
    'Address': 'Adresse',
    'model name': 'nom du modèle',
    'Not a valid address: type the service’s base URL, e.g. https://openrouter.ai/api/v1.': 'Adresse non valide : saisissez l’URL de base du service, par ex. https://openrouter.ai/api/v1.',
    'Use an https:// address: over http the key would travel in clear text.': 'Utilisez une adresse https:// : en http la clé circulerait en clair.',
    'Type only the base address, without /chat/completions.': 'Saisissez seulement l’adresse de base, sans /chat/completions.',
    'Can’t reach this address from the browser or through the device. Check it (it usually ends in /v1) and the network.': 'Impossible de joindre cette adresse depuis le navigateur ou via l’appareil. Vérifiez-la (elle finit souvent par /v1) ainsi que le réseau.',
    'The server doesn’t list its models: type the model name.': 'Le serveur ne liste pas ses modèles : saisissez le nom du modèle.',
    '✓ Works — called straight from the browser.': '✓ Ça marche — appelé directement depuis le navigateur.',
    '✓ Works — through the device (the service refuses browser calls).': '✓ Ça marche — via l’appareil (le service refuse les appels du navigateur).',
    'The test failed. Save anyway?': 'Le test a échoué. Enregistrer quand même ?',
    'Type the model name.': 'Saisissez le nom du modèle.',
    'Stored only on your device, never logged. With Claude the key stays in <b>your browser</b> and talks directly to Anthropic — the device isn’t loaded.': 'Stockée uniquement sur votre appareil, jamais journalisée. Avec Claude, la clé reste dans <b>votre navigateur</b> et communique directement avec Anthropic — l’appareil n’est pas sollicité.',
    'Skip AI setup? You can do it later in Settings ▸ AI.': 'Passer la configuration de l’IA ? Vous pourrez le faire plus tard dans Réglages ▸ IA.',
    'Set up later': 'Plus tard',
    '← Back': '← Retour',
    'Next →': 'Suivant →',
    'Start using NucleoOS': 'Commencer à utiliser NucleoOS',
  },
  de: {
    'Choose your language': 'Wähle deine Sprache',
    'You can change it anytime in Settings ▸ Appearance': 'Du kannst sie jederzeit unter Einstellungen ▸ Erscheinungsbild ändern',
    'Welcome to NucleoOS': 'Willkommen bei NucleoOS',
    'A web-native OS that lives on your device': 'Ein web-natives OS, das auf deinem Gerät lebt',
    'NucleoOS turns your device into a tiny computer you drive from this browser. At its heart is <b>ANIMA</b> — an assistant whose brain runs <b>offline, on the device itself</b>.': 'NucleoOS verwandelt dein Gerät in einen winzigen Computer, den du von diesem Browser aus steuerst. Im Kern steckt <b>ANIMA</b> — ein Assistent, dessen Gehirn <b>offline, auf dem Gerät selbst</b> läuft.',
    'Offline brain': 'Offline-Gehirn',
    'Answers, reasoning and memory — no cloud needed.': 'Antworten, Schlussfolgern und Gedächtnis — ohne Cloud.',
    'Optional cloud': 'Optionale Cloud',
    'Add a Claude key for deeper understanding & verification.': 'Füge einen Claude-Schlüssel für tieferes Verständnis und Verifizierung hinzu.',
    'Your keys, your device': 'Deine Schlüssel, dein Gerät',
    'Keys stay on the device; cloud calls go straight from your browser.': 'Die Schlüssel bleiben auf dem Gerät; Cloud-Aufrufe gehen direkt von deinem Browser aus.',
    'Light on the device': 'Schonend für das Gerät',
    'The heavy AI work runs in your browser, not the chip.': 'Die schwere KI-Arbeit läuft in deinem Browser, nicht auf dem Chip.',
    '✨ Two minutes now and ANIMA is ready everywhere in the OS.': '✨ Zwei Minuten jetzt und ANIMA ist überall im OS bereit.',
    'NucleoOS is served by the device over your network — no app store. <b>Install it</b> to get a full-screen app icon and instant launch.': 'NucleoOS wird vom Gerät über dein Netzwerk bereitgestellt — kein App-Store. <b>Installiere es</b>, um ein Vollbild-App-Icon und sofortigen Start zu erhalten.',
    'Keep the device on the same Wi-Fi as this computer or phone.': 'Halte das Gerät im selben WLAN wie diesen Computer oder dieses Telefon.',
    'Desktop (Chrome/Edge): click the ⊕ / install icon in the address bar.': 'Desktop (Chrome/Edge): Klicke auf das ⊕ / Installieren-Symbol in der Adressleiste.',
    'iPhone/iPad (Safari): Share → “Add to Home Screen”.': 'iPhone/iPad (Safari): Teilen → “Zum Home-Bildschirm”.',
    'Android (Chrome): menu ⋮ → “Install app”.': 'Android (Chrome): Menü ⋮ → “App installieren”.',
    '💡 Tip: bookmark the device IP so you can always get back to NucleoOS.': '💡 Tipp: Setze ein Lesezeichen auf die Geräte-IP, um immer zu NucleoOS zurückzufinden.',
    'Install NucleoOS': 'NucleoOS installieren',
    'Add it like a native app': 'Füge es wie eine native App hinzu',
    '⤓ Install app': '⤓ App installieren',
    'RECOMMENDED': 'EMPFOHLEN',
    'Choose your AI': 'Wähle deine KI',
    'You can change this anytime in Settings ▸ AI': 'Du kannst dies jederzeit unter Einstellungen ▸ KI ändern',
    'Best understanding. Runs in your browser — zero load on the device.': 'Bestes Verständnis. Läuft in deinem Browser — keine Last für das Gerät.',
    'Fast & free tier. OpenAI-compatible (Llama models).': 'Schnell und mit Gratis-Kontingent. OpenAI-kompatibel (Llama-Modelle).',
    'Strong, generous free tier. Routed via the device proxy (no browser CORS).': 'Stark, großzügiges Gratis-Kontingent. Über den Geräte-Proxy geleitet (kein Browser-CORS).',
    'Offline only': 'Nur offline',
    'No key. ANIMA still answers from its on-device brain, weather & Wikipedia.': 'Kein Schlüssel. ANIMA antwortet weiterhin aus ihrem Gehirn auf dem Gerät, Wetter und Wikipedia.',
    'Paste a key first.': 'Füge zuerst einen Schlüssel ein.',
    'testing…': 'teste…',
    '✓ Key works!': '✓ Schlüssel funktioniert!',
    '✗ Key rejected.': '✗ Schlüssel abgelehnt.',
    '⚡ Test': '⚡ Testen',
    'Paste your key.': 'Füge deinen Schlüssel ein.',
    'That doesn’t look like a ': 'Das sieht nicht nach einem ',
    ' key. Save anyway?': '-Schlüssel aus. Trotzdem speichern?',
    'saving…': 'speichere…',
    'detecting plan…': 'erkenne Tarif…',
    '✓ Saved — ANIMA is ready.': '✓ Gespeichert — ANIMA ist bereit.',
    'Pair this browser first.': 'Koppele zuerst diesen Browser.',
    'Save failed.': 'Speichern fehlgeschlagen.',
    '💾 Save & finish': '💾 Speichern und fertig',
    'Go to ': 'Gehe zu ',
    'Open API Keys → Create Key.': 'Öffne API Keys → Create Key.',
    'Copy the key (starts with sk-ant-) and paste it below.': 'Kopiere den Schlüssel (beginnt mit sk-ant-) und füge ihn unten ein.',
    'Create an API key (starts with AIza) and paste it below.': 'Erstelle einen API-Schlüssel (beginnt mit AIza) und füge ihn unten ein.',
    'The device relays the call (Google has no browser access).': 'Das Gerät leitet den Aufruf weiter (Google hat keinen Browser-Zugriff).',
    'Create an API key (starts with gsk_) and paste it below.': 'Erstelle einen API-Schlüssel (beginnt mit gsk_) und füge ihn unten ein.',
    'Connect ': 'Verbinde ',
    'Your key stays on the device': 'Dein Schlüssel bleibt auf dem Gerät',
    'Model': 'Modell',
    '{F}: too long for the device (at most {N} characters).': '{F}: zu lang für das Gerät (höchstens {N} Zeichen).',
    'Key rejected by {H}: check you copied all of it.': 'Schlüssel von {H} abgelehnt: prüfe, ob du ihn vollständig kopiert hast.',
    '{H} doesn’t know the model “{M}”: pick one from the list (Test fills it) or check the name.': '{H} kennt das Modell „{M}“ nicht: wähle eins aus der Liste (Testen füllt sie) oder prüfe den Namen.',
    'OpenAI-compatible': 'OpenAI-kompatibel',
    'OpenRouter, Together, DeepSeek, Mistral, OpenAI or your own server: address, model and key.': 'OpenRouter, Together, DeepSeek, Mistral, OpenAI oder dein eigener Server: Adresse, Modell und Schlüssel.',
    'Connect an OpenAI-compatible service': 'Einen OpenAI-kompatiblen Dienst verbinden',
    'Address, model and key stay on the device': 'Adresse, Modell und Schlüssel bleiben auf dem Gerät',
    'Copy the API base URL from your service’s docs (it usually ends in /v1).': 'Kopiere die API-Basis-URL aus der Doku deines Dienstes (sie endet meist auf /v1).',
    'Create an API key there and paste it below.': 'Erstelle dort einen API-Schlüssel und füge ihn unten ein.',
    'Press Test: the models the service offers appear in the list.': 'Drücke Testen: die Modelle des Dienstes erscheinen in der Liste.',
    'Address': 'Adresse',
    'model name': 'Modellname',
    'Not a valid address: type the service’s base URL, e.g. https://openrouter.ai/api/v1.': 'Keine gültige Adresse: gib die Basis-URL des Dienstes ein, z. B. https://openrouter.ai/api/v1.',
    'Use an https:// address: over http the key would travel in clear text.': 'Nutze eine https://-Adresse: über http ginge der Schlüssel unverschlüsselt.',
    'Type only the base address, without /chat/completions.': 'Gib nur die Basisadresse ein, ohne /chat/completions.',
    'Can’t reach this address from the browser or through the device. Check it (it usually ends in /v1) and the network.': 'Diese Adresse ist weder vom Browser noch über das Gerät erreichbar. Prüfe sie (sie endet meist auf /v1) und das Netz.',
    'The server doesn’t list its models: type the model name.': 'Der Server listet seine Modelle nicht: gib den Modellnamen ein.',
    '✓ Works — called straight from the browser.': '✓ Funktioniert — direkt vom Browser aufgerufen.',
    '✓ Works — through the device (the service refuses browser calls).': '✓ Funktioniert — über das Gerät (der Dienst lehnt Browser-Aufrufe ab).',
    'The test failed. Save anyway?': 'Der Test ist fehlgeschlagen. Trotzdem speichern?',
    'Type the model name.': 'Gib den Modellnamen ein.',
    'Stored only on your device, never logged. With Claude the key stays in <b>your browser</b> and talks directly to Anthropic — the device isn’t loaded.': 'Nur auf deinem Gerät gespeichert, nie protokolliert. Mit Claude bleibt der Schlüssel in <b>deinem Browser</b> und spricht direkt mit Anthropic — das Gerät wird nicht belastet.',
    'Skip AI setup? You can do it later in Settings ▸ AI.': 'KI-Einrichtung überspringen? Du kannst sie später unter Einstellungen ▸ KI vornehmen.',
    'Set up later': 'Später',
    '← Back': '← Zurück',
    'Next →': 'Weiter →',
    'Start using NucleoOS': 'NucleoOS nutzen',
  },
  zh: {
    'Choose your language': '选择语言',
    'You can change it anytime in Settings ▸ Appearance': '随时可以在「设置 ▸ 外观」中更改',
    'Welcome to NucleoOS': '欢迎使用 NucleoOS',
    'A web-native OS that lives on your device': '一个运行在你设备上的 Web 原生操作系统',
    'NucleoOS turns your device into a tiny computer you drive from this browser. At its heart is <b>ANIMA</b> — an assistant whose brain runs <b>offline, on the device itself</b>.': 'NucleoOS 把你的设备变成一台小电脑，通过这个浏览器操作。它的核心是 <b>ANIMA</b>——一个大脑<b>离线运行在设备本身</b>上的助手。',
    'Offline brain': '离线大脑',
    'Answers, reasoning and memory — no cloud needed.': '回答、推理和记忆——无需云端。',
    'Optional cloud': '可选云端',
    'Add a Claude key for deeper understanding & verification.': '添加 Claude 密钥，获得更深入的理解和核实。',
    'Your keys, your device': '你的密钥，你的设备',
    'Keys stay on the device; cloud calls go straight from your browser.': '密钥保存在设备上；云端请求直接从你的浏览器发出。',
    'Light on the device': '设备负担轻',
    'The heavy AI work runs in your browser, not the chip.': '繁重的 AI 运算在你的浏览器中进行，而不是在芯片上。',
    'Two minutes now and ANIMA is ready everywhere in the OS.': '现在花两分钟，ANIMA 就能在整个系统中随时可用。',
    'NucleoOS is served by the device over your network — no app store. <b>Install it</b> to get a full-screen app icon and instant launch.': 'NucleoOS 由设备通过你的网络提供——无需应用商店。<b>安装它</b>，即可获得全屏应用图标并快速启动。',
    'Keep the device on the same Wi-Fi as this computer or phone.': '让设备与这台电脑或手机连接同一个 Wi-Fi。',
    'Desktop (Chrome/Edge): click the ⊕ / install icon in the address bar.': '电脑（Chrome/Edge）：点击地址栏中的 ⊕ / 安装图标。',
    'iPhone/iPad (Safari): Share → “Add to Home Screen”.': 'iPhone/iPad（Safari）：分享 → 「添加到主屏幕」。',
    'Android (Chrome): menu ⋮ → “Install app”.': 'Android（Chrome）：菜单 ⋮ → 「安装应用」。',
    'Tip: bookmark the device IP so you can always get back to NucleoOS.': '提示：把设备的 IP 加入书签，随时都能回到 NucleoOS。',
    'Install NucleoOS': '安装 NucleoOS',
    'Add it like a native app': '像原生应用一样添加',
    '⤓ Install app': '⤓ 安装应用',
    'RECOMMENDED': '推荐',
    'Choose your AI': '选择你的 AI',
    'You can change this anytime in Settings ▸ AI': '随时可以在「设置 ▸ AI」中更改',
    'Best understanding. Runs in your browser — zero load on the device.': '理解能力最强。在你的浏览器中运行——设备零负担。',
    'Fast & free tier. OpenAI-compatible (Llama models).': '速度快，有免费额度。兼容 OpenAI（Llama 模型）。',
    'Strong, generous free tier. Routed via the device proxy (no browser CORS).': '能力强，免费额度充足。通过设备代理转发（无浏览器 CORS 限制）。',
    'Offline only': '仅离线',
    'No key. ANIMA still answers from its on-device brain, weather & Wikipedia.': '无需密钥。ANIMA 仍可依靠设备上的大脑、天气和维基百科回答。',
    'Paste a key first.': '请先粘贴密钥。',
    'testing…': '正在测试…',
    '✓ Key works!': '✓ 密钥可用！',
    '✗ Key rejected.': '✗ 密钥被拒绝。',
    'Test': '测试',
    'Paste your key.': '请粘贴你的密钥。',
    'That doesn’t look like a ': '这看起来不像 ',
    ' key. Save anyway?': ' 密钥。仍要保存吗？',
    'saving…': '正在保存…',
    'detecting plan…': '正在检测套餐…',
    '✓ Saved — ANIMA is ready.': '✓ 已保存——ANIMA 已就绪。',
    'Pair this browser first.': '请先配对此浏览器。',
    'Save failed.': '保存失败。',
    'Save & finish': '保存并完成',
    'Go to ': '前往 ',
    'Open API Keys → Create Key.': '打开 API Keys → Create Key。',
    'Copy the key (starts with sk-ant-) and paste it below.': '复制密钥（以 sk-ant- 开头），粘贴到下方。',
    'Create an API key (starts with AIza) and paste it below.': '创建一个 API 密钥（以 AIza 开头），粘贴到下方。',
    'The device relays the call (Google has no browser access).': '由设备转发请求（Google 不支持从浏览器直接访问）。',
    'Create an API key (starts with gsk_) and paste it below.': '创建一个 API 密钥（以 gsk_ 开头），粘贴到下方。',
    'Connect ': '连接 ',
    'Your key stays on the device': '你的密钥保存在设备上',
    'Model': '模型',
    '{F}: too long for the device (at most {N} characters).': '{F}：对设备来说太长（最多 {N} 个字符）。',
    'Key rejected by {H}: check you copied all of it.': '{H} 拒绝了该密钥：请检查是否完整复制。',
    '{H} doesn’t know the model “{M}”: pick one from the list (Test fills it) or check the name.': '{H} 不认识模型“{M}”：请从列表中选择（点击“测试”会填充列表）或检查名称。',
    'OpenAI-compatible': 'OpenAI 兼容',
    'OpenRouter, Together, DeepSeek, Mistral, OpenAI or your own server: address, model and key.': 'OpenRouter、Together、DeepSeek、Mistral、OpenAI 或你自己的服务器：地址、模型和密钥。',
    'Connect an OpenAI-compatible service': '连接 OpenAI 兼容服务',
    'Address, model and key stay on the device': '地址、模型和密钥保存在设备上',
    'Copy the API base URL from your service’s docs (it usually ends in /v1).': '从服务的文档中复制 API 基础地址（通常以 /v1 结尾）。',
    'Create an API key there and paste it below.': '在那里创建一个 API 密钥并粘贴到下方。',
    'Press Test: the models the service offers appear in the list.': '点击“测试”：服务提供的模型会出现在列表中。',
    'Address': '地址',
    'model name': '模型名称',
    'Not a valid address: type the service’s base URL, e.g. https://openrouter.ai/api/v1.': '地址无效：请输入服务的基础 URL，例如 https://openrouter.ai/api/v1。',
    'Use an https:// address: over http the key would travel in clear text.': '请使用 https:// 地址：通过 http 密钥会以明文传输。',
    'Type only the base address, without /chat/completions.': '只需输入基础地址，不要 /chat/completions。',
    'Can’t reach this address from the browser or through the device. Check it (it usually ends in /v1) and the network.': '无法从浏览器或通过设备访问此地址。请检查地址（通常以 /v1 结尾）和网络。',
    'The server doesn’t list its models: type the model name.': '服务器没有列出模型：请输入模型名称。',
    '✓ Works — called straight from the browser.': '✓ 可用 — 由浏览器直接调用。',
    '✓ Works — through the device (the service refuses browser calls).': '✓ 可用 — 通过设备（该服务不接受浏览器调用）。',
    'The test failed. Save anyway?': '测试失败。仍要保存吗？',
    'Type the model name.': '请输入模型名称。',
    'Stored only on your device, never logged. With Claude the key stays in <b>your browser</b> and talks directly to Anthropic — the device isn’t loaded.': '仅保存在你的设备上，从不写入日志。使用 Claude 时，密钥保存在<b>你的浏览器</b>中并直接与 Anthropic 通信——不会占用设备资源。',
    'Skip AI setup? You can do it later in Settings ▸ AI.': '跳过 AI 设置？之后可以在「设置 ▸ AI」中完成。',
    'Set up later': '稍后设置',
    '← Back': '← 返回',
    'Next →': '下一步 →',
    'Start using NucleoOS': '开始使用 NucleoOS',
  },
};
// A table may key a string by the English text without its leading pictograph: the English one is kept in front.
const LEAD = /^(\p{Extended_Pictographic}️?\s*)(.+)$/su;
const TR = (it, en) => {
  const l = lang(); if (l === 'it') return it; if (l === 'en') return en;
  const tb = L10N[l]; if (!tb) return en;
  if (tb[en] != null) return tb[en];
  const m = LEAD.exec(en);
  return m && tb[m[2]] != null ? m[1] + tb[m[2]] : en;
};

// tiny DOM builder (XSS-safe: text via textContent, no innerHTML of user data)
function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  if (props) for (const k in props) {
    if (k === 'class') e.className = props[k];
    else if (k === 'html') e.innerHTML = props[k];           // only for trusted static strings
    else if (k === 'on') for (const ev in props.on) e.addEventListener(ev, props.on[ev]);
    else if (k in e) e[k] = props[k]; else e.setAttribute(k, props[k]);
  }
  for (const kid of kids) if (kid != null) e.append(kid.nodeType ? kid : document.createTextNode(kid));
  return e;
}

export async function ensureOnboarding(opts = {}) {
  host = opts;
  const acc = await accountsToSet();
  // A browser that already went through the wizard (a device updated to accounts) sees only the accounts step.
  if (acc) { let seen = false; try { seen = localStorage.getItem(ONB_KEY) === '1'; } catch {} return runWizard(acc, seen); }
  try {
    if (localStorage.getItem(ONB_KEY) === '1') return;
    // A device that has its own first-run (the Handheld's setup, the browser edition's Configurazione) says
    // so here: its answer wins, or this wizard would ask again — and ask for an AI key in the browser where
    // that edition keeps keys on its server. Where the route does not exist (the Cardputer: 404) nothing changes.
    try {
      const r = await fetch('/api/onboard', { cache: 'no-store' });
      if (r.ok && (await r.json()).onboarded === true) { localStorage.setItem(ONB_KEY, '1'); return; }
    } catch {}
    const c = await AI.caps();
    if (c && c.hasKey) { localStorage.setItem(ONB_KEY, '1'); return; }   // already set up (e.g. another browser)
  } catch {}
  return runWizard();
}

function runWizard(acc = null, accountOnly = false) {
  return new Promise((resolve) => {
    const state = { step: 0, provider: 'anthropic', model: AI.PROVIDERS.anthropic.def, key: '', exec: 'browser', many: false };
    const STEPS = accountOnly ? ['account'] : acc ? ['language', 'account', 'welcome', 'apps', 'install', 'provider', 'key'] : ['language', 'welcome', 'apps', 'install', 'provider', 'key'];
    const P = (k) => (APPS[lang()] || APPS.en)[k];
    const nextAfterAccount = () => { if (accountOnly) done(); else { state.step++; render(); } };
    const A = (k) => (ACC[lang()] || ACC.en)[k];

    const card = h('div', { id: 'nob-card' });
    const scrim = h('div', { id: 'nob-scrim' }, card);
    const done = () => {
      localStorage.setItem(ONB_KEY, '1'); scrim.remove(); resolve();
      if (typeof host.onDone === 'function') host.onDone();
      if (state.openStore && typeof host.openApp === 'function') host.openApp('store');
    };

    function header(title, sub) {
      return h('div', { class: 'nob-hd' },
        h('div', { class: 'nob-logo' }, '◆'),
        h('div', null, h('h1', null, title), h('p', { class: 'nob-sub' }, sub)));
    }
    function dots() {
      const total = state.provider === 'offline' ? STEPS.length - 1 : STEPS.length;
      const wrap = h('div', { class: 'nob-dots' });
      for (let i = 0; i < total; i++) wrap.append(h('i', { class: i === state.step ? 'on' : '' }));
      return wrap;
    }

    function render() {
      card.textContent = '';
      if (STEPS[state.step] === 'language') renderLanguage();
      else if (STEPS[state.step] === 'account') renderAccount();
      else if (STEPS[state.step] === 'welcome') renderWelcome();
      else if (STEPS[state.step] === 'apps') renderApps();
      else if (STEPS[state.step] === 'install') renderInstall();
      else if (STEPS[state.step] === 'provider') renderProvider();
      else if (state.provider === 'custom') renderCustomKey();
      else renderKey();
    }

    // ---- step 0: language ----------------------------------------------------
    // A modern OS asks for the language first. The choice flows through the centralized i18n engine
    // (window.NucleoI18N) so it persists OS-wide; the rest of the wizard then renders in that language.
    function renderLanguage() {
      const langs = (window.NucleoI18N && window.NucleoI18N.LANGS)
        || [{ code: 'it', label: 'Italiano', flag: '🇮🇹' }, { code: 'en', label: 'English', flag: '🇬🇧' },
            { code: 'es', label: 'Español', flag: '🇪🇸' }, { code: 'fr', label: 'Français', flag: '🇫🇷' }, { code: 'de', label: 'Deutsch', flag: '🇩🇪' }];
      const cur = lang();
      // Re-render AFTER the switch: setLang loads the catalogs asynchronously, and an immediate
      // render still read the previous language.
      const pick = async (code) => {
        if (window.NucleoI18N) { try { await window.NucleoI18N.setLang(code); } catch {} }
        else { try { localStorage.setItem('anima.lang', code); } catch {} }
        render();
      };
      card.append(
        header(TR('Scegli la lingua', 'Choose your language'),
               TR('Puoi cambiarla quando vuoi in Impostazioni ▸ Aspetto', 'You can change it anytime in Settings ▸ Appearance')),
        h('div', { class: 'nob-body' }, h('div', { class: 'nob-choices' },
          ...langs.map((l) => h('button', { class: 'nob-choice' + (cur === l.code ? ' sel' : ''),
            on: { click: () => pick(l.code) } },
            h('div', { class: 'cic' }, l.flag),
            h('div', null, h('div', { class: 'ct' }, l.label)))))),
        footer({ next: true }));
    }

    // ---- accounts (only where the device can have them and none exists) -----
    function renderAccount() {
      if (!state.many) {
        card.append(header(A('title'), A('sub')),
          h('div', { class: 'nob-body' }, h('div', { class: 'nob-choices' },
            h('button', { class: 'nob-choice', on: { click: () => { try { localStorage.setItem(ACC_SKIP, '1'); } catch {} nextAfterAccount(); } } },
              h('div', null, h('div', { class: 'ct' }, A('me')), h('div', { class: 'cd' }, A('meD')))),
            h('button', { class: 'nob-choice', on: { click: () => { state.many = true; render(); } } },
              h('div', null, h('div', { class: 'ct' }, A('many')), h('div', { class: 'cd' }, A('manyD')))))),
          footer({ back: !accountOnly }));
        return;
      }
      const field = (type, label, auto) => h('input', { class: 'nob-input', type, placeholder: label, 'aria-label': label, autocomplete: auto });
      const name = field('text', A('name'), 'username'), pw = field('password', A('pw'), 'new-password'), again = field('password', A('again'), 'new-password');
      const pin = acc.physical ? null : field('text', A('pin'), 'off');
      const msg = h('div', { class: 'nob-note', role: 'status', 'aria-live': 'polite' });
      const create = h('button', { class: 'nob-btn pri', on: { click: async () => {
        if (!name.value.trim() || !pw.value) return;
        if (pw.value !== again.value) { msg.textContent = A('mismatch'); return; }
        create.disabled = true;
        const r = await User.setup(name.value.trim(), pw.value, pin ? pin.value.trim() : '');
        create.disabled = false;
        if (!r.ok) {
          const e = r.error;
          msg.textContent = A(e === 'weak_password' ? 'weak' : e === 'proof_required' ? 'proof' : e === 'name_taken' || e === 'bad_request' ? 'taken' : 'fail');
          return;
        }
        try { localStorage.removeItem(ACC_SKIP); } catch {}
        await User.switchTo(r.user.id);
        nextAfterAccount();
      } } }, A('go'));
      card.append(header(A('admin'), A('adminSub')),
        h('div', { class: 'nob-body' }, name, pw, again, pin, msg),
        h('div', { class: 'nob-ft' }, dots(), h('div', { class: 'nob-btns' },
          h('button', { class: 'nob-btn', on: { click: () => { state.many = false; render(); } } }, TR('← Indietro', '← Back')), create)));
      name.focus();
    }

    // ---- step 1: welcome -----------------------------------------------------
    function renderWelcome() {
      card.append(
        header(TR('Benvenuto in NucleoOS', 'Welcome to NucleoOS'),
               TR('Un OS web-native che vive sul tuo dispositivo', 'A web-native OS that lives on your device')),
        h('div', { class: 'nob-body' },
          h('p', { html: TR(
            'NucleoOS trasforma il tuo dispositivo in un piccolo computer che guidi da questo browser. Al centro c’è <b>ANIMA</b> — un assistente il cui cervello gira <b>offline, sul dispositivo stesso</b>.',
            'NucleoOS turns your device into a tiny computer you drive from this browser. At its heart is <b>ANIMA</b> — an assistant whose brain runs <b>offline, on the device itself</b>.') }),
          h('div', { class: 'nob-feat' },
            feat('🧠', TR('Cervello offline', 'Offline brain'), TR('Risposte, ragionamento e memoria — senza cloud.', 'Answers, reasoning and memory — no cloud needed.')),
            feat('☁', TR('Cloud opzionale', 'Optional cloud'), TR('Aggiungi una chiave Claude per comprensione e verifica migliori.', 'Add a Claude key for deeper understanding & verification.')),
            feat('🔒', TR('Le tue chiavi, il tuo device', 'Your keys, your device'), TR('Le chiavi restano sul dispositivo; le chiamate cloud partono dal tuo browser.', 'Keys stay on the device; cloud calls go straight from your browser.')),
            feat('⚡', TR('Leggero sul dispositivo', 'Light on the device'), TR('Il lavoro pesante dell’IA gira nel browser, non sul chip.', 'The heavy AI work runs in your browser, not the chip.'))),
          h('p', { class: 'nob-note', html: TR('✨ Due minuti adesso e ANIMA è pronta ovunque nell’OS.', '✨ Two minutes now and ANIMA is ready everywhere in the OS.') })),
        footer({ next: true, skip: true }));
    }
    function feat(ic, t, d) {
      return h('div', null, h('div', { class: 'ic' }, ic), h('div', { class: 't' }, t), h('div', { class: 'd' }, d));
    }

    // ---- your apps: Start, the desktop, the Store ---------------------------
    function renderApps() {
      const point = (title, text) => h('div', null, h('div', { class: 't' }, title), h('div', { class: 'd' }, text));
      const go = h('button', { class: 'nob-btn' + (state.openStore ? ' pri' : ''), on: { click: () => {
        state.openStore = !state.openStore; render();
      } } }, state.openStore ? P('opened') : P('open'));
      card.append(header(P('title'), P('sub')),
        h('div', { class: 'nob-body' }, h('div', { class: 'nob-feat one' },
          point(P('start'), P('startD')), point(P('desk'), P('deskD')), point(P('store'), P('storeD'))), go),
        footer({ back: true, next: true }));
    }

    // ---- step 1: install NucleoOS -------------------------------------------
    // PWA install exists ONLY in a secure context: on plain http://<ip> the
    // browser never fires beforeinstallprompt and the ⊕ icon never appears, so
    // the Install button is offered only in a secure context. (Pointing an http
    // user at https://<device>:8443 works only where the server has a TLS port —
    // the Handheld edition — so it is not wired here until that is a capability.)
    function renderInstall() {
      const prompt = window.__nucleoInstallPrompt;
      const secure = !!window.isSecureContext;   // beforeinstallprompt only fires in a secure context
      const body = h('div', { class: 'nob-body' },
        h('p', { html: TR(
          'NucleoOS è servito dal dispositivo sulla tua rete — niente app store. <b>Installalo</b> per avere un’icona a tutto schermo e avvio immediato.',
          'NucleoOS is served by the device over your network — no app store. <b>Install it</b> to get a full-screen app icon and instant launch.') }),
        h('ol', { class: 'nob-steps' },
          li(TR('Tieni il dispositivo sulla stessa Wi-Fi di questo computer o telefono.', 'Keep the device on the same Wi-Fi as this computer or phone.')),
          li(TR('Desktop (Chrome/Edge): clicca l’icona ⊕ / installa nella barra indirizzi.', 'Desktop (Chrome/Edge): click the ⊕ / install icon in the address bar.')),
          li(TR('iPhone/iPad (Safari): Condividi → “Aggiungi a Home”.', 'iPhone/iPad (Safari): Share → “Add to Home Screen”.')),
          li(TR('Android (Chrome): menu ⋮ → “Installa app”.', 'Android (Chrome): menu ⋮ → “Install app”.'))),
        h('p', { class: 'nob-note', html: TR('💡 Suggerimento: salva l’IP del dispositivo per tornare sempre a NucleoOS.', '💡 Tip: bookmark the device IP so you can always get back to NucleoOS.') }));
      card.append(header(TR('Installa NucleoOS', 'Install NucleoOS'), TR('Aggiungilo come un’app nativa', 'Add it like a native app')), body);
      const extra = [];
      if (secure && prompt) extra.push(h('button', { class: 'nob-btn', on: { click: async () => { try { prompt.prompt(); await prompt.userChoice; } catch {} window.__nucleoInstallPrompt = null; } } }, TR('⤓ Installa app', '⤓ Install app')));
      card.append(footer({ back: true, next: true, skip: true, extra }));
    }
    function li(...kids) { return h('li', null, ...kids); }

    // ---- step 2: choose provider --------------------------------------------
    function renderProvider() {
      const mk = (id, ic, title, desc, reco) => h('button', { class: 'nob-choice' + (state.provider === id ? ' sel' : ''), 'data-id': id,
        on: { click: () => { state.provider = id; render(); } } },
        h('div', { class: 'cic' }, ic),
        h('div', null, h('div', { class: 'ct', html: title + (reco ? '<span class="reco">' + TR('CONSIGLIATO', 'RECOMMENDED') + '</span>' : '') }), h('div', { class: 'cd' }, desc)));
      card.append(
        header(TR('Scegli la tua IA', 'Choose your AI'), TR('Puoi cambiarlo quando vuoi in Impostazioni ▸ IA', 'You can change this anytime in Settings ▸ AI')),
        h('div', { class: 'nob-body' }, h('div', { class: 'nob-choices' },
          mk('anthropic', '🟣', 'Claude (Anthropic)', TR('Comprensione al top. Gira nel browser — zero carico sul dispositivo.', 'Best understanding. Runs in your browser — zero load on the device.'), true),
          mk('openai', '⚡', 'Groq', TR('Veloce e con piano gratuito. OpenAI-compatibile (modelli Llama).', 'Fast & free tier. OpenAI-compatible (Llama models).'), false),
          mk('google', '✨', 'Gemini (Google)', TR('Forte, free tier generoso. Instradato dal proxy del device (niente CORS browser).', 'Strong, generous free tier. Routed via the device proxy (no browser CORS).'), false),
          mk('custom', '⇄', TR('Compatibile OpenAI', 'OpenAI-compatible'), TR('OpenRouter, Together, DeepSeek, Mistral, OpenAI o un tuo server: indirizzo, modello e chiave.', 'OpenRouter, Together, DeepSeek, Mistral, OpenAI or your own server: address, model and key.'), false),
          mk('offline', '🧠', TR('Solo offline', 'Offline only'), TR('Nessuna chiave. ANIMA risponde comunque dal cervello on-device, meteo e Wikipedia.', 'No key. ANIMA still answers from its on-device brain, weather & Wikipedia.'), false))),
        footer({ back: true, next: state.provider !== 'offline', finish: state.provider === 'offline' }));
    }

    // The two key steps share their buttons' words.
    const LBL = { test: () => TR('⚡ Prova', '⚡ Test'), save: () => TR('💾 Salva e finisci', '💾 Save & finish') };

    // ---- step 3: API key -----------------------------------------------------
    function renderKey() {
      const p = AI.providerOf(state.provider);
      if (!state.model || !p.models.some((m) => m[0] === state.model)) state.model = p.def;
      const stat = h('div', { class: 'nob-stat' });
      const input = h('input', { class: 'nob-input', type: 'password', placeholder: p.ph, autocomplete: 'off', spellcheck: 'false' });
      const sel = h('select', { class: 'nob-select' });
      for (const m of p.models) sel.append(h('option', { value: m[0], selected: m[0] === state.model }, AI.modelLabel(m)));
      sel.addEventListener('change', () => { state.model = sel.value; });

      const cfg = () => ({ provider: state.provider, base: p.base, model: sel.value, key: input.value.trim(), version: p.version, exec: 'browser' });
      const setStat = (t, cls) => { stat.textContent = t; stat.className = 'nob-stat' + (cls ? ' ' + cls : ''); };

      const testBtn = h('button', { class: 'nob-btn', on: { click: async () => {
        const k = input.value.trim(); if (!k) { setStat(TR('Incolla prima una chiave.', 'Paste a key first.'), 'err'); return; }
        setStat(TR('provo…', 'testing…')); testBtn.disabled = true;
        try { const ok = await AI.cloudPing(cfg()); setStat(ok ? TR('✓ La chiave funziona!', '✓ Key works!') : TR('✗ Chiave rifiutata.', '✗ Key rejected.'), ok ? 'ok' : 'err'); }
        catch (e) { setStat('✗ ' + String(e.message || e), 'err'); }
        finally { testBtn.disabled = false; }
      } } }, LBL.test());

      const saveBtn = h('button', { class: 'nob-btn pri', on: { click: async () => {
        const k = input.value.trim();
        if (!k) { setStat(TR('Incolla la tua chiave.', 'Paste your key.'), 'err'); return; }
        if (!p.prefix.test(k) && !confirm(TR('Non sembra una chiave ', 'That doesn’t look like a ') + p.label + TR('. Salvo lo stesso?', ' key. Save anyway?'))) return;
        setStat(TR('salvo…', 'saving…')); saveBtn.disabled = true;
        // On top of what the device already holds: the other providers' keys, the speech and vision
        // settings stay (a saved key comes back as a placeholder and is kept on the device).
        const held = await AI.readTeacher({ fresh: true }).catch(() => null);
        const full = () => Object.assign({}, (held && !held.unpaired) ? held : {}, cfg());
        const res = await AI.writeTeacher(full());
        saveBtn.disabled = false;
        if (res === true && state.provider === 'google') {
          // Detect the Gemini plan (real models + paid/free tier) and re-save with the recommended model + tier.
          // Best-effort: if it can't reach the API it just keeps the Flash default and finishes anyway.
          setStat(TR('rilevo il piano…', 'detecting plan…'));
          try {
            const c = await AI.calibrateGemini({ base: p.base, key: k });
            const d = full(); if (!c.models.includes(d.model)) d.model = c.recommended; d.geminiTier = c.tier;
            await AI.writeTeacher(d);
            setStat('✓ ' + AI.geminiTierLabel(c.tier, lang()), 'ok');
          } catch { setStat(TR('✓ Salvata — ANIMA è pronta.', '✓ Saved — ANIMA is ready.'), 'ok'); }
          setTimeout(done, 1000); return;
        }
        if (res === true) { setStat(TR('✓ Salvata — ANIMA è pronta.', '✓ Saved — ANIMA is ready.'), 'ok'); setTimeout(done, 650); }
        else if (res === 'unpaired') setStat(TR('Accoppia prima il browser.', 'Pair this browser first.'), 'err');
        else setStat(TR('Salvataggio fallito.', 'Save failed.'), 'err');
      } } }, LBL.save());

      const where = state.provider === 'anthropic'
        ? [li(TR('Vai su ', 'Go to '), h('a', { href: 'https://console.anthropic.com/settings/keys', target: '_blank', rel: 'noopener' }, 'console.anthropic.com')),
           li(TR('Apri API Keys → Create Key.', 'Open API Keys → Create Key.')),
           li(TR('Copia la chiave (inizia con sk-ant-) e incollala qui sotto.', 'Copy the key (starts with sk-ant-) and paste it below.'))]
        : state.provider === 'google'
        ? [li(TR('Vai su ', 'Go to '), h('a', { href: 'https://aistudio.google.com/apikey', target: '_blank', rel: 'noopener' }, 'aistudio.google.com/apikey')),
           li(TR('Crea una API key (inizia con AIza) e incollala qui sotto.', 'Create an API key (starts with AIza) and paste it below.')),
           li(TR('Il dispositivo inoltra la chiamata (Google non è accessibile dal browser).', 'The device relays the call (Google has no browser access).'))]
        : [li(TR('Vai su ', 'Go to '), h('a', { href: 'https://console.groq.com/keys', target: '_blank', rel: 'noopener' }, 'console.groq.com')),
           li(TR('Crea una API key (inizia con gsk_) e incollala qui sotto.', 'Create an API key (starts with gsk_) and paste it below.'))];

      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); saveBtn.click(); } });

      card.append(
        header(TR('Collega ', 'Connect ') + p.label, TR('La chiave resta sul dispositivo', 'Your key stays on the device')),
        h('div', { class: 'nob-body' },
          h('ol', { class: 'nob-steps' }, ...where),
          h('div', { class: 'nob-field' },
            h('label', null, TR('Modello', 'Model')), sel,
            h('label', null, 'API key'), input,
            h('div', { class: 'nob-row' }, testBtn), stat),
          h('div', { class: 'nob-note', html: '🔒 ' + TR(
            'Salvata solo sul tuo dispositivo, mai nei log. Con Claude la chiave resta nel <b>tuo browser</b> e parla direttamente con Anthropic — il dispositivo non viene caricato.',
            'Stored only on your device, never logged. With Claude the key stays in <b>your browser</b> and talks directly to Anthropic — the device isn’t loaded.') })),
        footer({ back: true, saveSlot: saveBtn }));
    }

    // ---- step 3b: an OpenAI-compatible service (address + model + key) --------
    // Any service that speaks the OpenAI API: nothing is assumed about the host, so the user gives all three. Test asks
    // the service for its models and runs one tiny completion, first from the browser and, when the service refuses
    // browser calls, through the device (AI.probeEndpoint); the way that worked is saved with the key (`proxy`).
    function renderCustomKey() {
      const stat = h('div', { class: 'nob-stat', role: 'status', 'aria-live': 'polite' });
      const setStat = (t, cls) => { stat.textContent = t; stat.className = 'nob-stat' + (cls ? ' ' + cls : ''); };
      const base = h('input', { class: 'nob-input', type: 'url', placeholder: 'https://openrouter.ai/api/v1', autocomplete: 'off', spellcheck: 'false', 'aria-label': TR('Indirizzo', 'Address') });
      const listId = 'nob-models';
      const model = h('input', { class: 'nob-input', type: 'text', placeholder: TR('nome del modello', 'model name'), autocomplete: 'off', spellcheck: 'false', 'aria-label': TR('Modello', 'Model') });
      model.setAttribute('list', listId);   // `list` is a read-only property: the attribute links the datalist
      const models = h('datalist', { id: listId });
      const input = h('input', { class: 'nob-input', type: 'password', placeholder: 'sk-…', autocomplete: 'off', spellcheck: 'false', 'aria-label': 'API key' });
      if (state.cbase) base.value = state.cbase;
      if (state.cmodel) model.value = state.cmodel;
      let probed = null;   // { base, ok, proxy, model } of the last test
      base.addEventListener('change', () => { state.cbase = base.value.trim(); probed = null; });
      model.addEventListener('change', () => { state.cmodel = model.value.trim(); });

      // The address as it will be saved, or null after saying what is wrong with it.
      const checkBase = () => {
        const r = AI.normalizeBase(base.value);
        if (r.base && !r.error) { base.value = r.base; return r.base; }
        if (r.error === 'endpoint') { base.value = r.base; setStat(TR('Scrivi solo l’indirizzo base, senza /chat/completions.', 'Type only the base address, without /chat/completions.'), 'err'); }
        else if (r.error === 'insecure') setStat(TR('Serve un indirizzo https://: con http la chiave viaggerebbe in chiaro.', 'Use an https:// address: over http the key would travel in clear text.'), 'err');
        else setStat(TR('Indirizzo non valido: scrivi l’URL base del servizio, per esempio https://openrouter.ai/api/v1.', 'Not a valid address: type the service’s base URL, e.g. https://openrouter.ai/api/v1.'), 'err');
        return null;
      };
      const say = (r) => {
        if (r.ok) setStat(r.proxy ? TR('✓ Funziona — tramite il dispositivo (il servizio non accetta chiamate dal browser).', '✓ Works — through the device (the service refuses browser calls).')
          : TR('✓ Funziona — chiamato direttamente dal browser.', '✓ Works — called straight from the browser.'), 'ok');
        else if (r.kind === 'no_model') setStat(TR('Il server non elenca i suoi modelli: scrivi il nome del modello.', 'The server doesn’t list its models: type the model name.'), 'err');
        else if (r.kind === 'network') setStat(TR('Non raggiungo questo indirizzo né dal browser né tramite il dispositivo. Controllalo (di solito finisce con /v1) e controlla la rete.', 'Can’t reach this address from the browser or through the device. Check it (it usually ends in /v1) and the network.'), 'err');
        else if (r.kind === 'auth') setStat('✗ ' + TR('Chiave rifiutata da {H}: controlla di averla copiata intera.', 'Key rejected by {H}: check you copied all of it.').replace('{H}', host()), 'err');
        else if (r.kind === 'model') setStat('✗ ' + TR('{H} non conosce il modello «{M}»: sceglilo dall’elenco (Prova lo riempie) o controlla il nome.', '{H} doesn’t know the model “{M}”: pick one from the list (Test fills it) or check the name.')
          .replace('{H}', host()).replace('{M}', (r.error && r.error.model) || model.value.trim()), 'err');
        else setStat('✗ ' + AI.explainAiError(r.error, lang(), { label: host() }), 'err');
      };
      const host = () => { try { return new URL(base.value).host; } catch { return base.value; } };
      const probe = async () => {
        const b = checkBase(); if (!b) return null;
        const k = input.value.trim(); if (!k) { setStat(TR('Incolla prima una chiave.', 'Paste a key first.'), 'err'); return null; }
        setStat(TR('provo…', 'testing…'));
        const r = await AI.probeEndpoint({ base: b, key: k, model: model.value.trim() });
        probed = Object.assign({ base: b }, r);
        if (r.models && r.models.length) {
          models.textContent = '';
          for (const id of [...new Set(r.models)].sort()) models.append(h('option', { value: id }));
          if (!model.value.trim() && r.model) { model.value = r.model; state.cmodel = r.model; }
        }
        say(r);
        return r;
      };

      const testBtn = h('button', { class: 'nob-btn', on: { click: async () => { testBtn.disabled = true; try { await probe(); } finally { testBtn.disabled = false; } } } }, LBL.test());
      const saveBtn = h('button', { class: 'nob-btn pri', on: { click: async () => {
        const b = checkBase(); if (!b) return;
        const k = input.value.trim(); if (!k) { setStat(TR('Incolla la tua chiave.', 'Paste your key.'), 'err'); return; }
        const long = AI.deviceFieldTooLong({ base: b, key: k, model: model.value.trim() });
        if (long) {
          const F = { base: TR('Indirizzo', 'Address'), key: 'API key', model: TR('Modello', 'Model') }[long.field];
          setStat(TR('{F}: troppo lungo per il dispositivo (al massimo {N} caratteri).', '{F}: too long for the device (at most {N} characters).').replace('{F}', F).replace('{N}', String(long.max)), 'err');
          return;
        }
        saveBtn.disabled = true;
        try {
          let r = probed && probed.base === b && probed.ok ? probed : await probe();
          if (!r) return;
          if (!model.value.trim()) { setStat(TR('Scrivi il nome del modello.', 'Type the model name.'), 'err'); return; }
          if (!r.ok && !confirm(TR('La prova non è riuscita. Salvo lo stesso?', 'The test failed. Save anyway?'))) return;
          setStat(TR('salvo…', 'saving…'));
          const held = await AI.readTeacher({ fresh: true }).catch(() => null);
          const cfg = Object.assign({}, (held && !held.unpaired) ? held : {},
            { provider: 'custom', base: b, model: model.value.trim(), key: k, version: '', exec: 'browser', effort: '', proxy: !!(r.ok && r.proxy) });
          const res = await AI.writeTeacher(cfg);
          if (res === true) { setStat(TR('✓ Salvata — ANIMA è pronta.', '✓ Saved — ANIMA is ready.'), 'ok'); setTimeout(done, 650); }
          else if (res === 'unpaired') setStat(TR('Accoppia prima il browser.', 'Pair this browser first.'), 'err');
          else setStat(TR('Salvataggio fallito.', 'Save failed.'), 'err');
        } finally { saveBtn.disabled = false; }
      } } }, LBL.save());
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); saveBtn.click(); } });

      card.append(
        header(TR('Collega un servizio compatibile OpenAI', 'Connect an OpenAI-compatible service'), TR('Indirizzo, modello e chiave restano sul dispositivo', 'Address, model and key stay on the device')),
        h('div', { class: 'nob-body' },
          h('ol', { class: 'nob-steps' },
            li(TR('Copia l’URL base delle API dalla documentazione del servizio (di solito finisce con /v1).', 'Copy the API base URL from your service’s docs (it usually ends in /v1).')),
            li(TR('Crea lì una chiave API e incollala qui sotto.', 'Create an API key there and paste it below.')),
            li(TR('Premi Prova: i modelli del servizio compaiono nell’elenco.', 'Press Test: the models the service offers appear in the list.'))),
          h('div', { class: 'nob-field' },
            h('label', null, TR('Indirizzo', 'Address')), base,
            h('label', null, 'API key'), input,
            h('label', null, TR('Modello', 'Model')), model, models,
            h('div', { class: 'nob-row' }, testBtn), stat)),
        footer({ back: true, saveSlot: saveBtn }));
      base.focus();
    }

    // ---- footer --------------------------------------------------------------
    function footer(opts) {
      const btns = h('div', { class: 'nob-btns' });
      if (opts.extra) for (const e of opts.extra) btns.append(e);
      if (opts.skip) btns.append(h('button', { class: 'nob-btn ghost', on: { click: () => { if (confirm(TR('Salto la configurazione IA? Puoi farla dopo in Impostazioni ▸ IA.', 'Skip AI setup? You can do it later in Settings ▸ AI.'))) done(); } } }, TR('Più tardi', 'Set up later')));
      if (opts.back) btns.append(h('button', { class: 'nob-btn', on: { click: () => { state.step = Math.max(0, state.step - 1); render(); } } }, TR('← Indietro', '← Back')));
      if (opts.saveSlot) btns.append(opts.saveSlot);
      if (opts.next) btns.append(h('button', { class: 'nob-btn pri', on: { click: () => { state.step++; render(); } } }, TR('Avanti →', 'Next →')));
      if (opts.finish) btns.append(h('button', { class: 'nob-btn pri', on: { click: done } }, TR('Inizia a usare NucleoOS', 'Start using NucleoOS')));
      return h('div', { class: 'nob-ft' }, dots(), btns);
    }

    render();
    document.body.append(scrim);
  });
}
