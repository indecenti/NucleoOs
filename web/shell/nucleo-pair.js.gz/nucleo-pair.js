/* SPDX-License-Identifier: AGPL-3.0-or-later */
// NucleoOS — the pairing dialog, shared by the shell and by any app that hits a
// gated route.
//
// Why this is a module and not shell code: apps run in their own frames, so a
// fetch interceptor in the shell cannot see them. Whoever gets the 401 has to be
// able to ask for the PIN, and every one of them asking in its own words is how
// "pairing_required" turns into "questa app è rotta" in the user's head.
//
// The PIN is not shown in the browser: /api/pair/speak reads it aloud on the
// CONSOLE's speaker. Only someone holding the device hears it — that is the whole
// proof of possession, and it is why the dialog leads with that button.

// on_*: the device is still OPEN and the caller was refused anyway (today: the
// terminal, gated harder because it is a shell). Turning protection on is no
// longer something any browser on the LAN can do — the server used to hand the
// PIN to whoever asked and pair them, which made "open by default" a one-request
// shell. Now it is done from the console itself or over the USB cable, and the
// PIN is read on the console's screen (quick menu › Network) or heard aloud.
import User, { LAST } from './nucleo-user.js';

const T = {
  it: { title: 'Accoppia questo browser', body: 'Per comandare il dispositivo (file, terminale, impostazioni) questo browser deve essere accoppiato una volta.',
        speak: '🔊 Leggi il PIN sul dispositivo', speaking: 'PIN letto sul dispositivo…',
        pin: 'PIN a 6 cifre', ok: 'Accoppia', cancel: 'Annulla', wrong: 'PIN errato', off: 'Accoppiamento non attivo su questo dispositivo',
        done: 'Accoppiato ✓', err: 'Dispositivo non raggiungibile', file: 'Il PIN è anche sullo schermo della console: menu rapido › Rete.',
        throttled: 'Attendi qualche secondo e riprova.', locked: 'Troppi tentativi: riprova tra un minuto.',
        on_title: 'Serve un PIN', on_body: 'Questa funzione apre una shell sul dispositivo, quindi non basta essere sulla stessa rete: serve la protezione con PIN. Per sicurezza si attiva solo dalla console o da un browser collegato col cavo USB (http://192.168.42.1:8080). Poi il PIN compare sullo schermo della console (menu rapido › Rete) e lo inserisci qui.',
        on_btn: 'Attiva', recheck: 'L\'ho attivata: inserisci il PIN',
        on_local: 'Da questo browser non si può attivare: fallo dalla console o via cavo USB, poi premi di nuovo.',
        on_still: 'La protezione non risulta ancora attiva sul dispositivo.',
        on_done: 'Protezione attiva. PIN: {pin}', on_done_nopin: 'Protezione attiva. Il PIN è sullo schermo della console (menu rapido › Rete): servirà agli altri browser.' },
  en: { title: 'Pair this browser', body: 'To drive the device (files, terminal, settings) this browser has to be paired once.',
        speak: '🔊 Read the PIN out on the device', speaking: 'PIN read out on the device…',
        pin: '6-digit PIN', ok: 'Pair', cancel: 'Cancel', wrong: 'Wrong PIN', off: 'Pairing is not enabled on this device',
        done: 'Paired ✓', err: 'Device unreachable', file: 'The PIN is also on the console screen: quick menu › Network.',
        throttled: 'Wait a few seconds and try again.', locked: 'Too many attempts: try again in a minute.',
        on_title: 'A PIN is required', on_body: 'This feature opens a shell on the device, so being on the same network is not enough: PIN protection is needed. For safety it can only be turned on from the console itself or from a browser plugged in over the USB cable (http://192.168.42.1:8080). The PIN then appears on the console screen (quick menu › Network) and you enter it here.',
        on_btn: 'Turn on', recheck: 'I turned it on: enter the PIN',
        on_local: 'It cannot be turned on from this browser: do it from the console or over the USB cable, then press again.',
        on_still: 'Protection is not on yet on the device.',
        on_done: 'Protection on. PIN: {pin}', on_done_nopin: 'Protection on. The PIN is on the console screen (quick menu › Network): other browsers will need it.' },
  es: { title: 'Emparejar este navegador', body: 'Para controlar el dispositivo (archivos, terminal, ajustes) hay que emparejar este navegador una vez.',
        speak: '🔊 Decir el PIN en el dispositivo', speaking: 'PIN dicho en el dispositivo…',
        pin: 'PIN de 6 cifras', ok: 'Emparejar', cancel: 'Cancelar', wrong: 'PIN incorrecto', off: 'El emparejamiento no está activo en este dispositivo',
        done: 'Emparejado ✓', err: 'Dispositivo inalcanzable', file: 'El PIN también está en la pantalla de la consola: menú rápido › Red.',
        throttled: 'Espera unos segundos y vuelve a intentarlo.', locked: 'Demasiados intentos: vuelve a intentarlo en un minuto.',
        on_title: 'Hace falta un PIN', on_body: 'Esta función abre una shell en el dispositivo, así que estar en la misma red no basta: hace falta la protección por PIN. Por seguridad solo se activa desde la consola o desde un navegador conectado por cable USB (http://192.168.42.1:8080). Después el PIN aparece en la pantalla de la consola (menú rápido › Red) y lo introduces aquí.',
        on_btn: 'Activar', recheck: 'Ya la activé: introducir el PIN',
        on_local: 'No se puede activar desde este navegador: hazlo desde la consola o por cable USB y vuelve a pulsar.',
        on_still: 'La protección aún no está activa en el dispositivo.',
        on_done: 'Protección activa. PIN: {pin}', on_done_nopin: 'Protección activa. El PIN está en la pantalla de la consola (menú rápido › Red): lo necesitarán los demás navegadores.' },
  fr: { title: 'Appairer ce navigateur', body: "Pour piloter l'appareil (fichiers, terminal, réglages), ce navigateur doit être appairé une fois.",
        speak: '🔊 Énoncer le PIN sur l\'appareil', speaking: 'PIN énoncé sur l\'appareil…',
        pin: 'PIN à 6 chiffres', ok: 'Appairer', cancel: 'Annuler', wrong: 'PIN incorrect', off: "L'appairage n'est pas actif sur cet appareil",
        done: 'Appairé ✓', err: 'Appareil injoignable', file: "Le PIN est aussi affiché sur l'écran de la console : menu rapide › Réseau.",
        throttled: 'Patientez quelques secondes et réessayez.', locked: 'Trop de tentatives : réessayez dans une minute.',
        on_title: 'Un PIN est nécessaire', on_body: "Cette fonction ouvre un shell sur l'appareil : être sur le même réseau ne suffit pas, il faut la protection par PIN. Par sécurité, elle ne s'active que depuis la console ou depuis un navigateur relié par câble USB (http://192.168.42.1:8080). Le PIN apparaît ensuite sur l'écran de la console (menu rapide › Réseau) et vous le saisissez ici.",
        on_btn: 'Activer', recheck: "Je l'ai activée : saisir le PIN",
        on_local: "Impossible de l'activer depuis ce navigateur : faites-le depuis la console ou par câble USB, puis appuyez à nouveau.",
        on_still: "La protection n'est pas encore active sur l'appareil.",
        on_done: 'Protection active. PIN : {pin}', on_done_nopin: "Protection active. Le PIN est sur l'écran de la console (menu rapide › Réseau) : les autres navigateurs en auront besoin." },
  de: { title: 'Diesen Browser koppeln', body: 'Um das Gerät zu steuern (Dateien, Terminal, Einstellungen), muss dieser Browser einmal gekoppelt werden.',
        speak: '🔊 PIN auf dem Gerät vorlesen', speaking: 'PIN auf dem Gerät vorgelesen…',
        pin: '6-stellige PIN', ok: 'Koppeln', cancel: 'Abbrechen', wrong: 'Falsche PIN', off: 'Kopplung ist auf diesem Gerät nicht aktiv',
        done: 'Gekoppelt ✓', err: 'Gerät nicht erreichbar', file: 'Die PIN steht auch auf dem Bildschirm der Konsole: Schnellmenü › Netzwerk.',
        throttled: 'Warte ein paar Sekunden und versuche es erneut.', locked: 'Zu viele Versuche: versuche es in einer Minute erneut.',
        on_title: 'Eine PIN ist nötig', on_body: 'Diese Funktion öffnet eine Shell auf dem Gerät — im selben Netz zu sein genügt nicht, es braucht den PIN-Schutz. Aus Sicherheitsgründen lässt er sich nur an der Konsole selbst oder in einem per USB-Kabel verbundenen Browser einschalten (http://192.168.42.1:8080). Danach erscheint die PIN auf dem Bildschirm der Konsole (Schnellmenü › Netzwerk) und du gibst sie hier ein.',
        on_btn: 'Einschalten', recheck: 'Ist eingeschaltet: PIN eingeben',
        on_local: 'Von diesem Browser aus geht das nicht: schalte es an der Konsole oder per USB-Kabel ein und tippe dann erneut.',
        on_still: 'Der Schutz ist auf dem Gerät noch nicht aktiv.',
        on_done: 'Schutz aktiv. PIN: {pin}', on_done_nopin: 'Schutz aktiv. Die PIN steht auf dem Bildschirm der Konsole (Schnellmenü › Netzwerk): andere Browser brauchen sie.' },
  zh: { title: '配对此浏览器', body: '要操作设备（文件、终端、设置），这个浏览器需要先配对一次。',
        speak: '在设备上朗读 PIN', speaking: '正在设备上朗读 PIN…',
        pin: '6 位 PIN', ok: '配对', cancel: '取消', wrong: 'PIN 错误', off: '此设备未启用配对',
        done: '已配对 ✓', err: '无法连接设备', file: 'PIN 也显示在主机屏幕上：快捷菜单 › 网络。',
        throttled: '请稍等几秒后重试。', locked: '尝试次数过多：请一分钟后重试。',
        on_title: '需要 PIN', on_body: '此功能会在设备上打开一个 shell，因此仅在同一网络中还不够：需要启用 PIN 保护。为了安全，只能在主机上或通过 USB 线连接的浏览器（http://192.168.42.1:8080）中开启。开启后 PIN 会显示在主机屏幕上（快捷菜单 › 网络），在这里输入即可。',
        on_btn: '开启', recheck: '我已开启：输入 PIN',
        on_local: '无法从这个浏览器开启：请在主机上或通过 USB 线开启，然后再按一次。',
        on_still: '设备上的保护尚未开启。',
        on_done: '保护已开启。PIN：{pin}', on_done_nopin: '保护已开启。PIN 显示在主机屏幕上（快捷菜单 › 网络）：其他浏览器需要用到它。' },
};
// The OS language is a DEVICE fact (/api/lang), not a per-browser one — the same
// console answers on several origins. The i18n engine's language (or the
// document/browser hint) is only the seed used until the device has answered;
// the device's answer goes through the engine's fromDevice(), which keeps a
// browser-only display language (zh) that the device stores as 'en'.
const engine = () => { try { return window.NucleoI18N || null; } catch { return null; } };
let LANG = String((engine() && engine().lang) || document.documentElement.lang || navigator.language || 'it').slice(0, 2);
async function syncLang() {
  try {
    const r = await fetch('/api/lang', { cache: 'no-store' });
    const j = await r.json();
    const E = engine();
    const l = j && (E && typeof E.fromDevice === 'function' ? E.fromDevice(j.lang) : j.lang);
    if (l && T[l]) LANG = l;
  } catch {}
}
// Accounts (capability users.multi, docs/multiuser.md): the device knows people, not browsers.
const TA = {
  it: { a_title: 'Accedi', a_body: 'Su questo dispositivo ognuno ha il suo account: entra con il tuo nome e la tua password.',
        a_name: 'Nome', a_pw: 'Password', a_remember: 'Ricordami su questo browser', a_ok: 'Entra',
        a_bad: 'Nome o password errati', a_disabled: "Questo account è disattivato: chiedi all'amministratore.",
        a_active: 'Ci sono già troppe persone collegate: riprova più tardi.',
        c_title: 'Scegli una nuova password', c_body: "L'amministratore ha reimpostato la tua password: scegline una nuova per continuare.",
        c_old: 'Password attuale', c_new: 'Nuova password', c_again: 'Ripeti la nuova password', c_ok: 'Salva',
        c_mismatch: 'Le due password non coincidono', c_weak: 'Password troppo debole: almeno 8 caratteri e non una delle più comuni.' },
  en: { a_title: 'Sign in', a_body: 'Everyone has their own account on this device: sign in with your name and password.',
        a_name: 'Name', a_pw: 'Password', a_remember: 'Remember me on this browser', a_ok: 'Sign in',
        a_bad: 'Wrong name or password', a_disabled: 'This account is disabled: ask the administrator.',
        a_active: 'Too many people are signed in right now: try again later.',
        c_title: 'Choose a new password', c_body: 'The administrator reset your password: choose a new one to continue.',
        c_old: 'Current password', c_new: 'New password', c_again: 'New password again', c_ok: 'Save',
        c_mismatch: 'The two passwords do not match', c_weak: 'Password too weak: at least 8 characters and not a common one.' },
  es: { a_title: 'Iniciar sesión', a_body: 'En este dispositivo cada persona tiene su cuenta: entra con tu nombre y tu contraseña.',
        a_name: 'Nombre', a_pw: 'Contraseña', a_remember: 'Recordarme en este navegador', a_ok: 'Entrar',
        a_bad: 'Nombre o contraseña incorrectos', a_disabled: 'Esta cuenta está desactivada: pregunta al administrador.',
        a_active: 'Ya hay demasiadas personas conectadas: inténtalo más tarde.',
        c_title: 'Elige una contraseña nueva', c_body: 'El administrador restableció tu contraseña: elige una nueva para continuar.',
        c_old: 'Contraseña actual', c_new: 'Contraseña nueva', c_again: 'Repite la contraseña nueva', c_ok: 'Guardar',
        c_mismatch: 'Las dos contraseñas no coinciden', c_weak: 'Contraseña demasiado débil: al menos 8 caracteres y no una de las más comunes.' },
  fr: { a_title: 'Se connecter', a_body: 'Sur cet appareil, chacun a son compte : connectez-vous avec votre nom et votre mot de passe.',
        a_name: 'Nom', a_pw: 'Mot de passe', a_remember: 'Se souvenir de moi sur ce navigateur', a_ok: 'Se connecter',
        a_bad: 'Nom ou mot de passe incorrect', a_disabled: "Ce compte est désactivé : demandez à l'administrateur.",
        a_active: 'Trop de personnes sont connectées en ce moment : réessayez plus tard.',
        c_title: 'Choisissez un nouveau mot de passe', c_body: "L'administrateur a réinitialisé votre mot de passe : choisissez-en un nouveau pour continuer.",
        c_old: 'Mot de passe actuel', c_new: 'Nouveau mot de passe', c_again: 'Répétez le nouveau mot de passe', c_ok: 'Enregistrer',
        c_mismatch: 'Les deux mots de passe ne correspondent pas', c_weak: 'Mot de passe trop faible : au moins 8 caractères et pas un des plus courants.' },
  de: { a_title: 'Anmelden', a_body: 'Auf diesem Gerät hat jede Person ein eigenes Konto: Melde dich mit deinem Namen und Passwort an.',
        a_name: 'Name', a_pw: 'Passwort', a_remember: 'In diesem Browser angemeldet bleiben', a_ok: 'Anmelden',
        a_bad: 'Name oder Passwort falsch', a_disabled: 'Dieses Konto ist deaktiviert: Frag den Administrator.',
        a_active: 'Gerade sind zu viele Personen angemeldet: Versuche es später erneut.',
        c_title: 'Neues Passwort wählen', c_body: 'Der Administrator hat dein Passwort zurückgesetzt: Wähle ein neues, um fortzufahren.',
        c_old: 'Aktuelles Passwort', c_new: 'Neues Passwort', c_again: 'Neues Passwort wiederholen', c_ok: 'Speichern',
        c_mismatch: 'Die beiden Passwörter stimmen nicht überein', c_weak: 'Passwort zu schwach: mindestens 8 Zeichen und keines der häufigsten.' },
  zh: { a_title: '登录', a_body: '这台设备上每个人都有自己的账户：用你的名称和密码登录。',
        a_name: '名称', a_pw: '密码', a_remember: '在此浏览器上记住我', a_ok: '登录',
        a_bad: '名称或密码错误', a_disabled: '此账户已停用：请联系管理员。',
        a_active: '当前登录的人数过多：请稍后重试。',
        c_title: '设置新密码', c_body: '管理员已重置你的密码：请设置一个新密码以继续。',
        c_old: '当前密码', c_new: '新密码', c_again: '再次输入新密码', c_ok: '保存',
        c_mismatch: '两次输入的密码不一致', c_weak: '密码太弱：至少 8 个字符，且不能是常见密码。' },
};
for (const l of Object.keys(TA)) Object.assign(T[l], TA[l]);
// A language may leave out the leading pictograph of a label: the English one is put in front.
const LEAD = /^\p{Extended_Pictographic}️?\s*/u;
for (const l of Object.keys(T)) for (const k of Object.keys(T.en)) {
  const m = LEAD.exec(T.en[k]), v = T[l][k];
  if (m && typeof v === 'string' && !LEAD.test(v)) T[l][k] = m[0] + v;
}
const t = (k) => (T[LANG] || T.it)[k] || T.it[k] || k;

const CSS = `
.ncpair-ovl{position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;
  background:rgba(4,8,20,.72);backdrop-filter:blur(3px);font:13px/1.5 system-ui,Segoe UI,sans-serif}
.ncpair-box{width:min(92vw,380px);background:var(--panel,#18233a);color:var(--text,#e8eefc);
  border:1px solid var(--line,#2a3a5e);border-radius:14px;padding:18px;box-shadow:0 18px 50px rgba(0,0,0,.5)}
.ncpair-box h2{margin:0 0 6px;font-size:16px}
.ncpair-box p{margin:0 0 12px;color:var(--muted,#8aa0c8);font-size:12px}
.ncpair-box button{font:inherit;border-radius:9px;padding:8px 12px;cursor:pointer;border:1px solid var(--line,#2a3a5e);
  background:#80808022;color:var(--text,#e8eefc)}
.ncpair-box button:hover{background:#80808036}
.ncpair-box button.pri{background:var(--accent,#4ea1ff);border-color:transparent;color:#04101f;font-weight:600}
.ncpair-speak{width:100%;margin-bottom:10px}
.ncpair-box input{width:100%;font:600 20px/1 ui-monospace,monospace;letter-spacing:.32em;text-align:center;
  padding:11px;border-radius:9px;border:1px solid var(--line,#2a3a5e);background:var(--field,#0b1220);
  color:var(--text,#e8eefc);outline:none}
.ncpair-row{display:flex;gap:8px;margin-top:12px}
.ncpair-row .grow{flex:1}
.ncpair-msg{min-height:16px;margin-top:8px;font-size:12px}
.ncpair-msg.err{color:var(--err,#e2576b)} .ncpair-msg.ok{color:var(--ok,#2fd07a)}
.ncpair-foot{margin-top:10px;font-size:11px;color:var(--muted,#8aa0c8)}
.ncpair-box .ncpair-acct input{font:14px/1.4 system-ui,Segoe UI,sans-serif;letter-spacing:normal;text-align:left;padding:9px 11px;margin-bottom:8px}
.ncpair-box .ncpair-acct input[type=checkbox]{width:auto;margin:0 6px 0 0;padding:0}
.ncpair-rem{display:flex;align-items:center;font-size:12px;color:var(--muted,#8aa0c8)}`;

let cssDone = false;
function injectCss() {
  if (cssDone) return;
  cssDone = true;
  const s = document.createElement('style'); s.textContent = CSS; document.head.appendChild(s);
}

/** {paired, auth:'open'|'pin'} — a fact about the DEVICE, never cached in localStorage. */
export async function pairStatus() {
  try {
    const r = await fetch('/api/auth/status', { cache: 'no-store' });
    return r.ok ? await r.json() : null;
  } catch { return null; }
}

let openDialog = null;   // one at a time, shared by every concurrent caller

/** Show the pairing dialog. Resolves true once this browser may drive the device,
 *  false if dismissed.
 *
 *  Two shapes, because there are two situations. If the device already asks for a
 *  PIN, this collects it. If the device is still open and the caller nonetheless
 *  got refused — which today means the terminal, gated harder than everything else
 *  because it is a shell — the dialog says how to turn protection ON. It used to do
 *  it right here and pair this browser in the same step; that was the hole (any
 *  LAN client could get the PIN that way), so now only the console or the USB
 *  cable can switch it on, and a WiFi browser is told where, then re-checks. */
export function pairDialog() {
  if (openDialog) return openDialog;
  injectCss();
  openDialog = (async () => {
    const [st] = await Promise.all([pairStatus(), syncLang()]);
    return new Promise((resolve) => {
      const ovl = document.createElement('div');
      ovl.className = 'ncpair-ovl';
      ovl.innerHTML =
        '<div class="ncpair-box" role="dialog" aria-modal="true">' +
        '<h2></h2><p></p>' +
        '<button class="ncpair-speak"></button>' +
        '<input class="ncpair-pin" inputmode="numeric" autocomplete="off" maxlength="6" placeholder="······">' +
        '<div class="ncpair-acct" hidden><input class="ncpair-a1" autocomplete="username" list="ncpair-names">' +
        '<input class="ncpair-a2" type="password" autocomplete="current-password">' +
        '<input class="ncpair-a3" type="password" autocomplete="new-password">' +
        '<label class="ncpair-rem"><input type="checkbox" class="ncpair-rm"><span></span></label>' +
        '<datalist id="ncpair-names"></datalist></div>' +
        '<div class="ncpair-msg"></div>' +
        '<div class="ncpair-row"><button class="ncpair-cancel"></button><div class="grow"></div><button class="pri ncpair-ok"></button></div>' +
        '<div class="ncpair-foot"></div></div>';
      const q = (s) => ovl.querySelector(s);
      const msg = (text, cls) => { const m = q('.ncpair-msg'); m.textContent = text; m.className = 'ncpair-msg ' + (cls || ''); };
      const done = (v) => { try { ovl.remove(); } catch {} openDialog = null; resolve(v); };
      // Each mode replaces the OK button's handler: onclick, not addEventListener,
      // so switching from "turn on" to "enter the PIN" cannot leave both wired.
      const ok = q('.ncpair-ok');

      q('.ncpair-cancel').textContent = t('cancel');
      q('.ncpair-cancel').onclick = () => done(false);

      // PIN entry — the normal case once the device asks for a PIN.
      const pinMode = () => {
        q('h2').textContent = t('title'); q('p').textContent = t('body');
        q('.ncpair-acct').hidden = true;
        q('.ncpair-speak').style.display = '';
        q('input').style.display = '';
        q('.ncpair-speak').textContent = t('speak');
        q('input').setAttribute('aria-label', t('pin'));
        ok.textContent = t('ok'); ok.style.display = ''; ok.disabled = false;
        q('.ncpair-foot').textContent = t('file');
        msg('');
        q('.ncpair-speak').onclick = async () => {
          msg(t('speaking'));
          try {
            const r = await fetch('/api/pair/speak', { method: 'POST' });
            const j = await r.json().catch(() => ({}));
            if (j.error === 'throttled') msg(t('throttled'), 'err');
            else if (j.ok === false) msg(t('off'), 'err');
          } catch { msg(t('err'), 'err'); }
        };
        const submit = async () => {
          const pin = q('input').value.trim();
          if (!pin) return;
          ok.disabled = true;
          try {
            const r = await fetch('/api/pair', { method: 'POST', body: JSON.stringify({ pin }) });
            const j = await r.json().catch(() => ({}));
            if (j.paired) { msg(t('done'), 'ok'); setTimeout(() => done(true), 450); return; }
            msg(r.status === 429 || j.locked ? t('locked') : t('wrong'), 'err');
          } catch { msg(t('err'), 'err'); }
          ok.disabled = false;
          q('input').select();
        };
        ok.onclick = submit;
        q('input').onkeydown = (e) => { if (e.key === 'Enter') submit(); };
        q('input').focus();
      };

      // The device is still open. From the console or the USB cable ("physical")
      // the button turns protection on; from anywhere else the server refuses,
      // so the dialog explains where to do it and then re-checks the device.
      const enableMode = () => {
        q('h2').textContent = t('on_title'); q('p').textContent = t('on_body');
        q('.ncpair-acct').hidden = true;
        q('.ncpair-speak').style.display = 'none';
        q('input').style.display = 'none';
        q('.ncpair-foot').textContent = '';
        const physical = !!(st && st.physical);
        ok.textContent = physical ? t('on_btn') : t('recheck');
        ok.onclick = async () => {
          ok.disabled = true;
          try {
            if (!physical) {
              // Someone turned it on at the console? Then this is just a PIN prompt.
              const now = await pairStatus();
              if (now && now.auth === 'pin') { if (now.paired) { done(true); return; } pinMode(); return; }
              msg(t('on_still'), 'err');
            } else {
              const r = await fetch('/api/pair/mode', { method: 'POST', body: JSON.stringify({ enabled: true }) });
              const j = await r.json().catch(() => ({}));
              if (j.enabled) {
                // A physical browser is trusted without a PIN. The PIN only comes
                // back to the console itself (loopback); everyone else reads it
                // on its screen.
                msg(j.pin ? t('on_done').replace('{pin}', j.pin) : t('on_done_nopin'), 'ok');
                ok.style.display = 'none';
                q('.ncpair-cancel').textContent = t('ok');
                q('.ncpair-cancel').onclick = () => done(true);
                return;
              }
              msg(r.status === 401 ? t('on_local') : (j.error || t('err')), 'err');
            }
          } catch { msg(t('err'), 'err'); }
          ok.disabled = false;
        };
        ok.focus();
      };

      // Accounts: name and password instead of the PIN. Signed in as someone else than this browser's last
      // person: their state is swapped in (nucleo-user.js) and the whole web OS reloads, so nothing of the
      // previous person stays on screen or in memory.
      const finish = async (user) => {
        if (await User.switchTo(user.id)) { try { (window.top || window).location.reload(); } catch { location.reload(); } return; }
        done(true);
      };
      const acctOnly = (title, body) => {
        q('h2').textContent = title; q('p').textContent = body;
        q('.ncpair-speak').style.display = 'none';
        q('.ncpair-pin').style.display = 'none';
        q('.ncpair-acct').hidden = false;
        q('.ncpair-foot').textContent = '';
        q('.ncpair-cancel').style.display = 'none';      // with accounts there is nothing to use without signing in
        ok.style.display = ''; ok.disabled = false;
        msg('');
      };
      const acctMode = () => {
        acctOnly(t('a_title'), t('a_body'));
        const [name, pw, again] = [q('.ncpair-a1'), q('.ncpair-a2'), q('.ncpair-a3')];
        name.style.display = ''; again.style.display = 'none'; q('.ncpair-rem').style.display = '';
        name.placeholder = t('a_name'); name.setAttribute('aria-label', t('a_name'));
        pw.placeholder = t('a_pw'); pw.setAttribute('aria-label', t('a_pw'));
        q('.ncpair-rem span').textContent = t('a_remember');
        const names = (st && Array.isArray(st.users)) ? st.users : [];
        q('#ncpair-names').replaceChildren(...names.map((u) => { const o = document.createElement('option'); o.value = u.name; return o; }));
        let lastId = null;
        try { lastId = localStorage.getItem(LAST); } catch {}
        const known = names.find((u) => u.id === lastId);
        if (known && !name.value) name.value = known.name;
        ok.textContent = t('a_ok');
        const submit = async () => {
          if (!name.value.trim() || !pw.value) return;
          ok.disabled = true; msg('');
          const r = await User.signIn(name.value.trim(), pw.value, q('.ncpair-rm').checked);
          if (r.ok && r.user) {
            if (r.user.must_change) { changeMode(pw.value, r.user); return; }
            msg(t('done'), 'ok'); setTimeout(() => finish(r.user), 300); return;
          }
          const e = r.error;
          msg(e === 'locked' ? t('locked') : e === 'disabled' ? t('a_disabled') : e === 'active_limit' ? t('a_active')
            : e === 'offline' ? t('err') : t('a_bad'), 'err');
          ok.disabled = false; pw.value = ''; pw.focus();
        };
        ok.onclick = submit;
        name.onkeydown = (e) => { if (e.key === 'Enter') pw.focus(); };
        pw.onkeydown = (e) => { if (e.key === 'Enter') submit(); };
        (name.value ? pw : name).focus();
      };
      // A password the administrator reset: changed here, before anything else answers.
      const changeMode = (oldPw, user) => {
        acctOnly(t('c_title'), t('c_body'));
        const [old, nw, again] = [q('.ncpair-a1'), q('.ncpair-a2'), q('.ncpair-a3')];
        q('.ncpair-rem').style.display = 'none';
        old.value = oldPw || ''; old.type = 'password'; old.removeAttribute('list');
        old.style.display = oldPw ? 'none' : '';
        old.placeholder = t('c_old'); old.setAttribute('aria-label', t('c_old')); old.setAttribute('autocomplete', 'current-password');
        nw.value = ''; nw.placeholder = t('c_new'); nw.setAttribute('aria-label', t('c_new')); nw.setAttribute('autocomplete', 'new-password');
        again.value = ''; again.style.display = ''; again.placeholder = t('c_again'); again.setAttribute('aria-label', t('c_again'));
        ok.textContent = t('c_ok');
        const submit = async () => {
          if (!old.value || !nw.value) return;
          if (nw.value !== again.value) { msg(t('c_mismatch'), 'err'); return; }
          ok.disabled = true; msg('');
          const r = await User.changePassword(old.value, nw.value);
          if (r.ok) { msg(t('done'), 'ok'); setTimeout(() => finish(user || (st && st.user)), 300); return; }
          msg(r.error === 'weak_password' ? t('c_weak') : r.error === 'bad_credentials' ? t('a_bad')
            : r.error === 'locked' ? t('locked') : t('err'), 'err');
          ok.disabled = false;
        };
        ok.onclick = submit;
        again.onkeydown = (e) => { if (e.key === 'Enter') submit(); };
        (oldPw ? nw : old).focus();
      };

      document.body.appendChild(ovl);
      if (st && st.multi) { if (st.user && st.user.must_change) changeMode('', st.user); else acctMode(); }
      else if (st && st.auth === 'open') enableMode(); else pinMode();
    });
  })();
  return openDialog;
}

/** True if this browser may drive the device — asking for the PIN if it may not. */
export async function ensurePaired() {
  const st = await pairStatus();
  if (!st) return false;
  if (st.paired && !(st.multi && st.user && st.user.must_change)) return true;
  return pairDialog();
}

/** fetch() that answers a `pairing_required` (or, with accounts, `signin_required`) 401 by asking for the PIN and
 *  retrying ONCE. Anything else is passed through untouched — a route that fails
 *  for its own reasons must keep failing visibly. */
export async function pairedFetch(input, init) {
  let r = await fetch(input, init);
  if (r.status !== 401) return r;
  let why = '';
  try { why = (await r.clone().json()).error || ''; } catch {}
  if (why !== 'pairing_required' && why !== 'signin_required') return r;
  if (!(await pairDialog())) return r;
  return fetch(input, init);
}

export default { pairStatus, pairDialog, ensurePaired, pairedFetch };
