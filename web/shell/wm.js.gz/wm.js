// Minimal window manager: open/focus/drag/minimize/close app windows.
// No dependencies. Apps are hosted in an <iframe> pointed at their web route.
// Real-OS extras: per-app geometry memory (via a provider the shell wires up) and
// Windows-11-style snapping — drag to edges/corners, or use the Snap Layouts flyout.
const layer = document.getElementById('windows');
let z = 10;
// A window may be PINNED above a fixed z (the blocking model installer floats above its OS-wide scrim).
// While pinned, focus() must NOT demote it to the normal counter — otherwise a click to reach its Cancel
// button would drop it under the scrim mid-gesture and the click would miss. null = no pin.
let pinnedTopId = null, pinnedTopZ = '';
const windows = new Map(); // id -> { el, app, min, max, snap, prev, ro }
let onChange = () => {};
let onFrameLoad = () => {};
let geomFor = () => null;  // shell-supplied: last-known geometry for an app id (survives close)

export function setOnChange(fn) { onChange = fn; }
// Called with (iframe, app) each time an app's iframe finishes loading, so the shell can
// inject OS-wide keyboard shortcuts into the app document (same-origin apps only).
export function setOnFrameLoad(fn) { onFrameLoad = fn; }
// The shell remembers each app's window geometry across closes/reboots and hands it back here.
export function setGeomProvider(fn) { geomFor = fn; }
export function list() { return [...windows.values()]; }
export function active() { return [...windows.values()].find((w) => w.el.classList.contains('active') && !w.min) || null; }

// Tell an app whether its window is currently visible. A minimized window is just CSS-hidden, so
// page-level document.hidden never fires inside the iframe — apps that poll the device (system
// monitor, Wi-Fi scan) would keep hammering it while invisible. This OS primitive lets them pause.
function notifyVis(w, visible) {
  const f = w && w.el.querySelector('iframe');
  if (f) try { f.contentWindow.postMessage({ t: 'os-visibility', d: { visible } }, '*'); } catch {}
}

// ── Feature Policy from the manifest ──────────────────────────────────────────────────────────
// This is the FIRST place a declared `permissions` entry actually constrains an app. Until now the
// field was decorative — nothing in the shell or the firmware ever read it — and because every app
// runs SAME-ORIGIN, the browser's default allowlist of `self` silently handed the microphone, the
// camera and geolocation to all 47 of them, including any app the agent writes and installs.
// Now a device capability is granted only if the manifest asked for it, and the others are DENIED
// explicitly ('none') rather than merely left unused. Scope is honest: this covers exactly the
// capabilities the BROWSER can mediate. `/api/*` capabilities (storage, IR, Wi-Fi) still need the
// broker described in docs — an iframe attribute cannot police them.
const FEATURE_BY_CAP = { 'device.mic': 'microphone', 'device.location': 'geolocation' };
const GATED_FEATURES = ['microphone', 'camera', 'geolocation'];   // camera: no app uses it — deny for all
export function allowAttr(app) {
  const declared = Array.isArray(app && app.permissions) ? app.permissions : null;
  // permissions unknown (registry unreadable) → keep the pre-existing behaviour rather than break
  // dictation/recorder/ANIMA's voice. Failing OPEN here is the status quo, not a new hole; failing
  // closed would silently mute the OS on a transient read error. shell.js logs it loudly.
  const parts = ['fullscreen', 'gamepad', 'autoplay'];
  if (!declared) return parts.join('; ');
  const granted = new Set(declared.map((c) => FEATURE_BY_CAP[c]).filter(Boolean));
  for (const f of GATED_FEATURES) parts.push(granted.has(f) ? f : `${f} 'none'`);
  return parts.join('; ');
}

// The window body: the app's iframe, or a placeholder when the manifest declares no web route.
// Extracted so the Feature-Policy wiring is host-testable — asserting that a declared `device.mic`
// really reaches the rendered `allow` attribute, without needing a browser.
// NB: no `pointer-lock` in the allow list. Chrome does not implement it as a Permissions-Policy
// feature and logs "Unrecognized feature" for every window opened; pointer lock in a same-origin,
// unsandboxed iframe (which this is) is allowed anyway, so the token only ever produced noise.
// Escape for an HTML ATTRIBUTE value. Not decoration: frameHtml built the tag by concatenation and
// interpolated app.name straight into title="…" BEFORE the allow attribute. A name containing a
// double quote closes the title and injects arbitrary attributes — including an `allow` of its own,
// which by the HTML duplicate-attribute rule (the FIRST wins) overrides the computed policy entirely.
// The agent can publish apps with names it chooses, so this was a self-service bypass of the very
// gate this file added. Also used for the window title bar, which is innerHTML too.
export const attr = (v) => String(v == null ? '' : v)
  .replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// Apps written by the AGENT run with NO ORIGIN. `sandbox` without allow-same-origin gives the frame an
// opaque origin: the pairing cookie does not ride along, the shell's localStorage is invisible, and
// /api/* is unreachable — which is the half of the boundary the Feature Policy above cannot cover.
// They reach the OS only through the postMessage broker (web/shell/appbroker.js), which grants exactly
// what their manifest declared. allow-forms + allow-modals keep ordinary UI working; popups, top-level
// navigation and downloads stay off. Curated apps are untouched: they are vetted code, and revoking
// their origin would break every one of them at once.
export function isSandboxed(app) { return !!(app && app.created_by === 'agent'); }

export function frameHtml(app, src) {
  const sandbox = isSandboxed(app) ? ' sandbox="allow-scripts allow-forms allow-modals"' : '';
  return app && app.route
    ? `<iframe src="${attr(src)}"${sandbox} title="${attr(app.name)}" allow="${attr(allowAttr(app))}"></iframe>`
    : `<div class="placeholder">${glyph(app)}<br><br>${attr(app && app.name)}<br><small>No web route declared.</small></div>`;
}

// Build the iframe of a deferred window, once, on demand. Everything that reads the frame already
// guards on null (notifyVis, the status broadcast, the shortcut injection), so a pending window is
// simply a window whose app has not loaded yet.
function materialise(w) {
  if (!w || !w.pending || w.holdDeferred) return;
  const src = w.pending;
  w.pending = null;
  const host = w.el.querySelector('.body');
  if (!host) return;
  host.innerHTML = frameHtml(w.app, src);
  const frame = host.querySelector('iframe');
  if (frame) frame.addEventListener('load', () => {
    try { onFrameLoad(frame, w.app); } catch {}
    try { const d = frame.contentDocument; if (d) d.addEventListener('pointerdown', () => focus(w.app.id), true); } catch {}
  });
}

function focus(id) {
  for (const w of windows.values()) w.el.classList.remove('active');
  const w = windows.get(id);
  if (!w) return;
  materialise(w);                 // a deferred window loads its app the moment it is actually wanted
  const wasMin = w.min;
  w.min = false;
  w.el.classList.remove('hidden');
  w.el.classList.add('active');
  w.el.style.zIndex = (id === pinnedTopId) ? pinnedTopZ : String(++z);   // never demote a pinned-top window
  if (wasMin) notifyVis(w, true);
  onChange();
}

// Click-to-front for APP CONTENT. Mouse events don't bubble out of an <iframe>, so a click on an
// app's body never reaches the outer .win mousedown (which only catches the chrome). When focus
// crosses into an iframe, the top window blurs and that iframe becomes document.activeElement — use
// that to raise its window, so clicking anywhere in any window brings it to the front like a real
// OS. This safety net also covers cross-origin frames; same-origin frames also get a direct
// pointerdown listener (below) for an instant, blur-independent raise.
window.addEventListener('blur', () => {
  setTimeout(() => {
    const ae = document.activeElement;
    if (!ae || ae.tagName !== 'IFRAME') return;
    for (const w of windows.values()) {
      if (w.el.querySelector('iframe') === ae && !w.el.classList.contains('active')) { focus(w.app.id); break; }
    }
  }, 0);
});

// Pin a window above a fixed z-index (e.g. the installer above its scrim) so focus() can't demote it.
// setPinnedTop(null) clears the pin. Idempotent; the shell pairs it with the install block lifecycle.
export function setPinnedTop(id, zIndex) { pinnedTopId = id || null; pinnedTopZ = String(zIndex || ''); }

export function toggle(id) {
  const w = windows.get(id);
  if (!w) return;
  if (w.el.classList.contains('active') && !w.min) { w.min = true; w.el.classList.add('hidden'); notifyVis(w, false); onChange(); }
  else focus(id);
}

// opts.deferred = build the window WITHOUT its iframe. The frame is materialised the first time the
// window is focused. Session restore uses it for windows that were minimised: they belong in the
// taskbar, but creating their iframe at boot means N simultaneous app loads on a device with 4-6
// sockets — for windows the user cannot even see.
export function open(app, query, opts = {}) {
  const src = app.route ? app.route + (query ? '?' + query : '') : '';
  if (windows.has(app.id)) {                       // already open: optionally navigate, then focus
    const w = windows.get(app.id);
    const iframe = w.el.querySelector('iframe');
    if (iframe && src) iframe.src = src;
    // A DEFERRED window has no iframe yet, so setting .src silently did nothing and it later
    // materialised its OLD pending URL: double-clicking a file with that app minimised opened
    // yesterday's document, with no error to explain it. Retarget the pending load instead.
    else if (!iframe && src) w.pending = src;
    focus(app.id);
    return;
  }
  const el = document.createElement('div');
  el.className = 'win';
  const n = windows.size;
  el.style.left = (60 + n * 28) + 'px';
  el.style.top = (40 + n * 28) + 'px';

  const body = opts.deferred ? '' : frameHtml(app, src);
  el.innerHTML =
    `<div class="bar"><span class="glyph">${glyph(app)}</span>` +
    `<span class="t">${attr(app.name)}</span>` +
    `<button class="min" title="Minimize"><svg viewBox="0 0 11 11" width="11" height="11" fill="none" stroke="currentColor" stroke-width="1.3"><line x1="2" y1="6" x2="9" y2="6" stroke-linecap="round"/></svg></button>` +
    `<button class="max" title="Maximize"><svg viewBox="0 0 11 11" width="11" height="11" fill="none" stroke="currentColor" stroke-width="1.2"><rect x="2" y="2" width="7" height="7" rx="1.2"/></svg></button>` +
    `<button class="close" title="Close"><svg viewBox="0 0 11 11" width="11" height="11" fill="none" stroke="currentColor" stroke-width="1.3"><line x1="2.6" y1="2.6" x2="8.4" y2="8.4" stroke-linecap="round"/><line x1="8.4" y1="2.6" x2="2.6" y2="8.4" stroke-linecap="round"/></svg></button></div>` +
    `<div class="body">${body}</div>` +
    `<div class="win-resizer n" data-dir="n"></div><div class="win-resizer s" data-dir="s"></div>` +
    `<div class="win-resizer e" data-dir="e"></div><div class="win-resizer w" data-dir="w"></div>` +
    `<div class="win-resizer nw" data-dir="nw"></div><div class="win-resizer ne" data-dir="ne"></div>` +
    `<div class="win-resizer sw" data-dir="sw"></div><div class="win-resizer se" data-dir="se"></div>`;

  layer.appendChild(el);
  windows.set(app.id, { el, app, min: false, max: false, snap: null, prev: null, pending: opts.deferred ? src : null });

  const frame = el.querySelector('iframe');
  if (frame) frame.addEventListener('load', () => {
    try { onFrameLoad(frame, app); } catch {}
    // Raise this window the instant the user touches its (same-origin) content. Capture phase so it
    // fires even if the app stops propagation; re-added per navigation since the document is fresh.
    try { const d = frame.contentDocument; if (d) d.addEventListener('pointerdown', () => focus(app.id), true); } catch {}
  });

  const bar = el.querySelector('.bar');
  const maxBtn = el.querySelector('.max');
  el.addEventListener('pointerdown', () => focus(app.id));   // click-to-front on touch too
  el.querySelector('.min').addEventListener('click', (e) => { e.stopPropagation(); toggle(app.id); });
  maxBtn.addEventListener('click', (e) => { e.stopPropagation(); maximize(app.id); });
  el.querySelector('.close').addEventListener('click', (e) => { e.stopPropagation(); close(app.id); });
  bar.addEventListener('dblclick', (e) => { if (!e.target.closest('button')) maximize(app.id); });
  attachSnapFlyout(maxBtn, app.id);                // Windows-11 Snap Layouts on hover
  // NOTE: no ResizeObserver here. The explicit resize handles (attachResize) call onChange()
  // once on pointerup; observing every frame floods renderTaskbar()+serialize() and freezes
  // the device mid-drag (esp. the heavy browser iframe).
  drag(el, bar, app.id);
  attachResize(el, app.id);

  const saved = geomFor(app.id);                   // restore this app's last geometry, if any
  if (saved) applyGeom(app.id, saved);
  // A deferred window must NOT be focused here: focus() materialises the frame, which is exactly the
  // load we are deferring. It is being restored minimised, so there is nothing to bring forward —
  // it just needs to exist in the taskbar until the user opens it.
  if (opts.deferred) { const w = windows.get(app.id); if (w) { w.min = true; w.el.classList.add('hidden'); } onChange(); return; }
  focus(app.id);
}

// Bring every floating window back inside the work area. A window dragged to the right edge of a
// wide screen simply VANISHED when the viewport shrank (a resize, a rotation, a smaller monitor):
// its saved left/top were still valid numbers, just off-screen, with no way to reach the title bar
// and drag it back. Called by the shell on resize. Maximized/snapped windows re-derive their own
// rectangle, so they are left alone.
export function clampIntoView() {
  const A = workArea();
  let moved = false;
  for (const w of windows.values()) {
    if (w.max || w.snap) continue;
    const el = w.el;
    // Read the STYLE, not the layout: a minimised window is display:none, so offsetLeft/offsetWidth
    // are 0 — and those are exactly the windows that reappear off-screen when they are restored.
    const curLeft = parseInt(el.style.left) || 0, curTop = parseInt(el.style.top) || 0;
    const width = parseInt(el.style.width) || el.offsetWidth || 320;
    // Always leave a grabbable strip of title bar on screen, never a fully off-screen window.
    const maxLeft = Math.max(0, A.w - Math.min(width, 120));
    const maxTop = Math.max(0, A.h - 34);
    const left = Math.min(Math.max(0, curLeft), maxLeft);
    const top = Math.min(Math.max(0, curTop), maxTop);
    if (left !== curLeft || top !== curTop) {
      el.style.left = left + 'px'; el.style.top = top + 'px'; moved = true;
    }
  }
  // Deliberately NOT onChange(): this is a DISPLAY correction for the current viewport. Persisting it
  // would let one session on a small screen (a projector, a rotated tablet) permanently collapse a
  // layout built on a large one — the user never asked to move those windows.
  return moved;
}

// ---- geometry helpers --------------------------------------------------------------------
function curGeom(w) {
  return { left: w.el.style.left, top: w.el.style.top,
    width: w.el.style.width || w.el.offsetWidth + 'px', height: w.el.style.height || w.el.offsetHeight + 'px' };
}
// The desktop work area: the viewport minus the taskbar. (The #windows layer has no intrinsic
// height — its children are absolutely positioned — so we measure the viewport directly, which
// is the same origin window left/top use and matches the CSS `.win.max` rectangle.)
function workArea() {
  const tb = document.getElementById('taskbar');
  const th = tb ? tb.offsetHeight : 44;
  return { w: window.innerWidth, h: window.innerHeight - th };
}
// Pixel rectangle for a snap zone within the work area.
function zoneRect(zone, A) {
  const hw = Math.round(A.w / 2), hh = Math.round(A.h / 2);
  switch (zone) {
    case 'full':  return { left: 0,  top: 0,  width: A.w, height: A.h };
    case 'left':  return { left: 0,  top: 0,  width: hw,  height: A.h };
    case 'right': return { left: hw, top: 0,  width: A.w - hw, height: A.h };
    case 'tl':    return { left: 0,  top: 0,  width: hw,  height: hh };
    case 'tr':    return { left: hw, top: 0,  width: A.w - hw, height: hh };
    case 'bl':    return { left: 0,  top: hh, width: hw,  height: A.h - hh };
    case 'br':    return { left: hw, top: hh, width: A.w - hw, height: A.h - hh };
  }
  return null;
}
// Which snap zone (if any) does a pointer at (px,py) in work-area coords land in?
function detectZone(px, py, A) {
  const EDGE = 18;
  const nearTop = py <= EDGE, nearLeft = px <= EDGE, nearRight = px >= A.w - EDGE, nearBottom = py >= A.h - EDGE;
  if (nearTop) return (px < A.w * 0.18) ? 'tl' : (px > A.w * 0.82) ? 'tr' : 'full';
  if (nearLeft) return py < A.h * 0.34 ? 'tl' : py > A.h * 0.66 ? 'bl' : 'left';
  if (nearRight) return py < A.h * 0.34 ? 'tr' : py > A.h * 0.66 ? 'br' : 'right';
  if (nearBottom) return px < A.w * 0.5 ? 'bl' : 'br';
  return null;
}

// Resize callback: if a SNAPPED window is dragged off its zone size via the grip, it stops
// being snapped (it becomes a floating window at the new size, which then persists correctly).
function onWinResized(w) {
  if (!w) return;
  if (w.snap && !w.max) {
    const r = zoneRect(w.snap, workArea());
    if (Math.abs(w.el.offsetWidth - r.width) > 3 || Math.abs(w.el.offsetHeight - r.height) > 3) {
      w.snap = null; w.el.classList.remove('snapped');
    }
  }
  onChange();
}

// Snap a window to a zone, remembering its floating geometry first so it can be restored.
export function applySnap(id, zone) {
  const w = windows.get(id); if (!w || !zone) return;
  if (!w.snap && !w.max) w.prev = curGeom(w);
  w.el.classList.remove('max', 'snapped');
  if (zone === 'full') {
    w.max = true; w.snap = null; w.el.classList.add('max'); w.el.querySelector('.max').title = 'Restore';
  } else {
    const r = zoneRect(zone, workArea());
    w.max = false; w.snap = zone; w.el.classList.add('snapped');
    Object.assign(w.el.style, { left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' });
    w.el.querySelector('.max').title = 'Maximize';
  }
  focus(id);
}

// Keyboard snapping (Win/⌘ + arrows), Windows-11 style. The current state is one of
// F(floating) M(maximized) left/right/tl/tr/bl/br; each arrow steps it through this grid,
// so e.g. Win+Left then Win+Up lands a window in the top-left quarter.
const SNAP_NEXT = {
  left:  { F: 'left',  M: 'left',  left: 'F',  right: 'F',  tl: 'F',    bl: 'F',    tr: 'tl',   br: 'bl' },
  right: { F: 'right', M: 'right', right: 'F', left: 'F',   tr: 'F',    br: 'F',    tl: 'tr',   bl: 'br' },
  up:    { F: 'M',     M: 'M',     left: 'tl', right: 'tr', bl: 'left', br: 'right', tl: 'M',   tr: 'M' },
  down:  { F: 'MIN',   M: 'F',     tl: 'left', tr: 'right', left: 'bl', right: 'br', bl: 'F',   br: 'F' },
};
export function snapByKey(id, dir) {
  const w = windows.get(id); if (!w || !SNAP_NEXT[dir]) return;
  const state = w.max ? 'M' : (w.snap || 'F');
  const next = SNAP_NEXT[dir][state];
  if (next === 'MIN') { w.min = true; w.el.classList.add('hidden'); notifyVis(w, false); onChange(); return; }
  if (next === 'M') { applySnap(id, 'full'); return; }       // force-maximize regardless of current snap
  if (next === 'F') { if (w.max || w.snap) maximize(id); return; }  // restore to floating geometry
  applySnap(id, next);                                       // a half/quarter zone
}

// Re-tile snapped windows when the desktop work area changes (resolution/DeX/rotation).
let retileT = null;
window.addEventListener('resize', () => {
  clearTimeout(retileT);
  retileT = setTimeout(() => {
    const A = workArea(); let any = false;
    for (const w of windows.values()) {
      if (!w.snap || w.max) continue;
      const r = zoneRect(w.snap, A);
      Object.assign(w.el.style, { left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' });
      any = true;
    }
    if (any) onChange();
  }, 120);
});

// Serialize open windows so the device can restore the session (real-OS behaviour).
// The window's CURRENT location, so a restored window comes back with its CONTENT and not blank.
// Only the geometry used to be saved: reopening put File Commander at its default folder, Notepad on
// an empty buffer and the media player on nothing. Prefer the live location (apps navigate with
// query strings), fall back to the src attribute, and keep it same-origin + bounded.
function liveUrl(w) {
  const f = w.el.querySelector('iframe');
  if (!f) return w.pending || '';                 // never materialised: its pending src is the truth
  try {
    const l = f.contentWindow && f.contentWindow.location;
    if (l && l.origin === location.origin) return (l.pathname + l.search).slice(0, 512);
  } catch {}                                       // cross-origin (an external link) → attribute only
  return (f.getAttribute('src') || '').slice(0, 512);
}

export function serialize() {
  const out = [];
  for (const w of windows.values()) {
    const g = ((w.max || w.snap) && w.prev) ? w.prev : curGeom(w);   // floating geom, so restore works
    out.push({ id: w.app.id, x: parseInt(g.left) || 0, y: parseInt(g.top) || 0,
      w: parseInt(g.width) || 0, h: parseInt(g.height) || 0,
      min: !!w.min, max: !!w.max, snap: w.snap || null, z: parseInt(w.el.style.zIndex) || 0,
      url: liveUrl(w) });
  }
  return out;
}

// Apply a saved geometry to an already-open window (session restore / per-app memory).
export function applyGeom(id, g) {
  const w = windows.get(id);
  if (!w) return;
  if (g.x != null) w.el.style.left = g.x + 'px';
  if (g.y != null) w.el.style.top = g.y + 'px';
  if (g.w) w.el.style.width = g.w + 'px';
  if (g.h) w.el.style.height = g.h + 'px';
  if (g.z) { w.el.style.zIndex = g.z; if (g.z > z) z = g.z; }
  // A window restored MINIMISED must not be materialised on the way in. maximize()/applySnap() both
  // end in focus(), which builds the iframe — precisely the load being deferred — so a
  // minimised-AND-maximised window still paid for its app at boot. Hold materialisation across the
  // geometry restore, then put it back in the taskbar.
  if (g.min) w.holdDeferred = true;
  if (g.max) maximize(id);                  // re-maximize (stores current floating geom as prev)
  else if (g.snap) applySnap(id, g.snap);   // re-snap to its half/quarter
  w.holdDeferred = false;
  if (g.min) { w.min = true; w.el.classList.add('hidden'); }
}

// Toggle a window between maximized (fills the desktop) and its prior size/position.
export function maximize(id) {
  const w = windows.get(id);
  if (!w) return;
  if (w.max || w.snap) {                     // restore from maximized OR snapped
    w.el.classList.remove('max', 'snapped');
    if (w.prev) Object.assign(w.el.style, w.prev);
    w.max = false; w.snap = null;
    w.el.querySelector('.max').title = 'Maximize';
  } else {
    w.prev = curGeom(w);
    w.el.classList.add('max');
    w.max = true;
    w.el.querySelector('.max').title = 'Restore';
  }
  focus(id);
}

// Minimize every window; if they're already all hidden, restore them (Win "show desktop").
export function showDesktop() {
  const vis = [...windows.values()].filter((w) => !w.min);
  if (vis.length) for (const w of vis) { w.min = true; w.el.classList.add('hidden'); notifyVis(w, false); }
  else for (const w of windows.values()) { w.min = false; w.el.classList.remove('hidden'); notifyVis(w, true); }
  onChange();
}

export function close(id) {
  const w = windows.get(id);
  if (!w) return;
  const wasActive = w.el.classList.contains('active');
  if (w.ro) try { w.ro.disconnect(); } catch {}
  w.el.remove();
  windows.delete(id);
  // Promote a successor. Nothing did, so after closing a window active() returned null and every
  // shortcut that targets "the current window" — Ctrl+W, Ctrl+S, Win+arrows, paste-to-app — went dead
  // until the user happened to click another one. Take the topmost window still on screen, exactly
  // like every desktop OS.
  if (wasActive) {
    const next = [...windows.values()].filter((x) => !x.min)
      .sort((a, b) => (parseInt(b.el.style.zIndex) || 0) - (parseInt(a.el.style.zIndex) || 0))[0];
    if (next) { focus(next.app.id); return; }   // focus() already calls onChange()
  }
  onChange();
}

function glyph(app) { return app.glyph || '▦'; }

// ---- snap preview overlay (shown while dragging near an edge) ----------------------------
let preview = null;
function showPreview(zone) {
  if (!preview) { preview = document.createElement('div'); preview.className = 'snap-preview hidden'; layer.appendChild(preview); }
  const r = zoneRect(zone, workArea());
  Object.assign(preview.style, { left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' });
  preview.classList.remove('hidden');
}
function hidePreview() { if (preview) preview.classList.add('hidden'); }

// Pointer dragging within the desktop, with Windows-11 edge/corner snapping.
// Title-bar drag on POINTER events. The resize handles 80 lines below already use them
// (attachResize), so this was an internal inconsistency with a user-visible cost: on a touch screen
// a window could be resized but never MOVED. Pointer capture also fixes a long-standing mouse bug —
// dragging fast over an app iframe used to drop the gesture; the iframe is only made inert as a
// belt-and-braces.
function drag(win, handle, id) {
  let sx, sy, ox, oy, moving = false, zone = null, dragPid = null;
  handle.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    if (e.target.closest('button')) return;
    const w = windows.get(id);
    // Dragging a maximized/snapped window "tears it off": restore floating size under the cursor.
    if (w && (w.max || w.snap)) {
      const rect = win.getBoundingClientRect();
      const ratioX = rect.width ? (e.clientX - rect.left) / rect.width : 0.5;
      w.el.classList.remove('max', 'snapped'); w.max = false; w.snap = null;
      w.el.querySelector('.max').title = 'Maximize';
      const prev = w.prev || { width: '520px', height: '360px' };
      const fw = parseInt(prev.width) || 520, fh = parseInt(prev.height) || 360;
      win.style.width = fw + 'px'; win.style.height = fh + 'px';
      win.style.left = Math.max(0, e.clientX - fw * ratioX) + 'px';
      win.style.top = Math.max(0, e.clientY - 17) + 'px';
    }
    moving = true; sx = e.clientX; sy = e.clientY;
    ox = win.offsetLeft; oy = win.offsetTop;
    e.preventDefault();
    dragPid = e.pointerId;
    try { handle.setPointerCapture(e.pointerId); } catch {}   // keep the gesture even over an iframe
    const iframe = win.querySelector('iframe');
    if (iframe) iframe.style.pointerEvents = 'none';
  });
  window.addEventListener('pointermove', (e) => {
    if (!moving || (dragPid != null && e.pointerId !== dragPid)) return;   // a second finger must not steer this window
    const A = workArea();
    win.style.left = Math.max(0, ox + e.clientX - sx) + 'px';
    win.style.top = Math.min(A.h - 34, Math.max(0, oy + e.clientY - sy)) + 'px';
    zone = detectZone(e.clientX, e.clientY, A);     // pointer is already in work-area coords
    if (zone) showPreview(zone); else hidePreview();
  });
  // One exit for EVERY way a pointer gesture can end. With only pointerup, a cancelled pointer (the
  // browser takes it back, a second touch, the tab losing it) left `moving` true and the iframe stuck
  // at pointerEvents:'none' — the window kept following the cursor and its app stopped accepting clicks.
  const endDrag = (e) => {
    if (!moving) return;
    if (e && e.pointerId != null && dragPid != null && e.pointerId !== dragPid) return;   // not our gesture
    moving = false; hidePreview();
    try { if (dragPid != null) handle.releasePointerCapture(dragPid); } catch {}
    dragPid = null;
    const iframe = win.querySelector('iframe');
    if (iframe) iframe.style.pointerEvents = '';
    if (zone) { applySnap(id, zone); zone = null; }
    else onChange();
  };
  window.addEventListener('pointerup', endDrag);
  window.addEventListener('pointercancel', endDrag);
  handle.addEventListener('lostpointercapture', endDrag);
}

// ---- Snap Layouts flyout (Windows-11: hover the maximize button) -------------------------
let fly = null, flyId = null, flyHideT = null;
function buildFly() {
  fly = document.createElement('div');
  fly.className = 'snap-fly';
  fly.innerHTML =
    `<div class="lay full"><div class="cell" data-z="full"></div></div>` +
    `<div class="lay two"><div class="cell" data-z="left"></div><div class="cell" data-z="right"></div></div>` +
    `<div class="lay quad"><div class="cell" data-z="tl"></div><div class="cell" data-z="tr"></div>` +
      `<div class="cell" data-z="bl"></div><div class="cell" data-z="br"></div></div>`;
  fly.addEventListener('mouseenter', () => clearTimeout(flyHideT));
  fly.addEventListener('mouseleave', hideFly);
  fly.addEventListener('click', (e) => { const c = e.target.closest('.cell'); if (c && flyId) { applySnap(flyId, c.dataset.z); hideFly(); } });
  document.body.appendChild(fly);
}
function showFly(id, btn) {
  if (!fly) buildFly();
  clearTimeout(flyHideT);
  flyId = id;
  fly.style.visibility = 'hidden'; fly.style.display = 'grid';
  const r = btn.getBoundingClientRect();
  const fw = fly.offsetWidth, fh = fly.offsetHeight;
  let left = Math.round(r.left + r.width / 2 - fw / 2);
  left = Math.max(6, Math.min(left, window.innerWidth - fw - 6));
  let top = r.bottom + 6;
  if (top + fh > window.innerHeight - 6) top = r.top - fh - 6;
  fly.style.left = left + 'px'; fly.style.top = top + 'px';
  fly.style.visibility = 'visible';
}
function hideFly() { if (fly) fly.style.display = 'none'; flyId = null; }
function attachSnapFlyout(btn, id) {
  let openT = null;
  btn.addEventListener('mouseenter', () => { openT = setTimeout(() => showFly(id, btn), 350); });
  btn.addEventListener('mouseleave', () => { clearTimeout(openT); flyHideT = setTimeout(hideFly, 250); });
}

// Window resizing from all edges and corners
function attachResize(win, id) {
  const resizers = win.querySelectorAll('.win-resizer');
  resizers.forEach(r => {
    r.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      e.preventDefault(); e.stopPropagation();
      focus(id);
      const w = windows.get(id);
      if (w.max || w.snap) {
        w.el.classList.remove('max', 'snapped'); w.max = false; w.snap = null;
        w.el.querySelector('.max').title = 'Maximize';
      }
      const dir = r.dataset.dir;
      const startX = e.clientX, startY = e.clientY;
      const startW = win.offsetWidth, startH = win.offsetHeight;
      const startL = win.offsetLeft, startT = win.offsetTop;
      const minW = 240, minH = 160;
      
      const iframe = win.querySelector('iframe');
      if (iframe) iframe.style.pointerEvents = 'none';

      const move = (ev) => {
        let dx = ev.clientX - startX, dy = ev.clientY - startY;
        let newW = startW, newH = startH, newL = startL, newT = startT;
        if (dir.includes('e')) newW = startW + dx;
        if (dir.includes('w')) { newW = startW - dx; newL = startL + dx; }
        if (dir.includes('s')) newH = startH + dy;
        if (dir.includes('n')) { newH = startH - dy; newT = startT + dy; }

        if (newW < minW) { newL -= (minW - newW); newW = minW; }
        if (newH < minH) { newT -= (minH - newH); newH = minH; }
        if (newT < 0) { newH += newT; newT = 0; }

        win.style.width = newW + 'px'; win.style.height = newH + 'px';
        if (dir.includes('w') || dir.includes('n')) {
          win.style.left = newL + 'px'; win.style.top = newT + 'px';
        }
      };
      const up = () => {
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
        if (iframe) iframe.style.pointerEvents = '';
        onChange();
      };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
    });
  });
}
