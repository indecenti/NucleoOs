// NucleoOS "Agenti" — UI controller. Reads the Anthropic key from the device vault, drives the
// online multi-agent runtime, renders the conversation + a live activity log, and gates destructive
// tool calls behind explicit approval. Online-only: if there's no key or no network it does NOT fall
// back to the offline brain — it cleanly hands off to the separate offline ANIMA app.

import { createRuntime } from './runtime.js';
// The F4 engine picker (lazy): the header 🧠 button and the no-key gate both open it. It owns model
// install and the honest per-rung capability verdicts; we only read its rows to build local.engines.
let pickerMod = null, picker = null;
async function loadPicker() { return pickerMod || (pickerMod = await import('./engine-picker.js')); }
// F2: the hardware permissions THIS app was granted. The gate is the manifest — a hardware tool the
// agent app did not declare is never offered to the model. Read once; the manifest is static.
let hwPerms = null;
async function loadHwPerms() {
  if (hwPerms) return hwPerms;
  // Through the file API: the device's webfs serves only www/ under /apps/agent/, so the manifest (one level up)
  // answered 404 on every Cardputer and the app ran with no declared permissions (found by device-smoke, 2026-10-10).
  try { const r = await fetch('/api/fs/read?path=' + encodeURIComponent('/apps/agent/manifest.json'), { cache: 'no-store' }); const m = r.ok ? await r.json() : null; hwPerms = (m && Array.isArray(m.permissions)) ? m.permissions : []; }
  catch { hwPerms = []; }
  return hwPerms;
}
import { providerOf, PROVIDERS, readTeacher } from '/ai.js';   // shared provider registry + cached vault read: Claude, Groq, Grok (xAI), Gemini
import I18N from '/nucleo-i18n.js';

// Centralized i18n: loads core + this app's catalog, paints [data-i18n] DOM, live-switches on OS
// language change, and returns a namespace-bound t(). Imperatively-built strings use t() below.
const t = await I18N.init('agent');

const $ = (id) => document.getElementById(id);
// The agent runtime is five-language aware; ask the OS engine instead of re-deriving it from
// localStorage, which only ever answered 'it' or 'en' and pinned es/fr/de users to Italian.
const lang = () => I18N.lang;

let cfg = null;            // active/default provider config for the runtime
let keys = null;           // full keys{} map (all configured providers) → cross-provider routing + fallback
let active = null;         // the user's chosen active cfg (for geminiTier + routing tiebreak)
let rt = null;             // runtime instance
let history = [];          // [{role:'user'|'bot', text}]
let busy = false;
let localUp = null;        // a local AI server on this PC (Ollama / LM Studio …) that can run the agent: { server, model } | null

// The PC's own model as an agent engine (/ai-engines.js): detected on boot, no key needed, works offline.
async function detectLocalServer() {
  try {
    const E = await import('/ai-engines.js');
    const cfgL = E.loadLocalConfig(); if (!cfgL.enabled) return null;
    const s = (await E.liveServers({ config: cfgL })).find((x) => x.status === 'ok' && x.models.length);
    if (!s) return null;
    return { server: s.name, model: (cfgL.models && cfgL.models[s.id] && cfgL.models[s.id].agent) || E.pickModel(s.models, 'agent', { perf: E.loadPerf(), base: s.base }) || s.models[0].id };
  } catch { return null; }
}

// ---- tiny safe markdown (escape → fenced code → inline) ----
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function md(text) {
  const parts = String(text || '').split(/```/);
  let out = '';
  for (let i = 0; i < parts.length; i++) {
    if (i % 2 === 1) { out += '<pre>' + esc(parts[i].replace(/^[a-z]*\n/i, '')) + '</pre>'; continue; }
    out += esc(parts[i])
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
      .replace(/\bhttps?:\/\/[^\s<]+/g, (m) => '<a href="' + m + '" target="_blank" rel="noopener">' + m + '</a>')
      .replace(/\n/g, '<br>');
  }
  return out;
}

const logEl = () => $('log');
function scroll() { const m = logEl(); m.scrollTop = m.scrollHeight; }
function addMsg(role, text, asMd) {
  const d = document.createElement('div'); d.className = 'msg ' + role;
  if (asMd) d.innerHTML = md(text); else d.textContent = text;
  logEl().appendChild(d); scroll(); return d;
}
function setStatus(s, kind) { $('status').textContent = s; const dot = $('dot'); dot.className = 'dot' + (kind ? ' ' + kind : ''); }

// ---- activity log: one card per tool call ----
const TOOL_ICON = { update_plan: '🗒️', list_files: '📁', read_file: '📄', search_files: '🔎', make_dir: '📁', write_file: '✍️', edit_file: '✏️', append_file: '➕', delete_file: '🗑️', move_file: '🔀', run_js: '⚙️', open_in_os: '🪟', device_status: '📊', list_apps: '🧩', weather: '🌤️', web_search: '🌐', scaffold_app: '🧱', publish_app: '🚀', manage_app: '🎛️', generate_image: '🎨', transcribe: '🎙️' };
function toolStart(ev) {
  const d = document.createElement('div'); d.className = 'tool run';
  const p = ev.input.path || ev.input.from || ev.input.app || ev.input.id || ev.input.name || '';
  d.innerHTML = '<div class="th"><span class="ti">' + (TOOL_ICON[ev.name] || '🔧') + '</span><span class="tn">' + esc(ev.name) + '</span><span class="tp">' + esc(p) + '</span></div><div class="tr">…</div>';
  logEl().appendChild(d); ev._el = d; scroll();
}
function toolEnd(ev, out, isErr) {
  const d = ev._el; if (!d) return;
  d.className = 'tool' + (isErr ? ' err' : '');
  const tr = d.querySelector('.tr'); if (tr) tr.textContent = String(out || '').slice(0, 1200);
  scroll();
}

// ---- live plan (the worker's update_plan checklist) ----
// Replaces the panel in place on every update, so the user watches ONE list advance instead of
// scrolling past N snapshots of it. Empty plan → the panel disappears.
const PLAN_MARK = { todo: '☐', doing: '▸', done: '☑' };
function renderPlanPanel(steps) {
  const el = $('plan');
  if (!el) return;
  if (!steps || !steps.length) { el.hidden = true; el.innerHTML = ''; return; }
  const done = steps.filter((s) => s.status === 'done').length;
  el.innerHTML = '<div class="ph"><span>' + esc(t('plan_title')) + '</span>'
    + '<span class="pb"><i style="width:' + Math.round(done / steps.length * 100) + '%"></i></span>'
    + '<span>' + done + '/' + steps.length + '</span></div>'
    + '<ol>' + steps.map((s) => '<li class="' + s.status + '"><span class="m">' + PLAN_MARK[s.status] + '</span>'
      + '<span>' + esc(s.title) + '</span></li>').join('') + '</ol>';
  el.hidden = false;
}

// ---- approval overlay (returns a Promise<bool>) ----
function diffHtml(oldS, newS) {
  return '<pre>' + (oldS ? '<span class="del">- ' + esc(oldS).replace(/\n/g, '\n- ') + '</span>\n' : '') +
    (newS ? '<span class="add">+ ' + esc(newS).replace(/\n/g, '\n+ ') + '</span>' : '') + '</pre>';
}
function confirmTool(req) {
  return new Promise((resolve) => {
    const labels = { write_file: t('op_write_file'), edit_file: t('op_edit_file'), append_file: t('op_append_file'), delete_file: t('op_delete_file'), move_file: t('op_move_file'), run_js: t('op_run_js'), scaffold_app: t('op_scaffold_app'), publish_app: t('op_publish_app'), manage_app: t('op_manage_app'), generate_image: t('op_generate_image') };
    let bodyHtml = '';
    // A hardware tool moves atoms in the room (an IR blast, a GPIO pin) — show it as such, with its
    // args, and always in the confirm dialog (the runtime forces the confirm; this only renders it).
    if (req.hw) {
      const args = Object.entries(req).filter(([k]) => !['op', 'hw', 'abs', 'root'].includes(k)).map(([k, v]) => k + ': ' + JSON.stringify(v));
      bodyHtml = '<div class="pth">⚡ ' + esc(t('appr_hw')) + '</div>' + (args.length ? '<pre>' + esc(args.join('\n')) + '</pre>' : '');
    }
    else if (req.op === 'edit_file') bodyHtml = diffHtml(req.old, req.new);
    else if (req.op === 'write_file' || req.op === 'append_file') bodyHtml = '<pre>' + esc(String(req.content || '').slice(0, 4000)) + (String(req.content || '').length > 4000 ? '\n…' : '') + '</pre>';
    else if (req.op === 'run_js') bodyHtml = '<pre>' + esc(String(req.code || '').slice(0, 4000)) + '</pre>';
    else if (req.op === 'move_file') bodyHtml = '<div class="pth">' + esc(req.from) + ' → ' + esc(req.to) + '</div>';
    else if (req.op === 'scaffold_app') bodyHtml = '<div class="pth">' + esc(t('appr_new_app')) + ': ' + esc(req.name || req.id || '') + '</div>' + (req.description ? '<pre>' + esc(req.description) + '</pre>' : '');
    else if (req.op === 'publish_app') bodyHtml = '<div class="pth">' + esc(t('appr_install_app')) + ': <b>' + esc(req.id || '') + '</b> → /apps/' + esc(req.id || '') + '</div>';
    else if (req.op === 'manage_app') bodyHtml = '<div class="pth">' + esc(String(req.action || '') === 'enable' ? t('appr_enable_app') : t('appr_disable_app')) + ': <b>' + esc(req.id || '') + '</b></div>';
    else if (req.op === 'generate_image') bodyHtml = '<div class="pth">' + esc(req.path || '') + '</div><pre>' + esc(String(req.prompt || '').slice(0, 2000)) + '</pre>';
    const pth = req.path || req.from || '';
    $('appr').innerHTML =
      '<h3>' + esc(t('appr_title')) + ' <span class="op' + (req.hw ? ' hw' : '') + '">' + esc(req.hw ? t('appr_hw_op') : (labels[req.op] || req.op)) + '</span></h3>' +
      (pth ? '<div class="pth">' + esc(pth) + '</div>' : '') + bodyHtml +
      '<div class="btns"><button class="deny" id="ap-deny">' + esc(t('appr_deny')) + '</button><button class="allow" id="ap-allow">' + esc(t('appr_allow')) + '</button></div>';
    $('ovl').classList.add('show');
    const fin = (v) => { $('ovl').classList.remove('show'); resolve(v); };
    $('ap-allow').onclick = () => fin(true);
    $('ap-deny').onclick = () => fin(false);
  });
}

const ui = {
  status: (s) => setStatus(s, 'busy'),
  note: (t) => addMsg('sys', t),
  toolStart, toolEnd,
  sandboxLog: (lvl, txt) => { if (txt) addMsg('sys', '⚙️ ' + txt); },
  plan: renderPlanPanel,
  confirm: confirmTool,
  autoApprove: () => $('auto').checked,
  webSearchEnabled: () => $('web').checked,
};

// ---- provider config from the device vault ----
// Returns { cfg, keys, active } or null. `cfg`/`active` is the user's chosen provider (or the strongest
// configured one as a default); `keys` is the FULL keys{} map so the runtime routes a subtask to the best
// model across EVERY configured provider and falls back when one is down. Works with ANY combination:
// only one key → just that provider; all keys → all exploited. Recognises all 4 providers incl. Grok (xai).
function inferProvider(j) {
  if (j.provider && PROVIDERS[j.provider]) return j.provider;
  const b = String(j.base || '');
  if (/anthropic/.test(b)) return 'anthropic';
  if (/generativelanguage/.test(b)) return 'google';
  if (/x\.ai/.test(b)) return 'xai';
  if (j.key) return 'openai';   // bare key, Groq-style base assumed
  return null;
}
function cfgFromEntry(prov, e) {
  const p = providerOf(prov);
  return { provider: prov, base: e.base || p.base, model: e.model || p.def, key: e.key, version: e.version || p.version, geminiTier: e.geminiTier || '' };
}
function pickCfg(j) {
  j = j || {};
  const keys = (j.keys && typeof j.keys === 'object') ? j.keys : {};
  // 1) the active provider chosen by the user (top-level), if it actually carries a key
  let active = null;
  const tp = inferProvider(j);
  if (j.key && tp) active = cfgFromEntry(tp, j);
  // 2) otherwise the strongest configured key in keys{} (Claude → Grok → Groq → Gemini)
  if (!active) {
    for (const prov of ['anthropic', 'xai', 'openai', 'google']) {
      const e = keys[prov];
      if (e && e.key) { active = cfgFromEntry(prov, e); break; }
    }
  }
  if (!active || !active.key) return null;
  return { cfg: active, keys, active };
}

function showGate(kind) {
  const c = $('gate-card');
  const openApp = (id) => window.parent && window.parent.postMessage({ type: 'open-app', id }, '*');
  if (kind === 'offline') {
    c.innerHTML = '<div class="gi">📡</div><h2>' + esc(t('gate_offline_title')) + '</h2><p>' + esc(t('gate_offline_body')) + '</p><div><button id="g-retry">' + esc(t('retry')) + '</button><button class="ghost" id="g-anima">' + esc(t('gate_anima')) + '</button></div>';
  } else {
    c.innerHTML = '<div class="gi">🔑</div><h2>' + esc(t('gate_key_title')) + '</h2><p>' + esc(t('gate_key_body')) + '</p><div><button id="g-set">' + esc(t('gate_open_settings')) + '</button><button class="ghost" id="g-anima">' + esc(t('gate_anima')) + '</button></div><div><button class="ghost" id="g-eng" style="margin-top:10px">' + esc(t('gate_local')) + '</button><button class="ghost" id="g-retry" style="margin-top:10px">' + esc(t('retry')) + '</button></div>';
  }
  $('gate').classList.add('show');
  const r = $('g-retry'); if (r) r.onclick = boot;
  const s = $('g-set'); if (s) s.onclick = () => openApp('settings');
  const a = $('g-anima'); if (a) a.onclick = () => openApp('anima');
  const g = $('g-eng'); if (g) g.onclick = () => { hideGate(); toggleEngines(); };
}
function hideGate() { $('gate').classList.remove('show'); }

// The 🧠 header button: toggle the engine panel. Built on first open; refreshed on later opens so
// cache/caps changes (a finished download, a browser flag flip) are reflected.
async function toggleEngines() {
  const hostEl = $('engines');
  if (!hostEl.hidden) { hostEl.hidden = true; return; }
  hostEl.hidden = false;
  const pk = await loadPicker();
  if (!picker) {
    picker = pk.initEnginePicker({ host: hostEl, t, hasKey: () => !!(cfg && cfg.key),
      onChange: () => { rebuildRuntime(); } });
  } else picker.refresh();
}

function configuredProviders() { return Object.keys(keys || {}).filter((p) => keys[p] && keys[p].key && PROVIDERS[p]); }
function modelLine() {
  if (cfg.provider === 'anthropic') return t('model_anthropic');
  if (configuredProviders().length > 1) return t('model_multi');
  return (providerOf(cfg.provider).label || cfg.provider) + ' · ' + t('model_tools_suffix');
}
function readyMsg() {
  if (cfg.provider === 'anthropic') return t('ready_anthropic');
  return t('ready_generic') + (configuredProviders().length > 1 ? t('ready_multi_suffix') : '');
}
async function rebuildRuntime() {
  const root = ($('ws').value || '/data/agent').trim() || '/data/agent';
  // local: the F0 cascade's rungs. Engines are constructed LAZILY on first use (the cloud path never
  // pays for them); a rung that fails to construct declines honestly and the next one is tried.
  const local = {
    engines: async () => {
      const pk = await loadPicker();
      const caps = await pk.probeCaps();
      const store = await pk.makeAgentStore();
      const status = {};
      for (const id of [pk.WEBGPU_MODEL, pk.WASM_MODEL]) { try { status[id] = await store.status(id); } catch { status[id] = 'absent'; } }
      const rows = pk.localRungOrder(pk.rungRows(caps, status, !!(cfg && cfg.key)), localStorage.getItem(pk.ENGINE_LS) || 'auto');
      const out = [];
      for (const r of rows) {
        try {
          // Only rungs the loop can genuinely RUN are constructed (rungRows marks them runnable) —
          // today that is WebGPU, built exactly like local-llm.js builds it: the vendor lib from the
          // SD, CreateMLCEngine behind an injected factory. A construction failure just skips the
          // rung; the F0 cascade declines honestly instead of pretending.
          if (r.id === 'webgpu') {
            const we = await import('/apps/anima/forge/webllm-engine.js');
            const createEngine = async (modelId, opts) => {
              const webllm = await import('/apps/anima/forge/vendor/web-llm.js');
              return webllm.CreateMLCEngine(modelId, { initProgressCallback: opts && opts.initProgressCallback });
            };
            out.push({ tier: 'local-webgpu', engine: we.makeWebLLMEngine({ createEngine, modelId: r.model }) });
          } else if (r.id === 'wasm') {
            // F3: the CPU rung. The wllama-adapter bridges the vendored wllama's createCompletion to the
            // createChatCompletion shape wasm-engine expects; the model loads from the shared cache.
            const [ws, ad] = [await import('/apps/anima/forge/wasm-engine.js'), await import('./wllama-adapter.js')];
            out.push({ tier: 'local-wasm', engine: ws.makeWasmEngine({ createEngine: ad.makeWllamaCreateEngine(ad.browserLoadWllama), modelId: r.model }) });
          }
        } catch { /* a missing vendor lib = this rung declines; the cascade moves on */ }
      }
      return out.filter((x) => x && x.engine);
    },
    grammar: await import('/apps/anima/forge/grammar.js').catch(() => null),
    // F3 grounded veto: the local loop's code writes go through capguard with the SAME hardware grant
    // the tools use, so a weak model cannot write os.hw.* code the app was not granted (F2's veto),
    // and dangerous patterns (eval, import) block too. Injected → the loop stays pure/testable.
    verify: async ({ code }) => {
      try {
        const cg = await import('/apps/anima/forge/capguard.js');
        const vf = await import('/apps/anima/forge/verify.js');
        const granted = (await loadHwPerms()).includes('device.ir') || (await loadHwPerms()).includes('device.gpio') || (await loadHwPerms()).includes('net.wifi') ? ['hw'] : [];
        const assessed = cg.assess(code, { granted });
        return vf.combineVerdict({ capguard: assessed });
      } catch { return { verdict: 'pass' }; }
    },
  };
  // localServer: first when there is no cloud key (the runtime decides), else the fallback when the cloud fails.
  const localServer = { first: () => false, private: () => false };
  rt = createRuntime({ cfg, root, lang: lang(), ui, keys, active, t, local: local.grammar ? local : null, hwPerms: await loadHwPerms(), localServer });
  $('model-line').textContent = modelLine();
}

async function send() {
  if (busy || !rt) return;
  const q = $('q').value.trim(); if (!q) return;
  if (!navigator.onLine && !localUp) { showGate('offline'); return; }   // a model on this PC needs no internet
  $('q').value = ''; autosize();
  addMsg('user', q);
  history.push({ role: 'user', text: q });
  busy = true; $('send').disabled = true; $('stop').style.display = '';
  setStatus(t('st_thinking'), 'busy');
  try {
    const reply = await rt.run(q, history.slice(0, -1));
    addMsg('bot', reply, true);
    history.push({ role: 'bot', text: reply });
    setStatus(t('st_ready'), 'ok');
  } catch (e) {
    const msg = String(e && e.message || e);
    if (msg === 'stopped') { addMsg('sys', t('msg_stopped')); setStatus(t('st_stopped')); }
    else { addMsg('sys', '⚠️ ' + msg); setStatus(t('st_error'), 'err'); }
  } finally {
    busy = false; $('send').disabled = false; $('stop').style.display = 'none'; $('q').focus();
  }
}

function autosize() { const t = $('q'); t.style.height = 'auto'; t.style.height = Math.min(160, t.scrollHeight) + 'px'; }

async function boot() {
  hideGate();
  localUp = await detectLocalServer();
  if (!navigator.onLine && !localUp) { showGate('offline'); return; }
  setStatus(t('st_checking_key'));
  try {
    // Shared cached vault read (memoised ~30s in ai.js → collapses repeated device reads). Returns the
    // normalised cfg incl. keys{} (all providers), {unpaired:true}, or null.
    const tc = await readTeacher({ fresh: true });
    if (tc && tc.unpaired) { setStatus(t('st_pair_first'), 'err'); showGate('key'); return; }
    const res = pickCfg(tc || {});
    cfg = res && res.cfg; keys = res && res.keys; active = res && res.active;
  } catch { cfg = null; keys = null; active = null; }
  if (!cfg && localUp) {
    // No cloud key, but a model runs on this PC (Ollama / LM Studio): the full agent with native tool calling.
    cfg = { provider: 'openai', key: '', model: '' }; keys = {}; active = null;
    await rebuildRuntime();
    $('model-line').textContent = localUp.server + ' · ' + localUp.model;
    setStatus(t('st_ready'), 'ok');
    if (!history.length) addMsg('sys', t('ready_local_server', { server: localUp.server, model: localUp.model }));
    return;
  }
  if (!cfg) {
    // No cloud key. F4: a cached local model is a first-class way to run — boot on it instead of
    // dead-ending at the key gate. The stub cfg has no key, so the cloud loop exits in zero hops
    // and the cascade goes straight to the local rungs.
    try {
      const pk = await loadPicker();
      const caps = await pk.probeCaps();
      const store = await pk.makeAgentStore();
      const status = {};
      for (const id of [pk.WEBGPU_MODEL, pk.WASM_MODEL]) { try { status[id] = await store.status(id); } catch { status[id] = 'absent'; } }
      const ready = pk.localRungOrder(pk.rungRows(caps, status, false));
      if (ready.length) {
        cfg = { provider: 'openai', key: '', model: '' }; keys = {}; active = null;
        await rebuildRuntime();
        $('model-line').textContent = t(ready[0].id === 'webgpu' ? 'eng_webgpu' : 'eng_wasm');
        setStatus(t('st_ready'), 'ok');
        if (!history.length) addMsg('sys', t('ready_local'));
        return;
      }
    } catch { /* fall through to the gate */ }
    showGate('key'); return;
  }
  await rebuildRuntime();
  setStatus(t('st_ready'), 'ok');
  if (!history.length) addMsg('sys', readyMsg());
}

// ---- wiring ----
$('send').addEventListener('click', send);
$('stop').addEventListener('click', () => { if (rt) rt.stop(); });
$('q').addEventListener('input', autosize);
$('q').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
$('ws').addEventListener('change', () => { if (cfg) rebuildRuntime(); });
window.addEventListener('online', () => { if (!cfg) boot(); else hideGate(); });
window.addEventListener('offline', () => { if (localUp) hideGate(); });
window.addEventListener('offline', () => { setStatus(t('st_offline_reconnect'), 'err'); });

// Live language switch (no reload). The observer repaints all [data-i18n] DOM; re-do the bits we
// build imperatively: the model-line (the observer would reset it to the generic "subtitle"), the
// rebuilt runtime (so the agent's own prompt language follows), and any open gate card.
I18N.onChange(() => {
  if (cfg) rebuildRuntime();   // also re-sets #model-line via t()
  if ($('gate').classList.contains('show')) showGate($('g-set') ? 'key' : 'offline');
});

document.getElementById('eng-btn').addEventListener('click', toggleEngines);
boot();
