// ANIMA weather NLU — shared, pure, testable.
//
// The native firmware mirrors this exact logic (nucleo_anima_online.c). The hard part of a
// weather assistant on an ESP32 is NOT the HTTP call — it's understanding the question with no
// NER, no LLM, no parser generator. So instead of the fragile "city must follow a preposition"
// rule (which fails on the single most common phrasing, "meteo brescia"), we use a RESIDUAL
// strip: peel away everything we DO recognise — the weather words, the time words, the dates,
// the fillers, the prepositions — and whatever contiguous run of words is left standing IS the
// place. Robust by construction: it doesn't need to know city names, it knows everything that
// isn't one.
//
// parseWeather(q, {lang, now}) -> {
//   isWeather, city, dayOffset, tooFar, aspect, dateLabel
// }

// ---- normalisation ---------------------------------------------------------
// Lowercase, strip accents, drop apostrophes, collapse whitespace. Keep digits (dates).
export function normWeather(s) {
  return String(s || '')
    .toLowerCase().replace(/ß/g, 'ss')
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/['’`]/g, ' ')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// ---- lexicons --------------------------------------------------------------
// STRONG weather words: their presence makes it a weather question. "tempo" is deliberately NOT
// here (it means time/duration too) — only the fixed phrase "che tempo" counts.
const WX_STRONG = ['meteo','previsioni','previsione','clima','climatic',
  'piove','piover','piova','pioggia','piovoso','piovera','pioggie',
  'sole','soleggiat','nuvol','nubi','sereno','coperto','nebbia','foschia',
  'neve','nevica','nevicher','grandine','temporale','temporali',
  'temperatura','temperature','gradi','caldo','freddo','afa','umidita','umid','vento','ventoso',
  'weather','forecast','rain','raining','rainy','sunny','cloud','cloudy','snow','snowing','snowy',
  'storm','thunderstorm','fog','foggy','windy','temperature','degrees','hot','cold','chilly','humidity',
  'ombrello','umbrella','bel tempo','brutto tempo'];

// Spanish / French / German weather words, matched as whole TOKENS (never substrings: "sol", "grad", "vent" sit inside
// other words). Until 2026-10 only Italian and English were understood: "Wie wird das Wetter morgen in Berlin?" went to a
// model that could only report the current weather.
const WX_TOKENS_XL = new Set(['lluvia','llueve','llover','llovera','lloviendo','soleado','nublado','nubes','nieve','nieva','nevara','tormenta','tormentas',
  'grados','calor','frio','viento','pronostico','paraguas','niebla',
  'pluie','pleut','pleuvoir','pleuvra','soleil','ensoleille','nuageux','nuages','neige','neigera','orage','orages','degres','chaud','froid','vent',
  'previsions','parapluie','brouillard',
  'wetter','regen','regnet','regnen','sonne','sonnig','bewolkt','wolken','schnee','schneit','gewitter','sturm','temperatur','grad','kalt','windig',
  'vorhersage','regenschirm','nebel']);
const REPORT_XL = /\bque tiempo\b|\btiempo (?:hace|hara|va a hacer)\b|\bel tiempo (?:hoy|manana|en|para)\b|\bquel temps\b|\btemps (?:fait|fera|va)\b|\bwetter\b|\bpronostico\b|\bprevisions? meteo\b|\bvorhersage\b/;
const PEEL_XL = ['que','como','cual','donde','cuando','hace','hara','va','van','ir','el','los','las','unos','unas','en','del','para','por','manana','hoy','pasado',
  'esta','este','semana','fin','tiempo','llover','hacer','dime','sabes','estara','sera','habra','hay','mi','ciudad','ahora','tarde','noche','dias','dia','cerca',
  'quel','quelle','quels','quelles','temps','fait','fera','elle','les','une','du','des','au','aux','dans','pour','sur','demain','aujourd','hui','apres','ce','cette',
  'soir','matin','semaine','est','sont','dis','moi','va','faire','ville','maintenant','jours','jour','pres','il','y','aura','prevu','prevue',
  'wie','wird','werden','das','der','die','den','dem','morgen','heute','ubermorgen','im','am','an','um','fur','mit','ist','sein','es','gibt','sag','mir',
  'bitte','woche','wochenende','abend','nacht','mittag','tagen','tage','tag','jetzt','stadt','bei','nach','von','wetter','wettervorhersage'];
const PREP_XL = ['en','para','por','cerca','dans','au','aux','pour','pres','im','am','fur','bei','nach','von'];
const MONTHS_XL = { enero:1, febrero:2, abril:4, mayo:5, junio:6, julio:7, septiembre:9, octubre:10, noviembre:11, diciembre:12,
  janvier:1, fevrier:2, mars:3, avril:4, mai:5, juin:6, juillet:7, aout:8, octobre:10, decembre:12,
  januar:1, februar:2, marz:3, juni:6, juli:7, oktober:10, dezember:12 };
const WEEKDAYS_XL = { domingo:0, lunes:1, martes:2, miercoles:3, jueves:4, viernes:5, sabado:6,
  dimanche:0, lundi:1, mardi:2, mercredi:3, jeudi:4, vendredi:5, samedi:6,
  sonntag:0, montag:1, dienstag:2, mittwoch:3, donnerstag:4, freitag:5, samstag:6 };

// Prepositions (a subset of PEEL). A run immediately following one of these is almost always the
// place ("a roma", "in london") — this beats "longest run" when a stray verb precedes the city.
const PREP = new Set(['a','ad','al','allo','alla','ai','agli','alle','in','nel','nello','nella','nei','negli','nelle',
  'di','del','dello','della','dei','degli','delle','da','dal','dallo','dalla','dai','dagli','dalle',
  'su','sul','sullo','sulla','sui','sugli','sulle','per','con','tra','fra','presso',
  'at','on','for','near','around','of','to','from','with','into']);

// Words to PEEL during residual place extraction. Superset of weather words plus fillers,
// question words, verbs of "to be/to do/to make", prepositions, articles. None of these are
// plausible city names, so removing them can't eat a place.
const PEEL = new Set([
  // weather surface forms (broad, since these never name a city)
  'meteo','previsioni','previsione','clima','climatico','climatica',
  'piove','piover','piovera','piovere','piova','pioggia','piovoso','piovosa','piovera','piogge',
  'sole','soleggiato','soleggiata','nuvoloso','nuvolosa','nuvole','nubi','sereno','serena','coperto','coperta',
  'nebbia','foschia','neve','nevica','nevicara','nevichera','grandine','temporale','temporali','rovesci',
  'temperatura','temperature','gradi','grado','caldo','calda','freddo','fredda','afa','umidita','vento','ventoso',
  'weather','forecast','rain','raining','rainy','sun','sunny','cloud','clouds','cloudy','overcast','clear',
  'snow','snowing','snowy','hail','storm','storms','thunderstorm','fog','foggy','mist','windy','wind',
  'temperature','degrees','degree','hot','warm','cold','chilly','humidity','humid','umido','umida',
  'massima','minima','massime','minime','max','min','meteorologica','meteorologiche',
  'ombrello','umbrella','bel','bello','brutto','brutta','buono','buon','buona','cattivo','cattiva','giornata',
  // time words (relative + units) — dates handled separately but peel the surface too
  'oggi','domani','dopodomani','stamattina','stamani','stasera','stanotte','stamane','domattina',
  'adesso','ora','ore','attualmente','attuale','poi','prossimo','prossima','prossimi','prossime','scorso','scorsa',
  'today','tomorrow','tonight','now','currently','later','next','this','coming','upcoming',
  'giorno','giorni','settimana','weekend','week','day','days','morning','afternoon','evening','night',
  // question / filler / verbs / connectors
  'che','cosa','come','quanto','quanta','quanti','quante','quale','quali','dove','quando','perche',
  'ci','c','si','e','ed','o','ma','se','non','mi','ti','sara','sarra','saranno','fa','fara','faranno','farra',
  'fare','essere','avere','avremo','avra','avranno','stara','staranno','tempo','meteorologico','meteorologiche',
  'previsto','prevista','previste','previsti','aspetta','aspettano','dimmi','dammi','sapere','vorrei','voglio',
  'puoi','potresti','mostrami','mostra','controlla','dico','dice','allora','insomma','citta','paese','zona',
  'what','whats','will','would','is','are','be','being','the','a','an','do','does','going','gonna','tell','me',
  'give','know','show','check','please','about','like','there','it','its','expected','forecasted','any',
  'sai','dire','vuoi','how','right',
  'dici','dirmi','dimmelo','dillo','favore','grazie','sapere','potrebbe','pomeriggio','mattina','sera','notte',
  // articles & demonstratives (Italian bare forms — never a city head)
  'il','lo','la','i','gli','le','un','uno','una','un',
  'questo','questa','questi','queste','quello','quella','quei','quegli','quelle','quel',
  // prepositions
  'a','ad','al','allo','alla','ai','agli','alle','in','nel','nello','nella','nei','negli','nelle',
  'di','del','dello','della','dei','degli','delle','da','dal','dallo','dalla','dai','dagli','dalle',
  'su','sul','sullo','sulla','sui','sugli','sulle','per','con','tra','fra','presso',
  'at','on','for','near','around','of','to','from','with','into',
]);

// IT / EN month names -> 1..12
const MONTHS = {
  gennaio:1, febbraio:2, marzo:3, aprile:4, maggio:5, giugno:6, luglio:7, agosto:8,
  settembre:9, ottobre:10, novembre:11, dicembre:12,
  january:1, february:2, march:3, april:4, may:5, june:6, july:7, august:8,
  september:9, october:10, november:11, december:12,
  gen:1, feb:2, mar:3, apr:4, mag:5, giu:6, lug:7, ago:8, set:9, sett:9, ott:10, nov:11, dic:12,
  jan:1, jun:6, jul:7, aug:8, sep:9, sept:9, oct:10, dec:12,
};
// Weekday name -> 0(Sun)..6(Sat) to match Date.getDay()
const WEEKDAYS = {
  domenica:0, lunedi:1, martedi:2, mercoledi:3, giovedi:4, venerdi:5, sabato:6,
  sunday:0, monday:1, tuesday:2, wednesday:3, thursday:4, friday:5, saturday:6,
  lun:1, mar:2, mer:3, gio:4, ven:5, sab:6, dom:0,
};

// The es/fr/de tables apply to es/fr/de questions only: merged into the shared ones they would split "Los Angeles",
// "El Paso", "Frankfurt am Main" in an Italian or English question.
const PEEL_XL_SET = new Set([...PEEL_XL, ...PREP_XL]), PREP_XL_SET = new Set(PREP_XL);
const ART_XL = new Set(['el', 'los', 'las', 'le', 'la', 'les', 'der', 'die', 'das', 'den']);   // kept after a preposition: "en Los Ángeles"
const XL = new Set(['es', 'fr', 'de']);
const monthOf = (t, lang) => MONTHS[t] || (XL.has(lang) ? MONTHS_XL[t] : undefined);
const weekdayOf = (t, lang) => (t in WEEKDAYS) ? WEEKDAYS[t] : (XL.has(lang) && (t in WEEKDAYS_XL) ? WEEKDAYS_XL[t] : undefined);
const LOCALE_XL = { es: 'es-ES', fr: 'fr-FR', de: 'de-DE' };

// Open-Meteo free forecast horizon (days ahead). Beyond this we honestly refuse.
export const FORECAST_HORIZON = 15;

// ---- weather intent --------------------------------------------------------
// A definition question ("cos'è il clima", "what is rain") is knowledge, not a live lookup.
function isDefinition(nf) {
  return /\bcos\b|\bcosa e\b|\bche cos|\bche cosa\b|\bsignifica\b|\bdefinizione\b|\bspiega\b/.test(nf)
      || /\bwhat is\b|\bwhat does\b|\bwhat are\b|\bmeaning of\b|\bdefine\b/.test(nf)
      || /\bque es\b|\bque son\b|\bdefinicion\b|\bqu est ce\b|\bque signifie\b|\bwas ist\b|\bwas sind\b|\bwas bedeutet\b/.test(nf);
}
export function isWeatherQuery(nf) {
  // An explicit live-REPORT word ("meteo"/"weather"/"forecast"/"che tempo") makes it a lookup even
  // in a "what is …" frame ("what is the weather like" is NOT a definition of the noun "weather").
  const report = /\bmeteo\b|\bprevision|\bforecast\b|\bweather\b|\bche tempo\b|\btempo fa\b|\btempo fara\b/.test(nf);
  if (report || REPORT_XL.test(nf)) return true;
  if (isDefinition(nf)) return false;   // "cos'è il clima", "what is rain" -> knowledge, not a lookup
  for (const w of WX_STRONG) if (nf.includes(w)) return true;
  // whole tokens: "rovesci" (showers) is inside "conto alla rovescia" (a countdown) — a timer page became a forecast
  for (const t of nf.split(' ')) if (WX_TOKENS_XL.has(t) || t === 'rovesci') return true;
  return false;
}

// What facet did they ask about? Lets us answer the actual question, not dump a bulletin.
function detectAspect(nf) {
  if (/\bpiov|\bpioggia\b|\brain|\bumbrella\b|\bombrello\b|\bllu|\bllov|\bparaguas\b|\bpluie\b|\bpleu|\bparapluie\b|\bregen|\bregn/.test(nf)) return 'rain';
  if (/\bsole\b|\bsoleggiat|\bsereno\b|\bsunny\b|\bsun\b|\bclear\b|\bsoleado\b|\bsoleil\b|\bensoleille\b|\bsonne\b|\bsonnig\b/.test(nf)) return 'sun';
  if (/\bnev|\bsnow|\bniev|\bneig|\bschnee|\bschneit/.test(nf)) return 'snow';
  if (/\btemperatur|\bgradi\b|\bcaldo\b|\bfreddo\b|\bhot\b|\bcold\b|\bwarm\b|\bchilly\b|\bdegrees?\b|\bgrados\b|\bcalor\b|\bfrio\b|\bdegres\b|\bchaud\b|\bfroid\b|\bgrad\b|\bkalt\b/.test(nf)) return 'temp';
  if (/\bvento\b|\bventoso\b|\bwind|\bwindy\b|\bviento\b|\bvent\b/.test(nf)) return 'wind';
  return 'general';
}

// ---- date parsing ----------------------------------------------------------
// Returns {dayOffset, tooFar, dateLabel, hitTokens:Set} from a token list. Pure given `now`.
function parseDate(tokens, lang, now) {
  const en = lang === 'en';
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const dayMs = 86400000;
  const offsetOf = (d) => Math.round((d - today) / dayMs);
  const labelDate = (d) => {
    const md = en
      ? ['January','February','March','April','May','June','July','August','September','October','November','December']
      : ['gennaio','febbraio','marzo','aprile','maggio','giugno','luglio','agosto','settembre','ottobre','novembre','dicembre'];
    return en ? `${md[d.getMonth()]} ${d.getDate()}` : `${d.getDate()} ${md[d.getMonth()]}`;
  };
  const wkLabel = (dow) => (en
    ? ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][dow]
    : ['domenica','lunedi','martedi','mercoledi','giovedi','venerdi','sabato'][dow]);

  const hit = new Set();
  const has = (w) => tokens.includes(w);
  const joined = ' ' + tokens.join(' ') + ' ';
  if (XL.has(lang)) {                                    // es / fr / de: labels from the platform's own calendar names
    const loc = LOCALE_XL[lang];
    const name = (d, o) => { try { return d.toLocaleDateString(loc, o); } catch { return d.toDateString(); } };
    const REL = { es: ['hoy', 'mañana', 'pasado mañana', 'este fin de semana'], fr: ["aujourd'hui", 'demain', 'après-demain', 'ce week-end'], de: ['heute', 'morgen', 'übermorgen', 'am Wochenende'] }[lang];
    const rel = (off, i) => ({ dayOffset: off, tooFar: false, dateLabel: REL[i], hitTokens: hit });
    if (has('ubermorgen') || joined.includes(' pasado manana ') || joined.includes(' apres demain ')) { ['ubermorgen', 'pasado', 'manana', 'apres', 'demain'].forEach((t) => hit.add(t)); return rel(2, 2); }
    // "morgen" alone is tomorrow ("heute morgen" = this morning); "manana" too ("esta mañana" = this morning)
    if ((has('morgen') && !has('heute')) || (has('manana') && !joined.includes(' esta manana ') && !joined.includes(' por la manana ')) || has('demain')) { ['morgen', 'manana', 'demain'].forEach((t) => hit.add(t)); return rel(1, 1); }
    for (let i = 0; i < tokens.length - 2; i++) {
      const n = parseInt(tokens[i + 1], 10);
      if (['en', 'dans', 'in'].includes(tokens[i]) && Number.isFinite(n) && ['dias', 'dia', 'jours', 'jour', 'tagen', 'tage', 'tag'].includes(tokens[i + 2])) {
        hit.add(tokens[i]); hit.add(tokens[i + 1]); hit.add(tokens[i + 2]);
        return { dayOffset: n, tooFar: n > FORECAST_HORIZON, dateLabel: name(new Date(today.getTime() + n * dayMs), { day: 'numeric', month: 'long' }), hitTokens: hit };
      }
    }
    for (let i = 0; i < tokens.length; i++) {
      const m = monthOf(tokens[i], lang); if (!m) continue;
      const dd = i > 0 && /^\d{1,2}$/.test(tokens[i - 1]) ? +tokens[i - 1] : (/^\d{1,2}$/.test(tokens[i + 1] || '') ? +tokens[i + 1] : 0);
      if (dd >= 1 && dd <= 31) {
        hit.add(tokens[i]); hit.add(String(dd));
        let d = new Date(now.getFullYear(), m - 1, dd); if (offsetOf(d) < 0) d = new Date(now.getFullYear() + 1, m - 1, dd);
        const off = offsetOf(d);
        return { dayOffset: off, tooFar: off > FORECAST_HORIZON, dateLabel: name(d, { day: 'numeric', month: 'long' }), hitTokens: hit };
      }
    }
    for (const t of tokens) if (weekdayOf(t, lang) !== undefined) {
      let off = (weekdayOf(t, lang) - today.getDay() + 7) % 7; if (off === 0) off = 7; hit.add(t);
      return { dayOffset: off, tooFar: off > FORECAST_HORIZON, dateLabel: name(new Date(today.getTime() + off * dayMs), { weekday: 'long' }), hitTokens: hit };
    }
    if (has('wochenende') || joined.includes(' fin de semana ') || has('weekend')) {
      ['wochenende', 'fin', 'semana', 'weekend'].forEach((t) => hit.add(t));
      let off = (6 - today.getDay() + 7) % 7; if (off === 0) off = 7; return { ...rel(off, 3) };
    }
    ['hoy', 'ahora', 'aujourd', 'hui', 'maintenant', 'heute', 'jetzt'].forEach((t) => { if (has(t)) hit.add(t); });
    return rel(0, 0);
  }

  // explicit relative words (longest/most-specific first)
  if (has('dopodomani') || (tokens.join(' ').includes('day after tomorrow'))) {
    ['dopodomani','day','after','tomorrow'].forEach(t => hit.add(t));
    return { dayOffset: 2, tooFar: false, dateLabel: en ? 'the day after tomorrow' : 'dopodomani', hitTokens: hit };
  }
  if (has('domani') || has('tomorrow') || has('domattina')) {
    ['domani','tomorrow','domattina'].forEach(t => hit.add(t));
    return { dayOffset: 1, tooFar: false, dateLabel: en ? 'tomorrow' : 'domani', hitTokens: hit };
  }

  // "fra/tra/in N giorni|days"
  for (let i = 0; i < tokens.length - 1; i++) {
    if (['fra','tra','in'].includes(tokens[i])) {
      const n = parseInt(tokens[i + 1], 10);
      const unit = tokens[i + 2];
      if (Number.isFinite(n) && (unit === 'giorni' || unit === 'giorno' || unit === 'days' || unit === 'day')) {
        hit.add(tokens[i]); hit.add(tokens[i + 1]); if (unit) hit.add(unit);
        const d = new Date(today.getTime() + n * dayMs);
        return { dayOffset: n, tooFar: n > FORECAST_HORIZON, dateLabel: labelDate(d), hitTokens: hit };
      }
    }
  }

  // "DD <month>" or "<month> DD" (with optional year ignored)
  for (let i = 0; i < tokens.length; i++) {
    const m = MONTHS[tokens[i]];
    if (!m) continue;
    let day = null;
    if (i > 0 && /^\d{1,2}$/.test(tokens[i - 1])) { day = parseInt(tokens[i - 1], 10); hit.add(tokens[i - 1]); }
    else if (i < tokens.length - 1 && /^\d{1,2}$/.test(tokens[i + 1])) { day = parseInt(tokens[i + 1], 10); hit.add(tokens[i + 1]); }
    if (day && day >= 1 && day <= 31) {
      hit.add(tokens[i]);
      let year = now.getFullYear();
      let d = new Date(year, m - 1, day);
      if (offsetOf(d) < 0) { d = new Date(year + 1, m - 1, day); }   // a passed date means next year
      const off = offsetOf(d);
      return { dayOffset: off, tooFar: off > FORECAST_HORIZON, dateLabel: labelDate(d), hitTokens: hit };
    }
  }

  // weekday name -> next occurrence (today's weekday means next week, not today)
  for (const t of tokens) {
    if (t in WEEKDAYS) {
      const target = WEEKDAYS[t];
      let off = (target - today.getDay() + 7) % 7;
      if (off === 0) off = 7;
      hit.add(t);
      return { dayOffset: off, tooFar: off > FORECAST_HORIZON, dateLabel: wkLabel(target), hitTokens: hit };
    }
  }

  // weekend -> upcoming Saturday
  if (has('weekend')) {
    hit.add('weekend');
    let off = (6 - today.getDay() + 7) % 7; if (off === 0) off = 7;
    return { dayOffset: off, tooFar: false, dateLabel: en ? 'this weekend' : 'questo weekend', hitTokens: hit };
  }

  // default: today
  ['oggi','today','adesso','ora','now','stamattina','stamani','stasera','stanotte'].forEach(t => { if (has(t)) hit.add(t); });
  return { dayOffset: 0, tooFar: false, dateLabel: en ? 'today' : 'oggi', hitTokens: hit };
}

// ---- place extraction (residual) -------------------------------------------
// Peel every recognised token; whatever contiguous runs of survivors remain are place candidates.
// Selection: a run immediately following a preposition ("a roma", "in london") is the place — this
// beats "longest" when a stray verb/filler precedes the city ("ci sono a roma" -> roma, not "sono").
// With no preposition anywhere ("meteo brescia", "previsioni reggio emilia"), the longest run wins.
function extractCity(tokens, dateHits, lang = 'it') {
  const runs = [];                       // { text, prep, len }
  let run = [], runPrep = false, prevDropPrep = false;
  const xl = XL.has(lang);
  const flush = () => { if (run.length) runs.push({ text: run.join(' '), prep: runPrep, len: run.length }); run = []; };
  for (const t of tokens) {
    const keepArt = xl && ART_XL.has(t) && prevDropPrep && !run.length;   // "en Los Ángeles", "in Den Haag": part of the name
    const drop = !keepArt && (PEEL.has(t) || (xl && PEEL_XL_SET.has(t)) || dateHits.has(t) || /^\d+$/.test(t) || t.length < 2 || (t in MONTHS) || (t in WEEKDAYS) || (xl && (t in MONTHS_XL || t in WEEKDAYS_XL)));
    if (drop) { flush(); prevDropPrep = PREP.has(t) || (xl && PREP_XL_SET.has(t)); }
    else { if (!run.length) runPrep = prevDropPrep; run.push(t); }
  }
  flush();
  if (!runs.length) return '';
  const prepRun = runs.find(r => r.prep);          // first place introduced by a preposition
  if (prepRun) return prepRun.text;
  return runs.slice().sort((a, b) => b.len - a.len)[0].text;   // else the longest surviving run
}

// ---- top-level -------------------------------------------------------------
export function parseWeather(q, opts = {}) {
  const lang = ['en', 'es', 'fr', 'de'].includes(opts.lang) ? opts.lang : 'it';
  const now = opts.now instanceof Date ? opts.now : new Date();
  const nf = normWeather(q);
  const out = { isWeather: false, city: '', dayOffset: 0, tooFar: false, aspect: 'general', dateLabel: lang === 'en' ? 'today' : lang === 'it' ? 'oggi' : '' };
  if (!isWeatherQuery(nf)) return out;
  out.isWeather = true;
  out.aspect = detectAspect(nf);
  const tokens = nf.split(' ').filter(Boolean);
  const dt = parseDate(tokens, lang, now);
  out.dayOffset = dt.dayOffset;
  out.tooFar = dt.tooFar;
  out.dateLabel = dt.dateLabel;
  out.city = extractCity(tokens, dt.hitTokens, lang);
  return out;
}

// ---- reply formatting (pure: parsed result + forecast row -> sentence) -----
// fc = { code, tmax, tmin, tcur(optional), precipProb(optional) }
const WMO = {
  it: { 0:'sereno', 1:'poco nuvoloso', 2:'poco nuvoloso', 3:'coperto', 45:'nebbia', 48:'nebbia',
    51:'pioggerella', 53:'pioggerella', 55:'pioggerella', 56:'pioggerella gelata', 57:'pioggerella gelata',
    61:'pioggia', 63:'pioggia', 65:'pioggia forte', 66:'pioggia gelata', 67:'pioggia gelata',
    71:'neve', 73:'neve', 75:'neve abbondante', 77:'nevischio', 80:'rovesci', 81:'rovesci', 82:'rovesci forti',
    85:'rovesci di neve', 86:'rovesci di neve', 95:'temporale', 96:'temporale con grandine', 99:'temporale con grandine' },
  en: { 0:'clear sky', 1:'partly cloudy', 2:'partly cloudy', 3:'overcast', 45:'fog', 48:'fog',
    51:'drizzle', 53:'drizzle', 55:'drizzle', 56:'freezing drizzle', 57:'freezing drizzle',
    61:'rain', 63:'rain', 65:'heavy rain', 66:'freezing rain', 67:'freezing rain',
    71:'snow', 73:'snow', 75:'heavy snow', 77:'snow grains', 80:'showers', 81:'showers', 82:'heavy showers',
    85:'snow showers', 86:'snow showers', 95:'thunderstorm', 96:'thunderstorm with hail', 99:'thunderstorm with hail' },
};
WMO.es = { 0:'despejado', 1:'poco nuboso', 2:'poco nuboso', 3:'cubierto', 45:'niebla', 48:'niebla', 51:'llovizna', 53:'llovizna', 55:'llovizna',
  56:'llovizna helada', 57:'llovizna helada', 61:'lluvia', 63:'lluvia', 65:'lluvia fuerte', 66:'lluvia helada', 67:'lluvia helada', 71:'nieve', 73:'nieve',
  75:'nieve intensa', 77:'granizo fino', 80:'chubascos', 81:'chubascos', 82:'chubascos fuertes', 85:'chubascos de nieve', 86:'chubascos de nieve',
  95:'tormenta', 96:'tormenta con granizo', 99:'tormenta con granizo' };
WMO.fr = { 0:'ciel dégagé', 1:'peu nuageux', 2:'peu nuageux', 3:'couvert', 45:'brouillard', 48:'brouillard', 51:'bruine', 53:'bruine', 55:'bruine',
  56:'bruine verglaçante', 57:'bruine verglaçante', 61:'pluie', 63:'pluie', 65:'forte pluie', 66:'pluie verglaçante', 67:'pluie verglaçante', 71:'neige', 73:'neige',
  75:'forte neige', 77:'grains de neige', 80:'averses', 81:'averses', 82:'fortes averses', 85:'averses de neige', 86:'averses de neige',
  95:'orage', 96:'orage avec grêle', 99:'orage avec grêle' };
WMO.de = { 0:'klar', 1:'leicht bewölkt', 2:'leicht bewölkt', 3:'bedeckt', 45:'Nebel', 48:'Nebel', 51:'Nieselregen', 53:'Nieselregen', 55:'Nieselregen',
  56:'gefrierender Nieselregen', 57:'gefrierender Nieselregen', 61:'Regen', 63:'Regen', 65:'starker Regen', 66:'gefrierender Regen', 67:'gefrierender Regen',
  71:'Schnee', 73:'Schnee', 75:'starker Schneefall', 77:'Schneegriesel', 80:'Schauer', 81:'Schauer', 82:'starke Schauer', 85:'Schneeschauer', 86:'Schneeschauer',
  95:'Gewitter', 96:'Gewitter mit Hagel', 99:'Gewitter mit Hagel' };
const VAR = { it: 'variabile', en: 'variable', es: 'variable', fr: 'variable', de: 'wechselhaft' };
export function wmoText(code, lang) {
  const tbl = WMO[lang] || WMO.it;
  return tbl[code] || VAR[lang] || VAR.it;
}
const isRainCode = (c) => (c >= 51 && c <= 67) || (c >= 80 && c <= 82) || c >= 95;
const isSnowCode = (c) => (c >= 71 && c <= 77) || c === 85 || c === 86;
const isSunCode  = (c) => c === 0 || c === 1;

// Build the human reply for a resolved place + day + forecast row, answering the asked aspect.
// es / fr / de sentences (the it / en ones below are unchanged and tested byte for byte)
const WX_T = {
  es: { rel: ['hoy', 'mañana', 'pasado mañana'], at: (p) => `En ${p}`, yesRain: (w, p) => `Sí, ${w} se espera lluvia en ${p}`, noRain: (w, p) => `No, ${w} no se espera lluvia en ${p}`,
    prob: (pp, d, lo, hi) => ` (probabilidad ${pp} %, ${d}, ${lo}–${hi} °C).`, par: (d, lo, hi) => ` (${d}, ${lo}–${hi} °C).`,
    yesSun: (w, p) => `Sí, ${w} hará sol en ${p}`, noSun: (w, p, d, lo, hi) => `No del todo: ${w} en ${p}, ${d}, ${lo}–${hi} °C.`,
    yesSnow: (w, p) => `Sí, ${w} se espera nieve en ${p}`, noSnow: (w, p) => `No, ${w} no se espera nieve en ${p}`,
    nowT: (p, t, d, lo, hi) => `En ${p} ahora hace ${t} °C (${d}, mín. ${lo} / máx. ${hi} °C).`, day: (at, w, d, lo, hi) => `${at} ${w}: ${d}, mín. ${lo} °C / máx. ${hi} °C.`,
    dayT: (at, w, d, lo, hi) => `${at} ${w}: ${lo}–${hi} °C (${d}).`, nowG: (p, d, t, lo, hi) => `En ${p} ahora: ${d}, ${t} °C (mín. ${lo} / máx. ${hi} °C).`,
    city: '¿Qué ciudad? Por ejemplo: "el tiempo en Madrid".', far: (l) => `Solo tengo previsión para unos 15 días: ${l} está demasiado lejos.`,
    off: 'Necesito internet para consultar el tiempo.', miss: (c) => `No consigo el tiempo de ${c}.` },
  fr: { rel: ["aujourd'hui", 'demain', 'après-demain'], at: (p) => `À ${p}`, yesRain: (w, p) => `Oui, de la pluie est prévue ${w} à ${p}`, noRain: (w, p) => `Non, pas de pluie prévue ${w} à ${p}`,
    prob: (pp, d, lo, hi) => ` (probabilité ${pp} %, ${d}, ${lo}–${hi} °C).`, par: (d, lo, hi) => ` (${d}, ${lo}–${hi} °C).`,
    yesSun: (w, p) => `Oui, ${w} il fera beau à ${p}`, noSun: (w, p, d, lo, hi) => `Pas vraiment : ${w} à ${p}, ${d}, ${lo}–${hi} °C.`,
    yesSnow: (w, p) => `Oui, de la neige est prévue ${w} à ${p}`, noSnow: (w, p) => `Non, pas de neige prévue ${w} à ${p}`,
    nowT: (p, t, d, lo, hi) => `À ${p}, il fait ${t} °C en ce moment (${d}, min ${lo} / max ${hi} °C).`, day: (at, w, d, lo, hi) => `${at} ${w} : ${d}, min ${lo} °C / max ${hi} °C.`,
    dayT: (at, w, d, lo, hi) => `${at} ${w} : ${lo}–${hi} °C (${d}).`, nowG: (p, d, t, lo, hi) => `À ${p} en ce moment : ${d}, ${t} °C (min ${lo} / max ${hi} °C).`,
    city: 'Quelle ville ? Par exemple : « météo à Paris ».', far: (l) => `Je n’ai des prévisions que sur ~15 jours : ${l}, c’est trop loin.`,
    off: 'J’ai besoin d’internet pour consulter la météo.', miss: (c) => `Je n’arrive pas à obtenir la météo pour ${c}.` },
  de: { rel: ['heute', 'morgen', 'übermorgen'], at: (p) => `In ${p}`, yesRain: (w, p) => `Ja, ${w} wird in ${p} Regen erwartet`, noRain: (w, p) => `Nein, ${w} wird in ${p} kein Regen erwartet`,
    prob: (pp, d, lo, hi) => ` (Wahrscheinlichkeit ${pp} %, ${d}, ${lo}–${hi} °C).`, par: (d, lo, hi) => ` (${d}, ${lo}–${hi} °C).`,
    yesSun: (w, p) => `Ja, ${w} wird es in ${p} sonnig`, noSun: (w, p, d, lo, hi) => `Eher nicht: ${w} in ${p} ${d}, ${lo}–${hi} °C.`,
    yesSnow: (w, p) => `Ja, ${w} wird in ${p} Schnee erwartet`, noSnow: (w, p) => `Nein, ${w} wird in ${p} kein Schnee erwartet`,
    nowT: (p, t, d, lo, hi) => `In ${p} sind es gerade ${t} °C (${d}, min. ${lo} / max. ${hi} °C).`, day: (at, w, d, lo, hi) => `${at} ${w}: ${d}, min. ${lo} °C / max. ${hi} °C.`,
    dayT: (at, w, d, lo, hi) => `${at} ${w}: ${lo}–${hi} °C (${d}).`, nowG: (p, d, t, lo, hi) => `In ${p} gerade: ${d}, ${t} °C (min. ${lo} / max. ${hi} °C).`,
    city: 'Welche Stadt? Zum Beispiel: „Wetter in Berlin“.', far: (l) => `Ich habe nur eine Vorhersage für etwa 15 Tage: ${l} ist zu weit weg.`,
    off: 'Ich brauche Internet, um das Wetter abzurufen.', miss: (c) => `Ich bekomme das Wetter für ${c} nicht.` },
};
function formatWeatherXL(parsed, place, fc, lang) {
  const T = WX_T[lang], desc = wmoText(fc.code, lang);
  const hi = Math.round(fc.tmax), lo = Math.round(fc.tmin);
  const when = parsed.dayOffset <= 2 ? T.rel[parsed.dayOffset] : parsed.dateLabel;
  const pp = (typeof fc.precipProb === 'number') ? fc.precipProb : null;
  if (parsed.aspect === 'rain') {
    const willRain = isRainCode(fc.code) || (pp !== null && pp >= 50);
    return (willRain ? T.yesRain(when, place) : T.noRain(when, place)) + (pp !== null ? T.prob(pp, desc, lo, hi) : T.par(desc, lo, hi));
  }
  if (parsed.aspect === 'sun') return isSunCode(fc.code) ? T.yesSun(when, place) + T.par(desc, lo, hi) : T.noSun(when, place, desc, lo, hi);
  if (parsed.aspect === 'snow') return (isSnowCode(fc.code) ? T.yesSnow(when, place) : T.noSnow(when, place)) + T.par(desc, lo, hi);
  if (parsed.aspect === 'temp') {
    if (parsed.dayOffset === 0 && typeof fc.tcur === 'number') return T.nowT(place, Math.round(fc.tcur), desc, lo, hi);
    return T.dayT(T.at(place), when, desc, lo, hi);
  }
  if (parsed.dayOffset === 0 && typeof fc.tcur === 'number') return T.nowG(place, desc, Math.round(fc.tcur), lo, hi);
  return T.day(T.at(place), when, desc, lo, hi);
}
export function formatWeather(parsed, place, fc, lang) {
  if (WX_T[lang]) return formatWeatherXL(parsed, place, fc, lang);
  const en = lang === 'en';
  const desc = wmoText(fc.code, lang);
  const hi = Math.round(fc.tmax), lo = Math.round(fc.tmin);
  const when = parsed.dayOffset === 0 ? (en ? 'today' : 'oggi')
            : parsed.dayOffset === 1 ? (en ? 'tomorrow' : 'domani')
            : parsed.dayOffset === 2 ? (en ? 'the day after tomorrow' : 'dopodomani')
            : parsed.dateLabel;
  const at = en ? `In ${place}` : `A ${place}`;
  const pp = (typeof fc.precipProb === 'number') ? fc.precipProb : null;

  // Targeted yes/no for a specific aspect.
  if (parsed.aspect === 'rain') {
    const willRain = isRainCode(fc.code) || (pp !== null && pp >= 50);
    const head = en
      ? (willRain ? `Yes — rain is expected ${when} in ${place}` : `No — no rain expected ${when} in ${place}`)
      : (willRain ? `Sì, ${when} a ${place} è prevista pioggia` : `No, ${when} a ${place} non è prevista pioggia`);
    const tail = pp !== null ? (en ? ` (${pp}% chance, ${desc}, ${lo}–${hi}°C).` : ` (probabilità ${pp}%, ${desc}, ${lo}–${hi}°C).`)
                             : (en ? ` (${desc}, ${lo}–${hi}°C).` : ` (${desc}, ${lo}–${hi}°C).`);
    return head + tail;
  }
  if (parsed.aspect === 'sun') {
    const sunny = isSunCode(fc.code);
    return en
      ? (sunny ? `Yes — ${when} looks sunny in ${place} (${desc}, ${lo}–${hi}°C).` : `Not really — ${when} in ${place}: ${desc}, ${lo}–${hi}°C.`)
      : (sunny ? `Sì, ${when} a ${place} ci sarà sole (${desc}, ${lo}–${hi}°C).` : `Non proprio: ${when} a ${place} ${desc}, ${lo}–${hi}°C.`);
  }
  if (parsed.aspect === 'snow') {
    const snowy = isSnowCode(fc.code);
    return en
      ? (snowy ? `Yes — snow is expected ${when} in ${place} (${desc}, ${lo}–${hi}°C).` : `No — no snow ${when} in ${place} (${desc}, ${lo}–${hi}°C).`)
      : (snowy ? `Sì, ${when} a ${place} è prevista neve (${desc}, ${lo}–${hi}°C).` : `No, ${when} a ${place} non è prevista neve (${desc}, ${lo}–${hi}°C).`);
  }
  if (parsed.aspect === 'temp') {
    if (parsed.dayOffset === 0 && typeof fc.tcur === 'number')
      return en ? `In ${place} now it's ${Math.round(fc.tcur)}°C (${desc}, ${lo}–${hi}°C today).`
                : `A ${place} ora ci sono ${Math.round(fc.tcur)}°C (${desc}, min ${lo} / max ${hi}°C).`;
    return en ? `${at} ${when}: ${lo}–${hi}°C (${desc}).` : `${at} ${when}: ${lo}–${hi}°C (${desc}).`;
  }
  // general bulletin
  if (parsed.dayOffset === 0 && typeof fc.tcur === 'number')
    return en ? `In ${place} now: ${desc}, ${Math.round(fc.tcur)}°C (low ${lo} / high ${hi}°C).`
              : `A ${place} ora: ${desc}, ${Math.round(fc.tcur)}°C (min ${lo} / max ${hi}°C).`;
  return en ? `${at} ${when}: ${desc}, low ${lo}°C / high ${hi}°C.`
            : `${at} ${when}: ${desc}, min ${lo}°C / max ${hi}°C.`;
}

// ---- live forecast (Open-Meteo: keyless and CORS-open, so the BROWSER calls it directly) ----------
// NEVER cached (volatility law §6). Shared by the ANIMA web app — whose weather used to exist only on
// the Cardputer, so with the device busy or away "meteo brescia" got a generic "I don't know" — and the
// PC simulator (tools/serve-shell.mjs). Mirrors the firmware weather_fetch(): geocode, then the daily
// row for the asked day (start_date=end_date, so any day in the ~15-day horizon works).
// opts: { fetch = globalThis.fetch, headers = {}, online = true, now = new Date() }

const foldPlace = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');

// Geocode with a multi-word fallback: Open-Meteo's index misses "reggio emilia" (stored as "Reggio
// nell'Emilia"), so on a miss search the FIRST token and pick the candidate whose region/admin/country
// matches the remaining words. Mirrors the firmware's full-then-first-token retry.
export async function geocodePlace(city, lang, opts = {}) {
  const f = opts.fetch || globalThis.fetch;
  const search = async (name, count) => {
    const r = await f(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=${count}&language=${['en', 'es', 'fr', 'de'].includes(lang) ? lang : 'it'}&format=json`,
      { headers: opts.headers || {} });
    return r.ok ? ((await r.json())?.results || []) : [];
  };
  const first = await search(city, 1);
  if (first.length && typeof first[0].latitude === 'number') return first[0];
  const toks = String(city).split(/\s+/).filter(Boolean);
  if (toks.length < 2) return null;
  const cand = (await search(toks[0], 10)).filter((c) => typeof c.latitude === 'number');
  if (!cand.length) return null;
  const rest = toks.slice(1).map(foldPlace);
  let best = cand[0], bestScore = -1;
  for (const c of cand) {
    const hay = foldPlace(`${c.name || ''} ${c.admin1 || ''} ${c.admin2 || ''} ${c.admin3 || ''} ${c.country || ''}`);
    const score = rest.reduce((s, t) => s + (hay.includes(t) ? 1 : 0), 0);
    if (score > bestScore) { bestScore = score; best = c; }
  }
  return best;   // the region-matched candidate if any, else the most populous match of the first token
}

// { place, code, tmax, tmin, precipProb?, tcur? } for `city` on today+dayOffset, or null.
export async function fetchForecast(city, dayOffset, lang, opts = {}) {
  const f = opts.fetch || globalThis.fetch;
  const now = opts.now instanceof Date ? opts.now : new Date();
  try {
    const hit = await geocodePlace(city, lang, opts);
    if (!hit || typeof hit.latitude !== 'number') return null;
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + dayOffset);
    const ds = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${hit.latitude}&longitude=${hit.longitude}`
      + '&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max'
      + `&current=temperature_2m&timezone=auto&start_date=${ds}&end_date=${ds}`;
    const r = await f(url, { headers: opts.headers || {} });
    if (!r.ok) return null;
    const j = await r.json();
    const dy = j?.daily;
    if (!dy || !Array.isArray(dy.time) || !dy.time.length || typeof dy.weather_code?.[0] !== 'number') return null;
    return {
      place: hit.name || city,
      code: dy.weather_code[0],
      tmax: dy.temperature_2m_max?.[0],
      tmin: dy.temperature_2m_min?.[0],
      precipProb: typeof dy.precipitation_probability_max?.[0] === 'number' ? dy.precipitation_probability_max[0] : undefined,
      tcur: dayOffset === 0 ? j?.current?.temperature_2m : undefined,
    };
  } catch (e) {
    if (e && e.name === 'AbortError') throw e;       // a stopped turn stays stopped
    return null;
  }
}

// The /api/anima-shaped result of a weather answer (tier 'remote', domain 'meteo' like the device's).
export function weatherResult(q, reply, confidence) {
  return { query: q, tier: 'remote', action: 'answer', intent: 'weather', confidence, state: 'idle',
           reply, learned: false, verified: true, domain: 'meteo' };
}

// Answer a weather question end to end, or null when `q` isn't one. Honest replies for the cases with
// no forecast: no place named, beyond the horizon, no network allowed (opts.online === false), fetch miss.
export async function weatherAnswer(q, lang, opts = {}) {
  const en = lang === 'en', T = WX_T[lang];
  const p = parseWeather(q, { lang, now: opts.now });
  if (!p.isWeather) return null;
  if (T) {                                               // es / fr / de
    if (!p.city) return weatherResult(q, T.city, 55);
    if (p.tooFar) return weatherResult(q, T.far(p.dateLabel), 60);
    if (opts.online === false) return weatherResult(q, T.off, 45);
    const fx = await fetchForecast(p.city, p.dayOffset, lang, opts);
    if (!fx || typeof fx.tmax !== 'number' || typeof fx.tmin !== 'number') return weatherResult(q, T.miss(p.city), 40);
    return weatherResult(q, formatWeather(p, fx.place, fx, lang), 90);
  }
  if (!p.city)
    return weatherResult(q, en ? 'Which city? e.g. "weather in Rome".' : 'Per quale città? Es. "che tempo fa a Roma".', 55);
  if (p.tooFar)
    return weatherResult(q, en ? `I only have a ~15-day forecast — ${p.dateLabel} is too far ahead.`
                               : `Ho previsioni solo fino a ~15 giorni: ${p.dateLabel} è troppo lontano.`, 60);
  if (opts.online === false)
    return weatherResult(q, en ? 'I need internet to check the weather.' : 'Mi serve internet per controllare il meteo.', 45);
  const fc = await fetchForecast(p.city, p.dayOffset, lang, opts);
  if (!fc || typeof fc.tmax !== 'number' || typeof fc.tmin !== 'number')
    return weatherResult(q, en ? `I couldn't get the weather for ${p.city}.` : `Non riesco a recuperare il meteo per ${p.city}.`, 40);
  return weatherResult(q, formatWeather(p, fc.place, fc, lang), 90);
}
