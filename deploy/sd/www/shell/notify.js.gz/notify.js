// System Notification Center — the web backbone of NucleoOS notifications.
// One contract, N producers, 2 surfaces (the web here; the device is the native twin).
// See docs/notify-protocol.md. Lazily loaded by shell.js like copilot.js.
//
// Everything is event-driven: no polling, no /api per keystroke. Notifications arrive
// either from Notify.emit(...) in-process, or from the event bus via WebSocket (topic notify.post,
// plus the legacy calendar.reminder until the firmware has migrated).

import I18N from './nucleo-i18n.js';

const t = I18N.scope('shell');

const LS_LIST = 'nucleo.notify.list';   // history (cap 50)
const LS_DND  = 'nucleo.notify.dnd';    // '1' = Do Not Disturb
const LS_VOL  = 'nucleo.notify.vol';    // 0..100 melody volume
const LS_QUIET= 'nucleo.notify.quiet';  // 'HH:MM-HH:MM' quiet hours, empty = off
const CAP = 50;

// Default per source: icon + i18n key of the tag (resolved at render time, so it
// follows the live OS language — the labels used to be hard-coded Italian in a 5-language OS).
const SRC = {
  calendar: { ic: '🔔', tagKey: 'nc_src_calendar' },
  system:   { ic: '⚙️', tagKey: 'nc_src_system' },
  anima:    { ic: '✨', tagKey: 'nc_src_anima' },
  voice:    { ic: '🎤', tagKey: 'nc_src_voice' },
  recorder: { ic: '🎙️', tagKey: 'nc_src_recorder' },
  ota:      { ic: '⬆️', tagKey: 'nc_src_ota' },
  app:      { ic: '📦', tagKey: 'nc_src_app' },
};

// Consonant chords, one timbre per level — true polyphony (several oscillators together).
// Short, soft attack, exponential release: little bell/chime, not a buzzer.
const CHORD = {
  info:     { notes: [659.25, 987.77],            type: 'sine',     gain: 0.16, roll: 0.0  }, // E5+B5 fifth
  success:  { notes: [523.25, 659.25, 783.99],    type: 'sine',     gain: 0.16, roll: 0.06 }, // C major, arpeggio
  warn:     { notes: [587.33, 880.0],             type: 'triangle', gain: 0.15, roll: 0.05 }, // D5+A5
  critical: { notes: [659.25, 659.25, 987.77],    type: 'triangle', gain: 0.18, roll: 0.06 }, // more attention-grabbing, never shrill
  none:     null,
};

// SIGNATURE earcon per source (WHO) — exact mirror of the firmware notify_signature(): plays BEFORE
// the level chord (urgency). Same "sonic DNA" on both bodies (web + device).
const SIG = {
  anima:    [{ hz: 2093.0, t: 0, d: 0.10 }, { hz: 2637.02, t: 0.05, d: 0.12 }], // high sparkle
  calendar: [{ hz: 783.99, t: 0, d: 0.16 }],                                    // warm chime
  ota:      [{ hz: 523.25, t: 0, d: 0.10 }, { hz: 783.99, t: 0.07, d: 0.12 }],  // ascending
  recorder: [{ hz: 880.0,  t: 0, d: 0.10 }, { hz: 698.46, t: 0.07, d: 0.12 }],  // descending
  voice:    [{ hz: 659.25, t: 0, d: 0.14 }],
  app:      [{ hz: 587.33, t: 0, d: 0.12 }],
  system:   [{ hz: 523.25, t: 0, d: 0.13 }],
};
const SIG_LEN = 0.16;

export function initNotify(OS_API) {
  const { byId, WM, openFile, FsIndex } = OS_API || {};
  let all = load();          // notifications [{id,src,lvl,icon,title,body,action,sound,sticky,ts,read,count}]
  let dnd = localStorage.getItem(LS_DND) === '1';
  let actx = null;           // Lazy AudioContext (created on the first sound after a user gesture)

  // ---- persistence -------------------------------------------------------
  // localStorage is synchronous: a burst of notifications would cause N writes. We coalesce them into ONE
  // (short timer), with an immediate flush if the page is about to close → no history loss.
  function load() {
    try { const a = JSON.parse(localStorage.getItem(LS_LIST)); return Array.isArray(a) ? a : []; } catch { return []; }
  }
  let saveTimer = null;
  function flushSave() {
    if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
    try { localStorage.setItem(LS_LIST, JSON.stringify(all.slice(0, CAP))); } catch {}
  }
  function save() { if (!saveTimer) saveTimer = setTimeout(flushSave, 300); }
  window.addEventListener('pagehide', flushSave);
  document.addEventListener('visibilitychange', () => { if (document.hidden) flushSave(); });

  // ---- DOM: bell in tray + flyout ---------------------------------
  const tray = document.getElementById('tray');
  const bell = document.createElement('span');
  bell.id = 'notif-bell'; bell.title = t('nc_title'); bell.setAttribute('role', 'button');
  bell.innerHTML =
    '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.3" aria-hidden="true">' +
    '<path d="M4 6.5a4 4 0 0 1 8 0c0 3 1 4 1.4 4.5H2.6C3 10.5 4 9.5 4 6.5z" stroke-linejoin="round"/>' +
    '<path d="M6.5 13a1.5 1.5 0 0 0 3 0" stroke-linecap="round"/></svg>' +
    '<span class="nb-badge" hidden>0</span>';
  // Inserted before the clock (Win11 order: notifications next to the date/time).
  const clock = document.getElementById('clock');
  if (tray && clock) tray.insertBefore(bell, clock); else if (tray) tray.appendChild(bell);

  const center = document.createElement('section');
  center.id = 'notif-center'; center.className = 'hidden';
  center.setAttribute('aria-label', t('nc_title'));
  center.innerHTML =
    '<div class="nc-head">' +
      `<span class="nc-title">${t('nc_title')}</span>` +
      `<button id="nc-dnd" title="${t('nc_dnd_title')}">🌙 <span>DND</span></button>` +
      `<button id="nc-amb" title="${t('amb_toggle_title')}">✨</button>` +
      `<button id="nc-clear" title="${t('nc_clear_title')}">${t('nc_clear')}</button>` +
    '</div>' +
    '<div class="nc-digest" id="nc-digest" hidden></div>' +
    '<div class="nc-list" id="nc-list"></div>';
  document.body.appendChild(center);
  // Live language switch: retranslate the static chrome and re-render the open list.
  I18N.onChange(() => {
    bell.title = t('nc_title');
    center.querySelector('.nc-title').textContent = t('nc_title');
    dndBtn.title = t('nc_dnd_title');
    ambBtn.title = t('amb_toggle_title');
    clearBtn.title = t('nc_clear_title'); clearBtn.childNodes[0].textContent = t('nc_clear');
    if (isOpen()) render();
  });

  const listEl = center.querySelector('#nc-list');
  const digestEl = center.querySelector('#nc-digest');
  const dndBtn = center.querySelector('#nc-dnd');
  const ambBtn = center.querySelector('#nc-amb');
  const clearBtn = center.querySelector('#nc-clear');

  // Proactive-ANIMA switch (ambient.js). The panel owns only the button: it flips the LS key and
  // announces it with an event; ambient.js is the one that starts/stops. Loose coupling on
  // purpose — no cross-imports between the two lazy modules.
  const AMB_LS = 'nucleo.ambient';
  const ambOn = () => (localStorage.getItem(AMB_LS) || '1') !== '0';
  const paintAmb = () => ambBtn.classList.toggle('active', ambOn());
  ambBtn.addEventListener('click', () => {
    const on = !ambOn();
    try { localStorage.setItem(AMB_LS, on ? '1' : '0'); } catch {}   // quota/private mode must not kill the Center
    paintAmb();
    document.dispatchEvent(new CustomEvent('nucleo:ambient-toggle', { detail: { on } }));
  });
  paintAmb();

  // ---- open/close --------------------------------------------------------
  function isOpen() { return !center.classList.contains('hidden'); }
  function open() {
    center.classList.remove('hidden');
    markAllRead(); render(); syncBadge();
    // close the other flyouts for Win11 consistency
    const ac = document.getElementById('action-center'); if (ac) ac.classList.add('hidden');
    const sm = document.getElementById('start-menu'); if (sm) sm.classList.add('hidden');   // the shell toggles `hidden`, not `open`
  }
  function close() { center.classList.add('hidden'); }
  function toggle() { isOpen() ? close() : open(); }

  bell.addEventListener('click', (e) => { e.stopPropagation(); toggle(); });
  document.addEventListener('click', (e) => {
    if (isOpen() && !center.contains(e.target) && !bell.contains(e.target)) close();
  });
  dndBtn.addEventListener('click', () => setDND(!dnd));
  clearBtn.addEventListener('click', () => clearAll());

  // ---- DND ---------------------------------------------------------------
  function inQuietHours() {
    const q = localStorage.getItem(LS_QUIET) || '';
    const m = q.match(/^(\d{2}):(\d{2})-(\d{2}):(\d{2})$/); if (!m) return false;
    const now = new Date(); const cur = now.getHours() * 60 + now.getMinutes();
    const a = (+m[1]) * 60 + (+m[2]), b = (+m[3]) * 60 + (+m[4]);
    return a <= b ? (cur >= a && cur < b) : (cur >= a || cur < b);  // window that crosses midnight
  }
  function muted() { return dnd || inQuietHours(); }
  function setDND(on) {
    dnd = !!on; try { localStorage.setItem(LS_DND, dnd ? '1' : '0'); } catch {}   // runs during init — a quota throw here would abort initNotify
    dndBtn.classList.toggle('active', dnd); bell.classList.toggle('dnd', dnd);
  }
  setDND(dnd);

  // ---- polyphonic melody (Web Audio, true polyphony) --------------------
  // One voice: fundamental + 2nd harmonic (chime timbre) with a soft ADSR.
  function playVoice(master, hz, t, dur, type) {
    const osc = actx.createOscillator(); osc.type = type; osc.frequency.value = hz;
    const o2 = actx.createOscillator(); o2.type = 'sine'; o2.frequency.value = hz * 2;
    const g = actx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(1, t + 0.012);            // soft attack ~12ms
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);         // exponential release
    const g2 = actx.createGain(); g2.gain.value = 0.35; g2.connect(g);
    osc.connect(g); o2.connect(g2); g.connect(master);
    osc.start(t); o2.start(t); osc.stop(t + dur + 0.05); o2.stop(t + dur + 0.05);
  }
  // Earcon = source signature (WHO) + level chord (urgency) in a single polyphonic phrase.
  function chime(n) {
    const level = (n && (n.sound || n.lvl)) || 'info';
    const spec = CHORD[level] || CHORD.info; if (!spec) return;
    const vol = (parseInt(localStorage.getItem(LS_VOL) || '60', 10) || 0) / 100;
    if (vol <= 0) return;
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      if (actx.state === 'suspended') actx.resume();
      const t0 = actx.currentTime + 0.01;
      const master = actx.createGain();
      master.gain.value = spec.gain * vol;
      master.connect(actx.destination);
      (SIG[n && n.src] || SIG.system).forEach((v) => playVoice(master, v.hz, t0 + v.t, v.d, 'sine'));     // signature (who)
      spec.notes.forEach((hz, i) => playVoice(master, hz, t0 + SIG_LEN + i * spec.roll, 0.5, spec.type)); // chord (urgency)
    } catch {}
  }

  // ---- badge -------------------------------------------------------------
  function unread() { return all.reduce((n, x) => n + (x.read ? 0 : 1), 0); }
  function syncBadge() {
    const b = bell.querySelector('.nb-badge'); const n = unread();
    if (n > 0) { b.textContent = n > 99 ? '99+' : String(n); b.hidden = false; }
    else b.hidden = true;
  }
  function markAllRead() { all.forEach((x) => { x.read = true; }); save(); }

  // ---- flyout rendering --------------------------------------------------
  function fmtWhen(ts) {
    const d = new Date(ts), now = new Date();
    const same = d.toDateString() === now.toDateString();
    const hh = String(d.getHours()).padStart(2, '0'), mm = String(d.getMinutes()).padStart(2, '0');
    return same ? `${hh}:${mm}` : `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')} ${hh}:${mm}`;
  }
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  // Digest: a one-line summary computed from the history (zero cost).
  function digestText() {
    if (!all.length) return '';
    let cal = 0, ai = 0, unread = 0;
    for (const n of all) { if (n.src === 'calendar') cal++; else if (n.src === 'anima') ai++; if (!n.read) unread++; }
    const p = [t('nc_digest_count', { count: all.length, n: all.length })];
    if (cal) p.push(t('nc_digest_cal', { n: cal }));
    if (ai) p.push(`${ai} ANIMA`);
    if (unread) p.push(t('nc_digest_unread', { n: unread }));
    return p.join(' · ');
  }
  function updateDigest() { const t = digestText(); digestEl.textContent = t; digestEl.hidden = !t; }

  function render() {
    updateDigest();
    if (!all.length) { listEl.innerHTML = `<div class="nc-empty">${esc(t('nc_empty'))}</div>`; return; }
    listEl.innerHTML = '';
    for (const n of all) {
      const meta = SRC[n.src] || SRC.app;
      const row = document.createElement('div');
      row.className = `nc-item lvl-${n.lvl || 'info'}`;
      row.innerHTML =
        `<div class="nc-ic">${esc(n.icon || meta.ic)}</div>` +
        '<div class="nc-body">' +
          '<div class="nc-row">' +
            `<span class="nc-ttl">${esc(n.title)}</span>` +
            (n.count > 1 ? `<span class="nc-count">×${n.count}</span>` : '') +
            `<span class="nc-when">${fmtWhen(n.ts)}</span>` +
          '</div>' +
          (n.body ? `<div class="nc-txt">${esc(n.body)}</div>` : '') +
          `<div class="nc-tag">${esc(t(meta.tagKey))}</div>` +
        '</div>' +
        `<button class="nc-x" title="${esc(t('nc_remove'))}">×</button>`;
      row.querySelector('.nc-x').addEventListener('click', (e) => { e.stopPropagation(); remove(n.id); });
      row.addEventListener('click', () => { runAction(n.action); close(); });
      listEl.appendChild(row);
    }
  }

  function remove(id) { all = all.filter((x) => x.id !== id); save(); render(); syncBadge(); }
  function clearAll() { all = []; save(); render(); syncBadge(); }

  // ---- transient toast (enriched: level + action) ------------------------
  function toast(n) {
    const container = document.getElementById('toast-container'); if (!container) return;
    const meta = SRC[n.src] || SRC.app;
    const t = document.createElement('div');
    t.className = `toast n-toast ${n.lvl || 'info'}`;
    const actLabel = actionLabel(n.action);
    t.innerHTML =
      '<div class="nt-main">' +
        `<div class="toast-icon">${esc(n.icon || meta.ic)}</div>` +
        `<div class="toast-body"><div class="toast-title">${esc(n.title)}</div>` +
        (n.body ? `<div class="toast-msg">${esc(n.body)}</div>` : '') + '</div>' +
      '</div>' +
      (actLabel ? `<button class="nt-act">${esc(actLabel)}</button>` : '');
    const kill = () => { t.classList.add('removing'); setTimeout(() => t.remove(), 220); };
    t.addEventListener('click', kill);
    const actBtn = t.querySelector('.nt-act');
    if (actBtn) actBtn.addEventListener('click', (e) => { e.stopPropagation(); runAction(n.action); kill(); });
    container.appendChild(t);
    if (!n.sticky) setTimeout(kill, n.lvl === 'critical' ? 12000 : 6500);
  }

  // ---- action router (same contract as the copilot) ----------------------
  function actionLabel(act) {
    if (!act) return '';
    const [k, v] = splitAct(act);
    if (k === 'app') return t('open');
    if (k === 'file') return t('open');
    if (k === 'anima') return t('nc_ask_anima');
    return '';
  }
  function splitAct(act) { const i = String(act).indexOf(':'); return i < 0 ? [act, ''] : [act.slice(0, i), act.slice(i + 1)]; }
  function runAction(act) {
    if (!act) return;
    const [k, v] = splitAct(act);
    try {
      if (k === 'app') {
        // "app:settings@updates" deep-links a tab inside the app: a one-shot localStorage hint
        // covers a cold app boot, a postMessage covers one already open (same contract, see the
        // Settings boot + message listener).
        const at = v.indexOf('@'); const id = at < 0 ? v : v.slice(0, at); const tab = at < 0 ? '' : v.slice(at + 1);
        if (tab) try { localStorage.setItem('nucleo.settings.tab', tab); } catch {}
        const a = byId && byId(id); if (a && WM) WM.open(a);
        if (tab && WM) try {
          const w = WM.list().find((x) => x.app && x.app.id === id);
          const f = w && w.el.querySelector('iframe');
          if (f) f.contentWindow.postMessage({ t: 'settings.tab', d: tab }, '*');
        } catch {}
      }
      else if (k === 'file') { if (openFile) openFile(v); }
      else if (k === 'anima') {
        // Forward to the system copilot if present (Ctrl+Space).
        document.dispatchEvent(new CustomEvent('nucleo:anima-ask', { detail: { q: v } }));
      }
    } catch (e) { console.warn('[notify] action failed', act, e); }
  }

  // ---- single entry point: emit ------------------------------------------
  function emit(input) {
    const n = normalize(input); if (!n) return;
    // coalescing per id: replace at the top, increment the counter.
    const prev = all.find((x) => x.id === n.id);
    all = all.filter((x) => x.id !== n.id);
    n.count = prev ? (prev.count || 1) + 1 : 1;
    all.unshift(n);
    if (all.length > CAP) all = all.slice(0, CAP);
    save();
    if (isOpen()) { n.read = true; save(); render(); }
    else if (!muted()) { toast(n); chime(n); }
    else { /* DND/quiet hours: no toast/sound, stays in the history */ }
    syncBadge();
    return n.id;
  }

  function normalize(input) {
    if (!input || (!input.title && !input.ttl)) return null;
    const src = (input.src || 'system').toLowerCase();
    const lvl = (input.lvl || input.level || 'info').toLowerCase();
    const meta = SRC[src] || SRC.app;
    return {
      id: input.id || `${src}-${Date.now()}-${Math.floor(Math.random() * 1e4)}`,
      src, lvl,
      icon: input.icon || input.ic || meta.ic,
      title: String(input.title || input.ttl || '').slice(0, 120),
      body: String(input.body || input.bd || '').slice(0, 240),
      action: input.action || input.act || '',
      sound: input.sound || input.snd || lvl,
      sticky: !!(input.sticky),
      ts: input.ts ? (input.ts < 1e12 ? input.ts * 1000 : input.ts) : Date.now(),  // accepts epoch s or ms
      read: false,
    };
  }

  // ---- entry from the event bus (WebSocket) -------------------------------
  function fromBus(topic, d) {
    if (topic === 'notify.post' && d) return emit(d);
    if (topic === 'calendar.reminder' && d) {  // legacy, until the firmware emits notify.post
      return emit({
        id: 'cal-' + (d.time || ''), src: 'calendar', lvl: 'info', icon: '🔔',
        title: d.text || t('nc_reminder'), body: d.time ? `${t('nc_reminder')} · ${d.time}` : '',
        action: 'app:calendar', sound: 'info',
      });
    }
  }

  syncBadge();   // restore the badge from the persisted history
  return { emit, fromBus, open, close, toggle, isOpen, clearAll, setDND, get all() { return all; } };
}
